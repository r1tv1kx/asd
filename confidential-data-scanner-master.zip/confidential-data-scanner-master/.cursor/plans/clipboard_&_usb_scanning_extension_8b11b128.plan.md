---
name: Clipboard & USB Scanning Extension
overview: Extend the existing confidential data scanner system with clipboard monitoring and USB device scanning capabilities, building upon the current Go Windows service architecture with minimal changes to backend services.
todos:
  - id: database-schema
    content: Extend SQLite schema with clipboard and USB tables
    status: completed
  - id: models-config
    content: Add clipboard/USB models and configuration structs
    status: completed
  - id: clipboard-monitor
    content: Implement clipboard monitoring module in Go
    status: completed
  - id: clipboard-api
    content: Add clipboard API endpoints to local REST server
    status: completed
  - id: usb-monitor
    content: Implement USB device monitoring with WMI
    status: completed
  - id: usb-api
    content: Add USB device management API endpoints
    status: completed
  - id: service-integration
    content: Integrate monitors into Windows service lifecycle
    status: completed
  - id: dashboard-backend
    content: Extend Node.js dashboard with new models and routes
    status: completed
  - id: desktop-ui
    content: Update Electron UI with clipboard/USB features
    status: completed
  - id: web-dashboard
    content: Update React dashboard with scan source filtering
    status: completed
  - id: testing
    content: End-to-end testing of clipboard and USB features
    status: completed
  - id: documentation
    content: Update documentation and configuration guides
    status: completed
---

# Clipboard & USB Scanning Extension Plan

## Overview

This plan extends the existing confidential data scanner to monitor clipboard activity and automatically scan USB devices for confidential data. Both features integrate seamlessly with the current architecture, reusing the Python analyzer, dashboard server, and existing scanning infrastructure.

## Architecture Changes

```mermaid
flowchart TB
    subgraph WindowsClient [Windows Client - Extended]
        WinService[Windows Service Go]
        ClipboardMonitor[Clipboard Monitor]
        USBMonitor[USB Device Monitor]
        FileScanner[File Scanner Existing]
        LocalDB[(SQLite DB)]
    end
    
    subgraph Backend [Backend Services - No Changes]
        AnalyzerServer[Python Analyzer]
        DashboardAPI[Node.js API]
        PostgreSQL[(PostgreSQL)]
    end
    
    subgraph UI [User Interfaces - Minor Updates]
        DesktopUI[Electron Desktop UI]
        WebDashboard[React Dashboard]
    end
    
    ClipboardMonitor -->|Text Content| WinService
    USBMonitor -->|Device Events| FileScanner
    FileScanner -->|Extracted Text| AnalyzerServer
    ClipboardMonitor -->|Text Content| AnalyzerServer
    AnalyzerServer -->|Detection Results| WinService
    WinService -->|Store Detections| LocalDB
    WinService -->|Submit Results| DashboardAPI
    WinService <-->|REST API| DesktopUI
    DashboardAPI <-->|Query Data| PostgreSQL
    DashboardAPI <-->|REST API| WebDashboard
```



## Implementation Components

### 1. Clipboard Monitor (Go Module)

**New File:** `windows-service/internal/clipboard/monitor.go`**Functionality:**

- Background goroutine monitoring clipboard changes using Windows API
- Debouncing to prevent excessive API calls (configurable interval)
- Text extraction from clipboard (text/plain format only)
- SHA-256 hashing of clipboard content for duplicate detection
- Integration with existing analyzer client
- Real-time alerts for detected sensitive data

**Key Dependencies:**

- `golang.design/x/clipboard` - Cross-platform clipboard library
- `golang.org/x/sys/windows` - Windows API access (already in project)

**Configuration Extension:**

```yaml
clipboard:
  enabled: true
  check_interval_ms: 500
  min_text_length: 10
  ignore_duplicates: true
  retention_hours: 24
  alert_on_detection: true
```

**Integration Points:**

- Initialize in [`windows-service/internal/service/service.go`](windows-service/internal/service/service.go) during service startup
- Use existing [`analyzer.Client`](windows-service/internal/analyzer/client.go) for text analysis
- Store detections via existing [`db.Database`](windows-service/internal/db/sqlite.go)
- Submit to dashboard via existing [`dashboard.Client`](windows-service/internal/dashboard/client.go)

---

### 2. USB Device Monitor (Go Module)

**New File:** `windows-service/internal/usb/monitor.go`**Functionality:**

- WMI event subscription for USB device insertion/removal
- Automatic drive letter detection
- Device metadata tracking (vendor, serial, name)
- Trigger existing file scanner on USB mount
- Device whitelist/blacklist support
- Optional blocking of USB ejection if sensitive data detected

**Key Dependencies:**

- `github.com/StackExchange/wmi` - Windows Management Instrumentation
- `github.com/fsnotify/fsnotify` - File system notifications (optional)

**Configuration Extension:**

```yaml
usb:
  enabled: true
  auto_scan_on_insert: true
  scan_hidden_files: false
  max_scan_size_gb: 32
  block_on_detection: false
  whitelist_devices: []
  blacklist_devices: []
  scan_timeout_minutes: 30
```

**Integration Points:**

- Initialize in [`windows-service/internal/service/service.go`](windows-service/internal/service/service.go)
- Trigger existing [`scanner.Scanner`](windows-service/internal/scanner/scanner.go) for USB directory scanning
- Reuse all existing file extraction and analysis pipeline
- Track USB devices in new database table

---

### 3. Database Schema Extensions

**File:** [`windows-service/internal/db/sqlite.go`](windows-service/internal/db/sqlite.go)**New Tables:**

```sql
-- Clipboard detections history
CREATE TABLE clipboard_detections (
  id TEXT PRIMARY KEY,
  content_hash TEXT NOT NULL,
  detection_type TEXT NOT NULL,
  confidence REAL,
  severity TEXT,
  detected_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  source_app TEXT,
  is_resolved INTEGER DEFAULT 0,
  synced INTEGER DEFAULT 0
);

-- USB device tracking
CREATE TABLE usb_devices (
  id TEXT PRIMARY KEY,
  device_serial TEXT,
  device_vendor TEXT,
  device_name TEXT,
  drive_letter TEXT,
  first_seen DATETIME,
  last_seen DATETIME,
  is_whitelisted INTEGER DEFAULT 0,
  is_blacklisted INTEGER DEFAULT 0
);

-- USB scan sessions
CREATE TABLE usb_scan_sessions (
  id TEXT PRIMARY KEY,
  device_id TEXT REFERENCES usb_devices(id),
  started_at DATETIME,
  completed_at DATETIME,
  status TEXT,
  files_scanned INTEGER DEFAULT 0,
  detections_found INTEGER DEFAULT 0
);

-- Add scan_source to existing detections table
ALTER TABLE detections ADD COLUMN scan_source TEXT DEFAULT 'filesystem';
-- Values: 'filesystem', 'clipboard', 'usb'

ALTER TABLE detections ADD COLUMN usb_device_id TEXT REFERENCES usb_devices(id);
```

**New Methods:**

- `SaveClipboardDetection(detection *ClipboardDetection) error`
- `GetClipboardDetections(limit, offset int) ([]ClipboardDetection, error)`
- `SaveUSBDevice(device *USBDevice) error`
- `GetUSBDevices() ([]USBDevice, error)`
- `GetUSBDeviceBySerial(serial string) (*USBDevice, error)`
- `SaveUSBScanSession(session *USBScanSession) error`

---

### 4. Models Extension

**File:** [`windows-service/internal/models/models.go`](windows-service/internal/models/models.go)**New Structs:**

```go
// ClipboardDetection represents a detection from clipboard monitoring
type ClipboardDetection struct {
    ID            string    `json:"id"`
    ContentHash   string    `json:"contentHash"`
    DetectionType string    `json:"detectionType"`
    Confidence    float64   `json:"confidence"`
    Severity      string    `json:"severity"`
    DetectedAt    time.Time `json:"detectedAt"`
    SourceApp     string    `json:"sourceApp,omitempty"`
    IsResolved    bool      `json:"isResolved"`
}

// USBDevice represents a USB device
type USBDevice struct {
    ID            string    `json:"id"`
    DeviceSerial  string    `json:"deviceSerial"`
    DeviceVendor  string    `json:"deviceVendor"`
    DeviceName    string    `json:"deviceName"`
    DriveLetter   string    `json:"driveLetter"`
    FirstSeen     time.Time `json:"firstSeen"`
    LastSeen      time.Time `json:"lastSeen"`
    IsWhitelisted bool      `json:"isWhitelisted"`
    IsBlacklisted bool      `json:"isBlacklisted"`
}

// USBScanSession represents a USB scan session
type USBScanSession struct {
    ID              string     `json:"id"`
    DeviceID        string     `json:"deviceId"`
    StartedAt       time.Time  `json:"startedAt"`
    CompletedAt     *time.Time `json:"completedAt,omitempty"`
    Status          string     `json:"status"`
    FilesScanned    int        `json:"filesScanned"`
    DetectionsFound int        `json:"detectionsFound"`
}

// Extend existing Detection struct
type Detection struct {
    // ... existing fields ...
    ScanSource   string `json:"scanSource"`   // 'filesystem', 'clipboard', 'usb'
    USBDeviceID  string `json:"usbDeviceId,omitempty"`
}
```

---

### 5. Configuration Extension

**File:** [`windows-service/internal/config/config.go`](windows-service/internal/config/config.go)**Add New Config Sections:**

```go
type Config struct {
    Scan      ScanConfig      `yaml:"scan" json:"scan"`
    Clipboard ClipboardConfig `yaml:"clipboard" json:"clipboard"`
    USB       USBConfig       `yaml:"usb" json:"usb"`
    Servers   ServersConfig   `yaml:"servers" json:"servers"`
    API       APIConfig       `yaml:"api" json:"api"`
}

type ClipboardConfig struct {
    Enabled          bool   `yaml:"enabled" json:"enabled"`
    CheckIntervalMs  int    `yaml:"check_interval_ms" json:"check_interval_ms"`
    MinTextLength    int    `yaml:"min_text_length" json:"min_text_length"`
    IgnoreDuplicates bool   `yaml:"ignore_duplicates" json:"ignore_duplicates"`
    RetentionHours   int    `yaml:"retention_hours" json:"retention_hours"`
    AlertOnDetection bool   `yaml:"alert_on_detection" json:"alert_on_detection"`
}

type USBConfig struct {
    Enabled            bool     `yaml:"enabled" json:"enabled"`
    AutoScanOnInsert   bool     `yaml:"auto_scan_on_insert" json:"auto_scan_on_insert"`
    ScanHiddenFiles    bool     `yaml:"scan_hidden_files" json:"scan_hidden_files"`
    MaxScanSizeGB      int      `yaml:"max_scan_size_gb" json:"max_scan_size_gb"`
    BlockOnDetection   bool     `yaml:"block_on_detection" json:"block_on_detection"`
    WhitelistDevices   []string `yaml:"whitelist_devices" json:"whitelist_devices"`
    BlacklistDevices   []string `yaml:"blacklist_devices" json:"blacklist_devices"`
    ScanTimeoutMinutes int      `yaml:"scan_timeout_minutes" json:"scan_timeout_minutes"`
}
```

---

### 6. Service Integration

**File:** [`windows-service/internal/service/service.go`](windows-service/internal/service/service.go)**Modifications:**

```go
type WindowsService struct {
    config           *config.Config
    db               *db.Database
    scanner          *scanner.Scanner
    clipboardMonitor *clipboard.Monitor  // NEW
    usbMonitor       *usb.Monitor        // NEW
    apiServer        *api.Server
    analyzerClient   *analyzer.Client
    dashboardClient  *dashboard.Client
    clientID         string
}

func (ws *WindowsService) initialize() error {
    // ... existing initialization ...
    
    // Initialize clipboard monitor if enabled
    if ws.config.Clipboard.Enabled {
        ws.clipboardMonitor = clipboard.New(
            ws.config,
            ws.db,
            ws.analyzerClient,
            ws.dashboardClient,
        )
        go ws.clipboardMonitor.Start()
    }
    
    // Initialize USB monitor if enabled
    if ws.config.USB.Enabled {
        ws.usbMonitor = usb.New(
            ws.config,
            ws.db,
            ws.scanner,
            ws.dashboardClient,
        )
        go ws.usbMonitor.Start()
    }
    
    return nil
}
```

---

### 7. API Server Extensions

**File:** [`windows-service/internal/api/server.go`](windows-service/internal/api/server.go)**New Endpoints:**

```javascript
GET  /api/clipboard/detections      - Get clipboard detection history
POST /api/clipboard/clear           - Clear clipboard detection history
GET  /api/clipboard/status          - Get clipboard monitor status
PUT  /api/clipboard/config          - Update clipboard settings

GET  /api/usb/devices               - List all USB devices
GET  /api/usb/devices/:id           - Get USB device details
POST /api/usb/devices/:id/whitelist - Add device to whitelist
POST /api/usb/devices/:id/blacklist - Add device to blacklist
GET  /api/usb/sessions              - Get USB scan sessions
POST /api/usb/scan/:deviceId        - Trigger manual USB scan
```

---

### 8. Dashboard Server Extensions

**File:** `dashboard-server/src/models/Detection.js`**Modifications:**

```javascript
// Add new fields to Detection model
scanSource: {
  type: DataTypes.ENUM('filesystem', 'clipboard', 'usb'),
  defaultValue: 'filesystem',
},
usbDeviceId: {
  type: DataTypes.UUID,
  allowNull: true,
},
```

**New Models:**

- `dashboard-server/src/models/USBDevice.js` - Track USB devices across clients
- `dashboard-server/src/models/ClipboardDetection.js` - Clipboard-specific detections

**New Routes:**

- `dashboard-server/src/routes/clipboard.js` - Clipboard detection endpoints
- `dashboard-server/src/routes/usb.js` - USB device and scan endpoints

---

### 9. Desktop UI Updates

**Files to Modify:**

- `desktop-ui/src/pages/Status.tsx` - Add clipboard/USB monitoring status
- `desktop-ui/src/pages/Detections.tsx` - Add filter by scan source
- `desktop-ui/src/pages/Settings.tsx` - Add clipboard/USB configuration UI

**New Components:**

- `desktop-ui/src/components/ClipboardAlert.tsx` - Real-time clipboard alerts
- `desktop-ui/src/components/USBDeviceCard.tsx` - USB device display

**New Pages:**

- `desktop-ui/src/pages/ClipboardHistory.tsx` - Clipboard detection history
- `desktop-ui/src/pages/USBDevices.tsx` - USB device management

---

### 10. Web Dashboard Updates

**Files to Modify:**

- `dashboard-ui/src/pages/Dashboard.tsx` - Add clipboard/USB statistics
- `dashboard-ui/src/pages/Detections.tsx` - Add scan source filter
- `dashboard-ui/src/pages/ClientDetail.tsx` - Show USB devices per client

**New Components:**

- `dashboard-ui/src/components/ScanSourceChip.tsx` - Visual indicator for scan source
- `dashboard-ui/src/components/USBDeviceList.tsx` - USB device list view

---

## Implementation Order

### Phase 1: Core Infrastructure (3-4 days)

1. **Database Schema Extension**

- Add new tables to SQLite schema
- Implement new database methods
- Add migration support

2. **Models & Configuration**

- Extend models with new structs
- Add clipboard/USB config sections
- Update config loading/saving

### Phase 2: Clipboard Monitoring (2-3 days)

3. **Clipboard Monitor Module**

- Implement clipboard watcher
- Add debouncing and duplicate detection
- Integrate with analyzer client
- Add real-time alerting

4. **Clipboard API Endpoints**

- Add local API endpoints
- Implement clipboard history retrieval
- Add configuration endpoints

### Phase 3: USB Device Monitoring (3-4 days)

5. **USB Monitor Module**

- Implement WMI event subscription
- Add device detection and tracking
- Integrate with existing scanner
- Implement whitelist/blacklist logic

6. **USB API Endpoints**

- Add USB device management endpoints
- Implement scan triggering
- Add device whitelisting API

### Phase 4: Service Integration (1-2 days)

7. **Windows Service Updates**

- Integrate clipboard monitor into service lifecycle
- Integrate USB monitor into service lifecycle
- Add graceful shutdown handling
- Update service initialization

### Phase 5: Backend Updates (2-3 days)

8. **Dashboard Server Extensions**

- Add new database models
- Implement new API routes
- Update existing endpoints for scan source filtering

9. **Desktop UI Updates**

- Add clipboard/USB settings
- Implement real-time clipboard alerts
- Add USB device management UI
- Update detection views with filters

### Phase 6: Web Dashboard Updates (1-2 days)

10. **React Dashboard Extensions**

    - Add scan source filtering
    - Display USB device information
    - Update statistics to include new sources

### Phase 7: Testing & Documentation (2-3 days)

11. **Integration Testing**

    - Test clipboard monitoring with various data types
    - Test USB device detection and scanning
    - Test whitelist/blacklist functionality
    - Performance testing (clipboard polling overhead)

12. **Documentation Updates**

    - Update README with new features
    - Document new configuration options
    - Add troubleshooting guide
    - Update API documentation

---

## Security & Privacy Considerations

### Clipboard Monitoring

- **User Consent:** Explicit opt-in required in settings
- **No Storage:** Only store detection metadata and content hashes
- **Real-time Alerts:** Immediate notification when sensitive data detected
- **Auto-Clear:** Optional automatic clipboard clearing on detection
- **Transparency:** Show clipboard monitoring status in UI

### USB Scanning

- **Device Tracking:** Track devices but respect privacy
- **Selective Scanning:** Only scan configured file types
- **Whitelist Support:** Allow trusted devices to bypass scanning
- **Block Capability:** Optional prevention of USB ejection (requires admin)
- **Audit Trail:** Complete history of USB device connections

---

## Configuration Example

**Updated `windows-service/config.yaml`:**

```yaml
scan:
  directories:
    - C:\Users\%USERNAME%\Documents
    - C:\Users\%USERNAME%\Desktop
    - C:\Users\%USERNAME%\Downloads
  file_types:
    - .txt
    - .pdf
    - .doc
    - .docx
  interval_hours: 24
  max_file_size_mb: 50
  worker_count: 4

clipboard:
  enabled: true
  check_interval_ms: 500
  min_text_length: 10
  ignore_duplicates: true
  retention_hours: 24
  alert_on_detection: true

usb:
  enabled: true
  auto_scan_on_insert: true
  scan_hidden_files: false
  max_scan_size_gb: 32
  block_on_detection: false
  whitelist_devices: []
  blacklist_devices: []
  scan_timeout_minutes: 30

servers:
  analyzer_url: http://localhost:8000
  dashboard_url: http://localhost:3001

api:
  port: 8080
```

---

## Dependencies to Add

**Go Dependencies (`windows-service/go.mod`):**

```javascript
golang.design/x/clipboard v0.7.0
github.com/StackExchange/wmi v1.2.1
github.com/fsnotify/fsnotify v1.7.0  // optional
```

**No changes required for:**

- Python analyzer server (works as-is)
- Node.js dependencies (existing packages sufficient)
- React dependencies (existing packages sufficient)

---

## Estimated Timeline

- **Total Implementation:** 15-20 days
- **Clipboard Feature:** 5-6 days
- **USB Feature:** 7-8 days
- **Integration & Testing:** 3-4 days
- **Documentation:** 2-3 days

---

## Success Metrics