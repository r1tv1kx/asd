---
name: Confidential Data Scanner System
overview: Build a multi-component system for scanning Windows files for confidential data (Aadhar, SSN, PAN cards), with a Go-based Windows service, Python analyzer backend, Node.js dashboard server, and Electron desktop UI.
todos:
  - id: python-analyzer
    content: Build Python Analyzer Server with Presidio + custom matchers
    status: completed
  - id: nodejs-api
    content: Build Node.js Dashboard Server with PostgreSQL integration
    status: completed
  - id: react-dashboard
    content: Build React Dashboard UI for multi-client monitoring
    status: completed
    dependencies:
      - nodejs-api
  - id: go-service
    content: Build Go Windows Service with scanning + text extraction
    status: completed
    dependencies:
      - python-analyzer
  - id: electron-ui
    content: Build Electron Desktop UI for local service monitoring
    status: completed
    dependencies:
      - go-service
  - id: integration-testing
    content: End-to-end testing and integration of all components
    status: completed
    dependencies:
      - python-analyzer
      - nodejs-api
      - react-dashboard
      - go-service
      - electron-ui
---

# Confidential Data Scanner System

## Architecture Overview

```mermaid
flowchart TB
    subgraph WindowsClient [Windows Client System]
        WinService[Windows Service Go]
        WinUI[Desktop UI Electron]
        LocalFiles[Local Files]
    end
    
    subgraph Backend [Backend Services]
        AnalyzerServer[Python Analyzer Server Presidio]
        DashboardAPI[Node.js Dashboard API]
        Database[(Database PostgreSQL)]
    end
    
    subgraph Web [Web Interface]
        Dashboard[React Dashboard]
    end
    
    LocalFiles -->|Scan & Extract| WinService
    WinService -->|Text Data| AnalyzerServer
    AnalyzerServer -->|Analysis Results| WinService
    WinService -->|Store Results| DashboardAPI
    WinService <-->|Local API| WinUI
    AnalyzerServer -->|Results| DashboardAPI
    DashboardAPI <-->|REST API| Dashboard
    DashboardAPI <-->|CRUD| Database
```



## Component Breakdown

### 1. Python Analyzer Server (Port 8000)

**Location:** `analyzer-server/`**Core Components:**

- **FastAPI** server for receiving text data from clients
- **Microsoft Presidio** for PII detection (SSN, generic patterns)
- **Custom regex matchers** for India-specific patterns:
- Aadhar Card: 12-digit format with optional spaces
- PAN Card: 5 letters + 4 digits + 1 letter format
- **REST API endpoints:**
- `POST /api/analyze` - Analyze text and return detected patterns
- `POST /api/analyze/batch` - Batch processing for multiple texts
- `GET /health` - Health check

**Key Files:**

- `main.py` - FastAPI app initialization
- `analyzer.py` - Presidio integration + custom matchers
- `models.py` - Pydantic models for request/response
- `patterns.py` - Custom regex patterns for Indian IDs
- `requirements.txt` - Python dependencies

**Dependencies:**

- `fastapi`, `uvicorn`, `presidio-analyzer`, `presidio-anonymizer`, `pydantic`

---

### 2. Node.js Dashboard Server (Port 3001)

**Location:** `dashboard-server/`**Core Components:**

- **Express.js** REST API server
- **PostgreSQL** database for storing scan results from multiple clients
- **Database schema:**
- `clients` - Registered client machines
- `scan_sessions` - Scanning sessions per client
- `detections` - Individual file detections with severity
- `files` - Scanned file metadata

**REST API Endpoints:**

- `GET /api/clients` - List all registered clients
- `GET /api/clients/:id/detections` - Get detections for a client
- `POST /api/detections` - Submit new detection results
- `GET /api/dashboard/stats` - Overall statistics
- `GET /api/dashboard/recent` - Recent detections across all clients

**Key Files:**

- `server.js` - Express server setup
- `routes/` - API route handlers
- `models/` - Database models (Sequelize ORM)
- `db/migrations/` - Database migrations
- `package.json` - Node.js dependencies

**Dependencies:**

- `express`, `pg`, `sequelize`, `cors`, `dotenv`

---

### 3. React Dashboard (Port 3000)

**Location:** `dashboard-ui/`**Core Components:**

- **React** + **TypeScript** for type safety
- **Material-UI** or **Ant Design** for quick UI components
- **Recharts** for data visualization

**Key Views:**

- **Overview Dashboard:** Total clients, total detections, severity breakdown
- **Clients List:** All registered Windows clients with last scan time
- **Detections Table:** Filterable list of all detections across clients
- **Client Detail:** Per-client view with file list and detection timeline

**Key Files:**

- `src/App.tsx` - Main app component with routing
- `src/pages/Dashboard.tsx` - Main dashboard view
- `src/pages/ClientDetail.tsx` - Per-client detail view
- `src/components/DetectionCard.tsx` - Detection display component
- `src/services/api.ts` - API client for dashboard server
- `package.json` - Node.js dependencies

**Dependencies:**

- `react`, `react-router-dom`, `@mui/material`, `recharts`, `axios`

---

### 4. Windows Service (Go)

**Location:** `windows-service/`**Core Components:**

- **Windows Service** using `golang.org/x/sys/windows/svc`
- **File Scanner Module:**
- Configurable directory scanning (recursive)
- File type filtering (.txt, .doc, .docx, .pdf)
- Concurrent file processing with worker pool
- **Text Extraction:**
- `.txt` - Direct read
- `.pdf` - Use `github.com/ledongthuc/pdf`
- `.doc/.docx` - Use `github.com/unidoc/unioffice`
- **API Communication:**
- HTTP client to Python Analyzer Server
- HTTP client to Node.js Dashboard Server
- Retry logic with exponential backoff
- **Local Tagging:**
- Windows file attributes for tagging
- Local SQLite database for storing detection metadata
- **Background Scheduling:**
- Initial full scan on service start
- Incremental scans every N hours (configurable)
- File system watcher for real-time monitoring

**Key Files:**

- `cmd/service/main.go` - Service entry point
- `internal/service/service.go` - Windows service implementation
- `internal/scanner/scanner.go` - File scanning logic
- `internal/extractor/extractor.go` - Text extraction from files
- `internal/analyzer/client.go` - HTTP client for analyzer server
- `internal/api/server.go` - Local REST API for desktop UI
- `internal/config/config.go` - Configuration management
- `internal/db/sqlite.go` - Local SQLite operations
- `go.mod` - Go dependencies

**Local REST API (Port 8080):**

- `GET /api/status` - Service status and scan progress
- `GET /api/detections` - Local detections list
- `GET /api/config` - Current configuration
- `PUT /api/config` - Update configuration
- `POST /api/scan/start` - Trigger manual scan
- `POST /api/scan/stop` - Stop ongoing scan

**Configuration:**

- Scan directories (default: Documents, Desktop, Downloads)
- File type filters
- Scan schedule interval
- Analyzer server URL
- Dashboard server URL

---

### 5. Desktop UI (Electron + React)

**Location:** `desktop-ui/`**Core Components:**

- **Electron** for desktop app shell
- **React** frontend communicating with local Windows service
- **Local-only** - No direct connection to backend servers

**Key Views:**

- **Status Page:** Service running status, last scan time, scan progress
- **Detections View:** List of flagged files with severity indicators
- File path, detection type (Aadhar/PAN/SSN), timestamp
- Action buttons: Open file location, View details
- **Settings Page:** 
- Configure scan directories
- Enable/disable file types
- Set scan frequency
- Server endpoints configuration
- **Scan Control:** Start/stop manual scan buttons

**Key Files:**

- `electron/main.js` - Electron main process
- `src/App.tsx` - React app component
- `src/pages/Status.tsx` - Status dashboard
- `src/pages/Detections.tsx` - Detections list
- `src/pages/Settings.tsx` - Configuration UI
- `src/services/serviceApi.ts` - API client for Windows service
- `package.json` - Dependencies

**Dependencies:**

- `electron`, `electron-builder`, `react`, `react-router-dom`, `@mui/material`

---

## Implementation Order

### Phase 1: Backend Foundation

1. **Python Analyzer Server** - Core analysis engine with Presidio
2. **Node.js Dashboard Server** - API + database setup
3. **React Dashboard** - Basic UI for viewing results

### Phase 2: Windows Client

4. **Go Windows Service** - File scanning, text extraction, API integration
5. **Electron Desktop UI** - Local UI for monitoring service

### Phase 3: Integration & Testing

6. End-to-end testing with all components
7. Build installers (Windows service MSI + Desktop UI installer)

---

## Pattern Detection Examples

**Aadhar Card (India):**

- Regex: `\b[2-9]{1}[0-9]{3}\s?[0-9]{4}\s?[0-9]{4}\b`
- Example: `1234 5678 9012`

**PAN Card (India):**

- Regex: `\b[A-Z]{5}[0-9]{4}[A-Z]{1}\b`
- Example: `ABCDE1234F`

**SSN (US):**

- Via Presidio's built-in recognizer
- Example: `123-45-6789`

---

## Database Schema (PostgreSQL)

```sql
-- Clients table
CREATE TABLE clients (
  id UUID PRIMARY KEY,
  hostname VARCHAR(255) NOT NULL,
  username VARCHAR(255),
  registered_at TIMESTAMP DEFAULT NOW(),
  last_seen TIMESTAMP
);

-- Scan sessions
CREATE TABLE scan_sessions (
  id UUID PRIMARY KEY,
  client_id UUID REFERENCES clients(id),
  started_at TIMESTAMP,
  completed_at TIMESTAMP,
  files_scanned INTEGER,
  detections_found INTEGER
);

-- Detections
CREATE TABLE detections (
  id UUID PRIMARY KEY,
  session_id UUID REFERENCES scan_sessions(id),
  client_id UUID REFERENCES clients(id),
  file_path TEXT NOT NULL,
  detection_type VARCHAR(50), -- 'AADHAR', 'PAN', 'SSN'
  matched_text VARCHAR(255), -- redacted/hashed
  confidence FLOAT,
  detected_at TIMESTAMP DEFAULT NOW()
);
```

---

## Security Considerations

1. **Data Privacy:** Never store actual confidential data, only detection metadata
2. **Text Redaction:** Hash or redact matched patterns before storing
3. **API Authentication:** Add JWT or API key authentication (future phase)
4. **TLS/HTTPS:** Use HTTPS for all API communications (production)
5. **Local Storage:** Encrypt local SQLite database in Windows service

---

## Configuration Files

**Windows Service Config (`config.yaml`):**

```yaml
scan:
  directories:
    - C:\Users\%USERNAME%\Documents
    - C:\Users\%USERNAME%\Desktop
    - C:\Users\%USERNAME%\Downloads
  file_types: [".txt", ".pdf", ".doc", ".docx"]
  interval_hours: 24
  
servers:
  analyzer_url: http://localhost:8000
  dashboard_url: http://localhost:3001
```

---

## Development Setup

1. **Prerequisites:** Go 1.21+, Python 3.10+, Node.js 18+, PostgreSQL 14+
2. **Clone repository** and navigate to each component directory