# Confidential Data Scanner System

A comprehensive system for scanning Windows files, clipboard, and USB devices for confidential data (PII) including Aadhar cards, PAN cards, SSN, credit cards, and more.

## Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           Windows Client System                              │
│  ┌─────────────────────┐         ┌─────────────────────┐                    │
│  │   Windows Service   │◄───────►│    Desktop UI       │                    │
│  │       (Go)          │  REST   │    (Electron)       │                    │
│  │                     │  :8080  │                     │                    │
│  │  • File Scanner     │         │  • Status View      │                    │
│  │  • Clipboard Monitor│         │  • Detections List  │                    │
│  │  • USB Monitor      │         │  • USB Devices      │                    │
│  │  • Text Extractor   │         │  • Settings         │                    │
│  │  • Local SQLite DB  │         │                     │                    │
│  └──────────┬──────────┘         └─────────────────────┘                    │
└─────────────┼───────────────────────────────────────────────────────────────┘
              │
              │ HTTP API
              ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                           Backend Services                                   │
│  ┌─────────────────────┐         ┌─────────────────────┐                    │
│  │   Analyzer Server   │         │   Dashboard Server  │                    │
│  │     (Python)        │         │     (Node.js)       │                    │
│  │     :8000           │         │     :3001           │                    │
│  │                     │         │                     │                    │
│  │  • Presidio PII     │────────►│  • Client Registry  │                    │
│  │  • Custom Patterns  │         │  • Scan Sessions    │                    │
│  │  • Aadhar/PAN/SSN   │         │  • USB Devices      │                    │
│  │                     │         │  • Clipboard Alerts │                    │
│  └─────────────────────┘         └──────────┬──────────┘                    │
└─────────────────────────────────────────────┼───────────────────────────────┘
                                              │
                                              │ REST API
                                              ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                           Web Dashboard                                      │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                    React Dashboard UI (:3000)                        │    │
│  │                                                                      │    │
│  │  • Multi-client Overview    • Detection Trends                      │    │
│  │  • Clipboard Detections     • USB Device Management                 │    │
│  │  • Scan Source Filtering    • Real-time Updates                     │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Components

| Component            | Technology                     | Port | Description                               |
| -------------------- | ------------------------------ | ---- | ----------------------------------------- |
| **Analyzer Server**  | Python + FastAPI + Presidio    | 8000 | PII detection engine with custom patterns |
| **Dashboard Server** | Node.js + Express + PostgreSQL | 3001 | Central API for multi-client management   |
| **Dashboard UI**     | React + TypeScript + MUI       | 3000 | Web dashboard for administrators          |
| **Windows Service**  | Go                             | 8080 | Local file scanner service                |
| **Desktop UI**       | Electron + React               | -    | Local monitoring application              |

## Supported Detection Types

### Indian IDs

- **Aadhar Card** - 12-digit UIDAI number (XXXX XXXX XXXX)
- **PAN Card** - 10-character alphanumeric (AAAAA9999A)
- **Indian Passport** - 1 letter + 7 digits
- **Voter ID (EPIC)** - 3 letters + 7 digits
- **Driving License** - State code + RTO code + Year + Serial

### US IDs

- **SSN** - Social Security Number (XXX-XX-XXXX)
- **US Passport** - 9 digits
- **US Driver License** - State-specific formats

### Financial

- **Credit Card** - Major card formats (Visa, Mastercard, Amex, etc.)
- **Bank Account** - US bank account numbers
- **IBAN** - International Bank Account Numbers

### Contact Information

- **Email Address**
- **Phone Number**
- **IP Address**

## Quick Start

### Prerequisites

- Python 3.10+
- Node.js 18+
- Go 1.21+
- PostgreSQL 14+

### 1. Start the Analyzer Server

```bash
cd analyzer-server

# Create virtual environment
python -m venv venv
venv\Scripts\activate  # Windows
# source venv/bin/activate  # Linux/Mac

# Install dependencies
pip install -r requirements.txt

# Download spaCy model
python -m spacy download en_core_web_lg

# Start server
python main.py
```

Server runs at http://localhost:8000

### 2. Start the Dashboard Server

```bash
cd dashboard-server

# Install dependencies
npm install

# Create PostgreSQL database
# psql -U postgres -c "CREATE DATABASE scanner_dashboard;"

# Start server
npm run dev
```

Server runs at http://localhost:3001

### 3. Start the Dashboard UI

```bash
cd dashboard-ui

# Install dependencies
npm install

# Start development server
npm start
```

Dashboard available at http://localhost:3000

### 4. Build and Run the Windows Service

```bash
cd windows-service

# Download dependencies
go mod download

# Build
go build -o scanner-service.exe ./cmd/service

# Run in interactive mode
./scanner-service.exe -interactive
```

Service API runs at http://localhost:8080

### 5. Start the Desktop UI

```bash
cd desktop-ui

# Install dependencies
npm install

# Start in development mode
npm start
```

## Configuration

### Windows Service (`windows-service/config.yaml`)

```yaml
scan:
  directories:
    - C:\Users\%USERNAME%\Documents
    - C:\Users\%USERNAME%\Desktop
    - C:\Users\%USERNAME%\Downloads
  file_types:
    - .txt
    - .pdf
    - .doc
    - .docx
  interval_hours: 24
  max_file_size_mb: 50
  worker_count: 4

clipboard:
  enabled: true
  check_interval_ms: 500 # How often to check clipboard
  min_text_length: 10 # Minimum text length to analyze
  ignore_duplicates: true # Skip already-seen content
  retention_hours: 24 # How long to keep clipboard history
  alert_on_detection: true # Show alerts when PII detected

usb:
  enabled: true
  auto_scan_on_insert: true # Scan USB drives when connected
  scan_hidden_files: false # Include hidden files in scan
  max_scan_size_gb: 32 # Skip drives larger than this
  block_on_detection: false # Block USB ejection if PII found
  whitelist_devices: [] # Device serials to skip scanning
  blacklist_devices: [] # Device serials to block
  scan_timeout_minutes: 30 # Maximum scan duration

servers:
  analyzer_url: http://localhost:8000
  dashboard_url: http://localhost:3001

api:
  port: 8080
```

### Dashboard Server (`.env`)

```env
DB_HOST=localhost
DB_PORT=5432
DB_NAME=scanner_dashboard
DB_USER=postgres
DB_PASSWORD=postgres
PORT=3001
```

## API Documentation

### Analyzer Server

- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

### Dashboard Server

- Health: `GET /health`
- Clients: `GET/POST /api/clients`
- Detections: `GET/POST /api/detections`
- Dashboard: `GET /api/dashboard/stats`

### Windows Service

- Status: `GET /api/status`
- Detections: `GET /api/detections`
- Config: `GET/PUT /api/config`
- Scan: `POST /api/scan/start`, `POST /api/scan/stop`
- Clipboard: `GET /api/clipboard/detections`, `GET /api/clipboard/status`
- USB: `GET /api/usb/devices`, `POST /api/usb/devices/:id/whitelist`

## Development

### Project Structure

```
service/
├── analyzer-server/       # Python FastAPI + Presidio
│   ├── main.py
│   ├── analyzer.py
│   ├── patterns.py
│   ├── models.py
│   └── requirements.txt
├── dashboard-server/      # Node.js Express API
│   ├── src/
│   │   ├── server.js
│   │   ├── routes/
│   │   └── models/
│   └── package.json
├── dashboard-ui/          # React Web Dashboard
│   ├── src/
│   │   ├── pages/
│   │   ├── components/
│   │   └── services/
│   └── package.json
├── windows-service/       # Go Windows Service
│   ├── cmd/service/
│   ├── internal/
│   │   ├── scanner/
│   │   ├── extractor/
│   │   ├── analyzer/
│   │   ├── clipboard/     # Clipboard monitoring
│   │   ├── usb/           # USB device monitoring
│   │   └── api/
│   └── go.mod
├── desktop-ui/            # Electron Desktop App
│   ├── electron/
│   ├── src/
│   └── package.json
└── README.md
```

## New Features: Clipboard & USB Monitoring

### Clipboard Monitoring

The system now monitors the Windows clipboard in real-time for sensitive data:

- **Real-time Detection**: Checks clipboard every 500ms (configurable)
- **Duplicate Detection**: Uses SHA-256 hashing to avoid re-analyzing same content
- **Source Tracking**: Captures which application copied the text
- **Privacy-First**: Only stores hashes and redacted previews, never actual clipboard content

### USB Device Monitoring

Automatically scans USB flash drives when connected:

- **Auto-Scan on Insert**: Triggers scan when USB device is connected
- **Device Tracking**: Records device serial, vendor, name, and connection history
- **Whitelist/Blacklist**: Configure trusted or blocked devices by serial number
- **Size Limits**: Skip scanning drives larger than configured limit
- **Scan Timeout**: Configurable maximum scan duration

## Security Considerations

1. **Data Privacy**: Actual PII values are never stored - only hashed references and redacted previews
2. **Clipboard Privacy**: Clipboard content is hashed immediately, original text is never persisted
3. **USB Device Tracking**: Device metadata is stored for audit purposes
4. **Local Storage**: Windows service uses SQLite with optional encryption
5. **Network**: All API communications should use HTTPS in production
6. **Authentication**: Add JWT/API key authentication for production deployments

## License

MIT License
