# Service Startup Guide

This guide explains how to start all services for the Confidential Data Scanner system.

## Quick Start

### Option 1: PowerShell Script (Recommended)

```powershell
.\start-services.ps1
```

### Option 2: Batch File (Double-click)

Double-click `start-services.bat` in Windows Explorer

### Option 3: With Options

```powershell
# Start with Desktop UI
.\start-services.ps1 -StartDesktopUI

# Skip Docker checks
.\start-services.ps1 -SkipDockerCheck

# Wait for services (keeps script running)
.\start-services.ps1 -WaitForServices
```

## Stopping Services

```powershell
.\stop-services.ps1
```

Or manually:

```powershell
# Find and stop processes
Get-Process | Where-Object {$_.ProcessName -like "*scanner*"} | Stop-Process -Force
```

## What Gets Started

### Docker Services (Already Running)

These should already be running via `docker-compose up -d`:

- **PostgreSQL** (port 5432)
- **Analyzer Server** (port 8000)
- **Dashboard API** (port 3001)
- **Dashboard UI** (port 3000)

### Manual Services (Started by Script)

- **Windows Service** (port 8080) - Go service for file scanning, clipboard/USB monitoring
- **Desktop UI** (optional) - Electron app for local monitoring

## Service URLs

After starting, access:

- **Web Dashboard**: http://localhost:3000
- **Windows Service API**: http://localhost:8080
- **Dashboard API**: http://localhost:3001
- **Analyzer Server**: http://localhost:8000

## Troubleshooting

### Service Won't Start

1. Check if port 8080 is already in use:

   ```powershell
   netstat -ano | findstr :8080
   ```

2. Check if service executable exists:

   ```powershell
   Test-Path windows-service\scanner-service.exe
   ```

3. Build the service if missing:
   ```powershell
   cd windows-service
   go build -o scanner-service.exe ./cmd/service
   ```

### Docker Services Not Running

Start Docker services first:

```powershell
docker-compose up -d
```

Check status:

```powershell
docker-compose ps
```

### Service Crashes

Check Windows Event Viewer or run service in console mode:

```powershell
cd windows-service
.\scanner-service.exe -interactive
```

## Process Management

The script saves process IDs to `.service-pids.txt` for easy stopping.

View running processes:

```powershell
Get-Process | Where-Object {$_.ProcessName -like "*scanner*"}
```

## Next Steps

1. **Start Services**: Run `.\start-services.ps1`
2. **Access Dashboard**: Open http://localhost:3000
3. **Test Clipboard**: Copy sensitive data to clipboard
4. **Test USB**: Insert USB device to test monitoring

## Script Options

- `-SkipDockerCheck`: Don't check Docker services
- `-StartDesktopUI`: Also start the Electron desktop app
- `-WaitForServices`: Keep script running (press Ctrl+C to stop all)

## Example Usage

```powershell
# Basic startup
.\start-services.ps1

# Full startup with Desktop UI
.\start-services.ps1 -StartDesktopUI -WaitForServices

# Quick startup (skip checks)
.\start-services.ps1 -SkipDockerCheck
```
