# PII Analyzer Server

A FastAPI-based server for detecting Personally Identifiable Information (PII) in text using Microsoft Presidio and custom recognizers for Indian ID documents.

## Features

- **Indian ID Detection**: Aadhar, PAN, Passport, Voter ID, Driving License
- **US ID Detection**: SSN, Passport
- **Financial Data**: Credit Card, Bank Account, IBAN
- **Contact Info**: Email, Phone Number, IP Address

## Setup

### Prerequisites

- Python 3.10+
- pip

### Installation

```bash
cd analyzer-server

# Create virtual environment
python -m venv venv

# Activate virtual environment
# Windows:
venv\Scripts\activate
# Linux/Mac:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Download spaCy model (required by Presidio)
python -m spacy download en_core_web_lg
```

### Running the Server

```bash
# Development mode with auto-reload
python main.py

# Or using uvicorn directly
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

The server will be available at `http://localhost:8000`

## API Endpoints

### Health Check

```
GET /health
```

### Analyze Text

```
POST /api/analyze
Content-Type: application/json

{
    "text": "My Aadhar number is 2345 6789 0123",
    "file_path": "optional/path/to/file.txt",
    "language": "en"
}
```

### Batch Analysis

```
POST /api/analyze/batch
Content-Type: application/json

{
    "items": [
        {"text": "Text 1...", "file_path": "file1.txt"},
        {"text": "Text 2...", "file_path": "file2.txt"}
    ]
}
```

## API Documentation

- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`

## Supported Patterns

| Entity Type | Pattern         | Example             |
| ----------- | --------------- | ------------------- |
| AADHAR      | XXXX XXXX XXXX  | 2345 6789 0123      |
| PAN         | AAAAA9999A      | ABCDE1234F          |
| US_SSN      | XXX-XX-XXXX     | 123-45-6789         |
| CREDIT_CARD | Various formats | 4111-1111-1111-1111 |
