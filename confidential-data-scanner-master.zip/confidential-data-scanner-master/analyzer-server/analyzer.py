"""Core analyzer module integrating Presidio with custom recognizers."""
import hashlib
from typing import List, Tuple

from presidio_analyzer import AnalyzerEngine, RecognizerResult
from presidio_anonymizer import AnonymizerEngine
from presidio_anonymizer.entities import OperatorConfig

from patterns import get_custom_recognizers
from models import Detection, AnalyzeResponse


class PIIAnalyzer:
    """
    PII Analyzer combining Microsoft Presidio with custom recognizers
    for Indian ID documents.
    """
    
    def __init__(self):
        """Initialize the analyzer with Presidio and custom recognizers."""
        # Initialize Presidio analyzer engine
        self.analyzer = AnalyzerEngine()
        
        # Add custom recognizers for Indian documents
        for recognizer in get_custom_recognizers():
            self.analyzer.registry.add_recognizer(recognizer)
        
        # Initialize anonymizer for redaction
        self.anonymizer = AnonymizerEngine()
        
        # Entity types we're interested in
        self.target_entities = [
            # Custom Indian entities
            "AADHAR",
            "PAN",
            "INDIAN_PASSPORT",
            "VOTER_ID",
            "DRIVING_LICENSE",
            # Built-in Presidio entities
            "US_SSN",
            "CREDIT_CARD",
            "EMAIL_ADDRESS",
            "PHONE_NUMBER",
            "US_BANK_NUMBER",
            "US_PASSPORT",
            "IBAN_CODE",
            "IP_ADDRESS",
        ]
    
    def get_loaded_analyzers(self) -> List[str]:
        """Return list of loaded analyzer/recognizer names."""
        recognizers = self.analyzer.registry.get_recognizers(
            language="en",
            all_fields=True
        )
        return [r.name for r in recognizers]
    
    def _redact_text(self, text: str) -> str:
        """
        Redact sensitive text by showing only first and last characters.
        Example: "123456789012" -> "1**********2"
        """
        if len(text) <= 2:
            return "*" * len(text)
        return text[0] + "*" * (len(text) - 2) + text[-1]
    
    def _hash_text(self, text: str) -> str:
        """Create a hash of the text for secure storage."""
        return hashlib.sha256(text.encode()).hexdigest()[:16]
    
    def analyze_text(
        self,
        text: str,
        file_path: str = None,
        language: str = "en"
    ) -> AnalyzeResponse:
        """
        Analyze text for PII and return detections.
        
        Args:
            text: The text content to analyze
            file_path: Optional file path for reference
            language: Language code (default: "en")
            
        Returns:
            AnalyzeResponse with list of detections
        """
        if not text or not text.strip():
            return AnalyzeResponse(
                file_path=file_path,
                detections=[],
                total_detections=0,
                has_pii=False
            )
        
        # Run Presidio analysis
        results: List[RecognizerResult] = self.analyzer.analyze(
            text=text,
            language=language,
            entities=self.target_entities,
        )
        
        # Convert results to Detection objects
        detections: List[Detection] = []
        for result in results:
            detected_text = text[result.start:result.end]
            detection = Detection(
                entity_type=result.entity_type,
                text=detected_text,
                start=result.start,
                end=result.end,
                confidence=result.score,
                redacted_text=self._redact_text(detected_text)
            )
            detections.append(detection)
        
        # Sort by position in text
        detections.sort(key=lambda d: d.start)
        
        return AnalyzeResponse(
            file_path=file_path,
            detections=detections,
            total_detections=len(detections),
            has_pii=len(detections) > 0
        )
    
    def analyze_batch(
        self,
        items: List[Tuple[str, str, str]]
    ) -> List[AnalyzeResponse]:
        """
        Analyze multiple texts in batch.
        
        Args:
            items: List of (text, file_path, language) tuples
            
        Returns:
            List of AnalyzeResponse objects
        """
        results = []
        for text, file_path, language in items:
            result = self.analyze_text(text, file_path, language)
            results.append(result)
        return results


# Global analyzer instance
_analyzer_instance: PIIAnalyzer = None


def get_analyzer() -> PIIAnalyzer:
    """Get or create the global analyzer instance."""
    global _analyzer_instance
    if _analyzer_instance is None:
        _analyzer_instance = PIIAnalyzer()
    return _analyzer_instance

