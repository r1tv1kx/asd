"""FastAPI server for PII analysis."""

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from models import (
    AnalyzeRequest,
    BatchAnalyzeRequest,
    AnalyzeResponse,
    BatchAnalyzeResponse,
    HealthResponse,
)
from analyzer import get_analyzer, PIIAnalyzer

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan context manager for startup/shutdown events."""
    # Startup: Initialize the analyzer
    logger.info("Initializing PII Analyzer...")
    analyzer = get_analyzer()
    loaded = analyzer.get_loaded_analyzers()
    logger.info(f"Loaded {len(loaded)} recognizers: {loaded[:5]}...")
    yield
    # Shutdown
    logger.info("Shutting down PII Analyzer server...")


# Create FastAPI app
app = FastAPI(
    title="PII Analyzer Server",
    description="Analyzes text for Personally Identifiable Information (PII) including Aadhar, PAN, SSN, and more.",
    version="1.0.0",
    lifespan=lifespan,
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, restrict this
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health", response_model=HealthResponse, tags=["Health"])
async def health_check():
    """
    Health check endpoint.

    Returns the service status and loaded analyzers.
    """
    analyzer = get_analyzer()
    return HealthResponse(
        status="healthy",
        version="1.0.0",
        analyzers_loaded=analyzer.get_loaded_analyzers()[
            :10
        ],  # Limit for response size
    )


@app.post("/api/analyze", response_model=AnalyzeResponse, tags=["Analysis"])
async def analyze_text(request: AnalyzeRequest):
    """
    Analyze text for PII.

    Scans the provided text for various types of personally identifiable
    information including:
    - Indian IDs: Aadhar, PAN, Passport, Voter ID, Driving License
    - US IDs: SSN, Passport
    - Financial: Credit Card, Bank Account, IBAN
    - Contact: Email, Phone Number, IP Address

    Returns a list of detections with entity type, position, and confidence score.
    """
    try:
        analyzer = get_analyzer()
        result = analyzer.analyze_text(
            text=request.text, file_path=request.file_path, language=request.language
        )
        logger.info(
            f"Analyzed text ({len(request.text)} chars): "
            f"found {result.total_detections} detections"
        )
        return result
    except Exception as e:
        logger.error(f"Error analyzing text: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/analyze/batch", response_model=BatchAnalyzeResponse, tags=["Analysis"])
async def analyze_batch(request: BatchAnalyzeRequest):
    """
    Analyze multiple texts in batch.

    Processes multiple text items in a single request for efficiency.
    Each item can have its own file path and language setting.

    Returns aggregated results including total files and files with PII detected.
    """
    try:
        analyzer = get_analyzer()

        # Prepare items for batch processing
        items = [(item.text, item.file_path, item.language) for item in request.items]

        results = analyzer.analyze_batch(items)
        files_with_pii = sum(1 for r in results if r.has_pii)

        logger.info(
            f"Batch analyzed {len(items)} items: " f"{files_with_pii} with PII detected"
        )

        return BatchAnalyzeResponse(
            results=results, total_files=len(results), files_with_pii=files_with_pii
        )
    except Exception as e:
        logger.error(f"Error in batch analysis: {e}")
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True, log_level="info")
