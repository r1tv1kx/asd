"""Pydantic models for request/response schemas."""
from typing import List, Optional
from pydantic import BaseModel, Field


class AnalyzeRequest(BaseModel):
    """Request model for text analysis."""
    text: str = Field(..., description="Text content to analyze for PII")
    file_path: Optional[str] = Field(None, description="Optional file path for reference")
    language: str = Field("en", description="Language code for analysis")


class BatchAnalyzeRequest(BaseModel):
    """Request model for batch text analysis."""
    items: List[AnalyzeRequest] = Field(..., description="List of texts to analyze")


class Detection(BaseModel):
    """Model representing a single PII detection."""
    entity_type: str = Field(..., description="Type of PII detected (AADHAR, PAN, SSN, etc.)")
    text: str = Field(..., description="The detected text (may be redacted)")
    start: int = Field(..., description="Start position in original text")
    end: int = Field(..., description="End position in original text")
    confidence: float = Field(..., description="Confidence score (0-1)")
    redacted_text: Optional[str] = Field(None, description="Redacted version of detected text")


class AnalyzeResponse(BaseModel):
    """Response model for text analysis."""
    file_path: Optional[str] = Field(None, description="File path if provided in request")
    detections: List[Detection] = Field(default_factory=list, description="List of PII detections")
    total_detections: int = Field(0, description="Total number of detections found")
    has_pii: bool = Field(False, description="Whether any PII was detected")


class BatchAnalyzeResponse(BaseModel):
    """Response model for batch text analysis."""
    results: List[AnalyzeResponse] = Field(default_factory=list, description="Analysis results")
    total_files: int = Field(0, description="Total files analyzed")
    files_with_pii: int = Field(0, description="Number of files with PII detected")


class HealthResponse(BaseModel):
    """Response model for health check."""
    status: str = Field("healthy", description="Service health status")
    version: str = Field("1.0.0", description="API version")
    analyzers_loaded: List[str] = Field(default_factory=list, description="Loaded analyzer types")

