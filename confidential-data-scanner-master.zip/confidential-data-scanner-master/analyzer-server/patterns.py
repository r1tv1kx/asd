"""Custom regex patterns for Indian ID documents and other PII."""

from presidio_analyzer import Pattern, PatternRecognizer


class AadharRecognizer(PatternRecognizer):
    """
    Recognizer for Indian Aadhar Card numbers.

    Aadhar is a 12-digit unique identification number issued by UIDAI.
    Format: XXXX XXXX XXXX or XXXX-XXXX-XXXX or XXXXXXXXXXXX
    First digit cannot be 0 or 1.
    """

    PATTERNS = [
        Pattern(
            "Aadhar (with spaces)",
            r"\b[2-9][0-9]{3}\s[0-9]{4}\s[0-9]{4}\b",
            0.85,
        ),
        Pattern(
            "Aadhar (with dashes)",
            r"\b[2-9][0-9]{3}-[0-9]{4}-[0-9]{4}\b",
            0.85,
        ),
        Pattern(
            "Aadhar (continuous)",
            r"\b[2-9][0-9]{11}\b",
            0.6,  # Lower confidence for continuous as it could be other numbers
        ),
    ]

    CONTEXT = [
        "aadhar",
        "aadhaar",
        "uid",
        "uidai",
        "unique identification",
        "identity",
        "आधार",
        "enrollment",
    ]

    def __init__(self):
        super().__init__(
            supported_entity="AADHAR",
            patterns=self.PATTERNS,
            context=self.CONTEXT,
            supported_language="en",
        )


class PANRecognizer(PatternRecognizer):
    """
    Recognizer for Indian PAN (Permanent Account Number) Card.

    PAN is a 10-character alphanumeric identifier.
    Format: AAAAA9999A
    - First 5 characters: Letters (A-Z)
    - Next 4 characters: Numbers (0-9)
    - Last character: Letter (A-Z)

    The fourth character indicates the type of holder:
    - P: Individual
    - C: Company
    - H: HUF
    - F: Firm
    - A: AOP
    - T: Trust
    - B: BOI
    - L: Local Authority
    - J: Artificial Juridical Person
    - G: Government
    """

    PATTERNS = [
        Pattern(
            "PAN Card",
            r"\b[A-Z]{3}[ABCFGHLJPT][A-Z][0-9]{4}[A-Z]\b",
            0.85,
        ),
        Pattern(
            "PAN Card (generic)",
            r"\b[A-Z]{5}[0-9]{4}[A-Z]\b",
            0.6,  # Lower confidence for generic pattern
        ),
        Pattern(
            "PAN Card (followed by lowercase)",
            r"\b[A-Z]{3}[ABCFGHLJPT][A-Z][0-9]{4}[A-Z](?=[a-z])",
            0.75,  # PAN followed by lowercase letter (typo/concatenation)
        ),
        Pattern(
            "PAN Card (generic followed by lowercase)",
            r"\b[A-Z]{5}[0-9]{4}[A-Z](?=[a-z])",
            0.5,  # Generic PAN followed by lowercase
        ),
    ]

    CONTEXT = [
        "pan",
        "permanent account number",
        "income tax",
        "tax",
        "पैन",
        "it department",
        "taxation",
    ]

    def __init__(self):
        super().__init__(
            supported_entity="PAN",
            patterns=self.PATTERNS,
            context=self.CONTEXT,
            supported_language="en",
        )


class IndianPassportRecognizer(PatternRecognizer):
    """
    Recognizer for Indian Passport numbers.

    Format: A1234567 (1 letter followed by 7 digits)
    The letter indicates the passport office of issue.
    """

    PATTERNS = [
        Pattern(
            "Indian Passport",
            r"\b[A-Z][0-9]{7}\b",
            0.5,  # Lower confidence as format is generic
        ),
    ]

    CONTEXT = [
        "passport",
        "travel document",
        "पासपोर्ट",
        "visa",
        "immigration",
        "passport number",
        "passport no",
    ]

    def __init__(self):
        super().__init__(
            supported_entity="INDIAN_PASSPORT",
            patterns=self.PATTERNS,
            context=self.CONTEXT,
            supported_language="en",
        )


class IndianVoterIDRecognizer(PatternRecognizer):
    """
    Recognizer for Indian Voter ID (EPIC) numbers.

    Format: ABC1234567 (3 letters followed by 7 digits)
    """

    PATTERNS = [
        Pattern(
            "Voter ID",
            r"\b[A-Z]{3}[0-9]{7}\b",
            0.6,
        ),
    ]

    CONTEXT = [
        "voter",
        "voter id",
        "epic",
        "election",
        "electoral",
        "मतदाता",
        "election commission",
    ]

    def __init__(self):
        super().__init__(
            supported_entity="VOTER_ID",
            patterns=self.PATTERNS,
            context=self.CONTEXT,
            supported_language="en",
        )


class IndianDrivingLicenseRecognizer(PatternRecognizer):
    """
    Recognizer for Indian Driving License numbers.

    Format varies by state but typically:
    - State code (2 letters) + RTO code (2 digits) + Year (4 digits) + Serial (7 digits)
    - Example: DL01 20190000001
    """

    PATTERNS = [
        Pattern(
            "Driving License (with spaces)",
            r"\b[A-Z]{2}[0-9]{2}\s?[0-9]{4}[0-9]{7}\b",
            0.7,
        ),
        Pattern(
            "Driving License (with dash)",
            r"\b[A-Z]{2}-[0-9]{2}-[0-9]{4}-[0-9]{7}\b",
            0.8,
        ),
    ]

    CONTEXT = [
        "driving",
        "license",
        "licence",
        "dl",
        "driver",
        "ड्राइविंग",
        "लाइसेंस",
        "rto",
        "motor vehicle",
    ]

    def __init__(self):
        super().__init__(
            supported_entity="DRIVING_LICENSE",
            patterns=self.PATTERNS,
            context=self.CONTEXT,
            supported_language="en",
        )


def get_custom_recognizers():
    """Return a list of all custom recognizers for Indian documents."""
    return [
        AadharRecognizer(),
        PANRecognizer(),
        IndianPassportRecognizer(),
        IndianVoterIDRecognizer(),
        IndianDrivingLicenseRecognizer(),
    ]
