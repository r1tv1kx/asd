# Dashboard Server

Node.js REST API server for the Confidential Data Scanner Dashboard.

## Features

- Client registration and management
- Scan session tracking
- Detection storage and querying
- Dashboard statistics and trends
- High-risk file/client identification

## Setup

### Prerequisites

- Node.js 18+
- PostgreSQL 14+

### Installation

```bash
cd dashboard-server

# Install dependencies
npm install

# Copy environment file
copy .env.example .env  # Windows
# cp .env.example .env  # Linux/Mac

# Edit .env with your database credentials
```

### Database Setup

```bash
# Create PostgreSQL database
psql -U postgres -c "CREATE DATABASE scanner_dashboard;"

# Run the server (it will auto-create tables)
npm run dev
```

### Running the Server

```bash
# Development mode with auto-reload
npm run dev

# Production mode
npm start
```

The server will be available at `http://localhost:3001`

## API Endpoints

### Health
- `GET /health` - Health check

### Clients
- `GET /api/clients` - List all clients
- `GET /api/clients/:id` - Get single client
- `POST /api/clients/register` - Register a new client
- `PUT /api/clients/:id/status` - Update client status
- `GET /api/clients/:id/detections` - Get detections for a client

### Sessions
- `GET /api/sessions` - List scan sessions
- `GET /api/sessions/:id` - Get session details
- `POST /api/sessions` - Create new scan session
- `PUT /api/sessions/:id` - Update session status

### Detections
- `GET /api/detections` - List all detections
- `POST /api/detections` - Submit new detections
- `PUT /api/detections/:id/resolve` - Mark detection as resolved
- `PUT /api/detections/bulk-resolve` - Bulk resolve detections
- `GET /api/detections/stats` - Get detection statistics

### Dashboard
- `GET /api/dashboard/stats` - Overall statistics
- `GET /api/dashboard/recent` - Recent activity
- `GET /api/dashboard/trends` - Detection trends over time
- `GET /api/dashboard/high-risk` - High-risk files and clients

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| PORT | Server port | 3001 |
| DB_HOST | PostgreSQL host | localhost |
| DB_PORT | PostgreSQL port | 5432 |
| DB_NAME | Database name | scanner_dashboard |
| DB_USER | Database user | postgres |
| DB_PASSWORD | Database password | postgres |
| NODE_ENV | Environment | development |

