const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const ClipboardDetection = sequelize.define('ClipboardDetection', {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    clientId: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'clients',
        key: 'id',
      },
    },
    contentHash: {
      type: DataTypes.STRING(64),
      allowNull: false,
      comment: 'SHA-256 hash of clipboard content',
    },
    detectionType: {
      type: DataTypes.STRING(50),
      allowNull: false,
      comment: 'Type of PII detected: AADHAR, PAN, SSN, etc.',
    },
    redactedPreview: {
      type: DataTypes.STRING(255),
      allowNull: true,
      comment: 'Redacted preview of matched text',
    },
    confidence: {
      type: DataTypes.FLOAT,
      allowNull: true,
      validate: {
        min: 0,
        max: 1,
      },
    },
    severity: {
      type: DataTypes.ENUM('low', 'medium', 'high', 'critical'),
      defaultValue: 'medium',
    },
    sourceApp: {
      type: DataTypes.STRING(255),
      allowNull: true,
      comment: 'Application from which content was copied',
    },
    detectedAt: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
    isResolved: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
    },
  }, {
    tableName: 'clipboard_detections',
    timestamps: true,
    indexes: [
      {
        fields: ['clientId'],
      },
      {
        fields: ['detectionType'],
      },
      {
        fields: ['severity'],
      },
      {
        fields: ['detectedAt'],
      },
    ],
  });

  return ClipboardDetection;
};

