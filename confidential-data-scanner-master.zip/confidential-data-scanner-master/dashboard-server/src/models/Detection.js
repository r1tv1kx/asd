const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Detection = sequelize.define('Detection', {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    clientId: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'clients',
        key: 'id',
      },
    },
    sessionId: {
      type: DataTypes.UUID,
      allowNull: true,
      references: {
        model: 'scan_sessions',
        key: 'id',
      },
    },
    filePath: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    fileName: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    fileType: {
      type: DataTypes.STRING(50),
      allowNull: true,
    },
    fileSize: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    detectionType: {
      type: DataTypes.STRING(50),
      allowNull: false,
      comment: 'Type of PII detected: AADHAR, PAN, SSN, etc.',
    },
    matchedTextHash: {
      type: DataTypes.STRING(64),
      allowNull: true,
      comment: 'SHA-256 hash of matched text (never store actual PII)',
    },
    redactedPreview: {
      type: DataTypes.STRING(255),
      allowNull: true,
      comment: 'Redacted preview of matched text',
    },
    confidence: {
      type: DataTypes.FLOAT,
      allowNull: true,
      validate: {
        min: 0,
        max: 1,
      },
    },
    severity: {
      type: DataTypes.ENUM('low', 'medium', 'high', 'critical'),
      defaultValue: 'medium',
    },
    position: {
      type: DataTypes.JSONB,
      allowNull: true,
      comment: 'Start and end position in file',
    },
    detectedAt: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
    isResolved: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
    },
    resolvedAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    resolvedBy: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    scanSource: {
      type: DataTypes.ENUM('filesystem', 'clipboard', 'usb'),
      defaultValue: 'filesystem',
      comment: 'Source of the detection: filesystem, clipboard, or usb',
    },
    usbDeviceId: {
      type: DataTypes.UUID,
      allowNull: true,
      comment: 'Reference to USB device if scan source is usb',
    },
  }, {
    tableName: 'detections',
    timestamps: true,
    indexes: [
      {
        fields: ['clientId'],
      },
      {
        fields: ['sessionId'],
      },
      {
        fields: ['detectionType'],
      },
      {
        fields: ['severity'],
      },
      {
        fields: ['detectedAt'],
      },
      {
        fields: ['isResolved'],
      },
      {
        fields: ['scanSource'],
      },
    ],
  });

  return Detection;
};

