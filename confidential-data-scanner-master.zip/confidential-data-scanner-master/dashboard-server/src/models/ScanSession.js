const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const ScanSession = sequelize.define('ScanSession', {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    clientId: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'clients',
        key: 'id',
      },
    },
    startedAt: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
    completedAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    status: {
      type: DataTypes.ENUM('running', 'completed', 'failed', 'cancelled'),
      defaultValue: 'running',
    },
    filesScanned: {
      type: DataTypes.INTEGER,
      defaultValue: 0,
    },
    detectionsFound: {
      type: DataTypes.INTEGER,
      defaultValue: 0,
    },
    scanType: {
      type: DataTypes.ENUM('full', 'incremental', 'manual'),
      defaultValue: 'full',
    },
    scanDirectories: {
      type: DataTypes.ARRAY(DataTypes.STRING),
      allowNull: true,
    },
    errorMessage: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
  }, {
    tableName: 'scan_sessions',
    timestamps: true,
    indexes: [
      {
        fields: ['clientId'],
      },
      {
        fields: ['status'],
      },
      {
        fields: ['startedAt'],
      },
    ],
  });

  return ScanSession;
};

