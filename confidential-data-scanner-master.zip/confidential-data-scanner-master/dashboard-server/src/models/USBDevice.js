const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const USBDevice = sequelize.define('USBDevice', {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    clientId: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'clients',
        key: 'id',
      },
    },
    deviceSerial: {
      type: DataTypes.STRING(255),
      allowNull: true,
      comment: 'Serial number of the USB device',
    },
    deviceVendor: {
      type: DataTypes.STRING(255),
      allowNull: true,
      comment: 'Vendor/manufacturer of the USB device',
    },
    deviceName: {
      type: DataTypes.STRING(255),
      allowNull: true,
      comment: 'Name/label of the USB device',
    },
    driveLetter: {
      type: DataTypes.STRING(10),
      allowNull: true,
      comment: 'Current drive letter (if connected)',
    },
    firstSeen: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
    lastSeen: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
    isWhitelisted: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
    },
    isBlacklisted: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
    },
    totalScans: {
      type: DataTypes.INTEGER,
      defaultValue: 0,
    },
    totalDetections: {
      type: DataTypes.INTEGER,
      defaultValue: 0,
    },
  }, {
    tableName: 'usb_devices',
    timestamps: true,
    indexes: [
      {
        fields: ['clientId'],
      },
      {
        fields: ['deviceSerial'],
      },
      {
        fields: ['lastSeen'],
      },
    ],
  });

  return USBDevice;
};

