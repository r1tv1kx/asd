const { Sequelize } = require('sequelize');
const config = require('../config/database');

const env = process.env.NODE_ENV || 'development';
const dbConfig = config[env];

const sequelize = new Sequelize(
  dbConfig.database,
  dbConfig.username,
  dbConfig.password,
  {
    host: dbConfig.host,
    port: dbConfig.port,
    dialect: dbConfig.dialect,
    logging: dbConfig.logging,
    pool: dbConfig.pool,
  }
);

// Import models
const Client = require('./Client')(sequelize);
const ScanSession = require('./ScanSession')(sequelize);
const Detection = require('./Detection')(sequelize);
const USBDevice = require('./USBDevice')(sequelize);
const ClipboardDetection = require('./ClipboardDetection')(sequelize);

// Define associations
Client.hasMany(ScanSession, { foreignKey: 'clientId', as: 'scanSessions' });
ScanSession.belongsTo(Client, { foreignKey: 'clientId', as: 'client' });

Client.hasMany(Detection, { foreignKey: 'clientId', as: 'detections' });
Detection.belongsTo(Client, { foreignKey: 'clientId', as: 'client' });

ScanSession.hasMany(Detection, { foreignKey: 'sessionId', as: 'detections' });
Detection.belongsTo(ScanSession, { foreignKey: 'sessionId', as: 'session' });

// USB Device associations
Client.hasMany(USBDevice, { foreignKey: 'clientId', as: 'usbDevices' });
USBDevice.belongsTo(Client, { foreignKey: 'clientId', as: 'client' });

// Clipboard Detection associations
Client.hasMany(ClipboardDetection, { foreignKey: 'clientId', as: 'clipboardDetections' });
ClipboardDetection.belongsTo(Client, { foreignKey: 'clientId', as: 'client' });

module.exports = {
  sequelize,
  Sequelize,
  Client,
  ScanSession,
  Detection,
  USBDevice,
  ClipboardDetection,
};

