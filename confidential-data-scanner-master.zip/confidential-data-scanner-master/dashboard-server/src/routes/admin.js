const express = require('express');
const router = express.Router();
const { Client, ScanSession, Detection, USBDevice, ClipboardDetection, sequelize } = require('../models');

// DELETE /api/admin/clear-all-data - Clear all scan data for testing
// Note: Client registration data is preserved
router.delete('/clear-all-data', async (req, res) => {
  try {
    // Use a transaction to ensure all deletes succeed or fail together
    const transaction = await sequelize.transaction();

    try {
      // Delete all clipboard detections first (due to foreign key constraints)
      const clipboardDetectionsDeleted = await ClipboardDetection.destroy({
        where: {},
        transaction,
      });

      // Delete all USB devices
      const usbDevicesDeleted = await USBDevice.destroy({
        where: {},
        transaction,
      });

      // Delete all detections (due to foreign key constraints)
      const detectionsDeleted = await Detection.destroy({
        where: {},
        transaction,
      });

      // Delete all scan sessions
      const sessionsDeleted = await ScanSession.destroy({
        where: {},
        transaction,
      });

      // IMPORTANT: Client registration data is NOT deleted to preserve client registrations
      // Clients table is explicitly excluded from deletion to maintain client identity
      // and registration information (hostname, IP, status, etc.)
      // DO NOT add Client.destroy() here - client registrations must be preserved

      await transaction.commit();

      console.log(`Cleared all data: ${detectionsDeleted} detections, ${sessionsDeleted} sessions, ${clipboardDetectionsDeleted} clipboard detections, ${usbDevicesDeleted} USB devices. Client registrations preserved.`);

      res.json({
        message: 'All scan data cleared successfully. Client registrations preserved.',
        deleted: {
          detections: detectionsDeleted,
          sessions: sessionsDeleted,
          clipboardDetections: clipboardDetectionsDeleted,
          usbDevices: usbDevicesDeleted,
        },
        preserved: {
          clients: 'Client registration data preserved',
        },
      });
    } catch (error) {
      await transaction.rollback();
      throw error;
    }
  } catch (error) {
    console.error('Error clearing all data:', error);
    res.status(500).json({ error: 'Failed to clear data' });
  }
});

// GET /api/admin/stats - Get database statistics
router.get('/stats', async (req, res) => {
  try {
    const clientCount = await Client.count();
    const sessionCount = await ScanSession.count();
    const detectionCount = await Detection.count();

    res.json({
      clients: clientCount,
      sessions: sessionCount,
      detections: detectionCount,
    });
  } catch (error) {
    console.error('Error getting admin stats:', error);
    res.status(500).json({ error: 'Failed to get stats' });
  }
});

module.exports = router;


