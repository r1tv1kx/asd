const express = require('express');
const router = express.Router();
const { Client, ScanSession, Detection, sequelize } = require('../models');
const { Op } = require('sequelize');

// GET /api/analytics/trends - Get detailed time-series data with breakdowns
router.get('/trends', async (req, res) => {
  try {
    const {
      startDate,
      endDate,
      groupBy = 'day', // day, week, month
      breakdown, // severity, type, source, client
    } = req.query;

    const start = startDate ? new Date(startDate) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const end = endDate ? new Date(endDate) : new Date();

    // Build the date grouping function based on groupBy parameter
    let dateGroup;
    switch (groupBy) {
      case 'week':
        dateGroup = sequelize.fn('DATE_TRUNC', 'week', sequelize.col('detectedAt'));
        break;
      case 'month':
        dateGroup = sequelize.fn('DATE_TRUNC', 'month', sequelize.col('detectedAt'));
        break;
      default:
        dateGroup = sequelize.fn('DATE', sequelize.col('detectedAt'));
    }

    let attributes = [
      [dateGroup, 'date'],
      [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
    ];

    let group = [dateGroup];

    // Add breakdown field if specified
    if (breakdown) {
      switch (breakdown) {
        case 'severity':
          attributes.push('severity');
          group.push('severity');
          break;
        case 'type':
          attributes.push('detectionType');
          group.push('detectionType');
          break;
        case 'source':
          attributes.push('scanSource');
          group.push('scanSource');
          break;
        case 'client':
          attributes.push('clientId');
          group.push('clientId');
          break;
      }
    }

    const trends = await Detection.findAll({
      where: {
        detectedAt: {
          [Op.between]: [start, end],
        },
      },
      attributes,
      group,
      order: [[dateGroup, 'ASC']],
      raw: true,
    });

    res.json({ trends, startDate: start, endDate: end, groupBy, breakdown });
  } catch (error) {
    console.error('Error fetching analytics trends:', error);
    res.status(500).json({ error: 'Failed to fetch analytics trends' });
  }
});

// GET /api/analytics/drilldown - Get drill-down data for charts
router.get('/drilldown', async (req, res) => {
  try {
    const {
      dimension = 'type', // type, severity, client, source
      level = '1',
      parentId,
      startDate,
      endDate,
    } = req.query;

    const start = startDate ? new Date(startDate) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const end = endDate ? new Date(endDate) : new Date();

    const where = {
      detectedAt: {
        [Op.between]: [start, end],
      },
    };

    let groupField;
    switch (dimension) {
      case 'severity':
        groupField = 'severity';
        break;
      case 'client':
        groupField = 'clientId';
        break;
      case 'source':
        groupField = 'scanSource';
        break;
      default:
        groupField = 'detectionType';
    }

    // If level 2 or higher, filter by parent
    if (parseInt(level) > 1 && parentId) {
      if (dimension === 'type') {
        // For type, parentId would be a category - map it back to types
        const categoryMap = {
          identity: ['AADHAR', 'PAN', 'US_SSN', 'INDIAN_PASSPORT', 'VOTER_ID', 'DRIVING_LICENSE', 'PERSON'],
          financial: ['CREDIT_CARD', 'IBAN', 'BANK_ACCOUNT'],
          contact: ['EMAIL_ADDRESS', 'PHONE_NUMBER', 'IP_ADDRESS', 'URL'],
        };
        if (categoryMap[parentId]) {
          where.detectionType = { [Op.in]: categoryMap[parentId] };
        }
      } else {
        where[groupField] = parentId;
      }
    }

    const data = await Detection.findAll({
      where,
      attributes: [
        groupField,
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
      ],
      group: [groupField],
      order: [[sequelize.fn('COUNT', sequelize.col('id')), 'DESC']],
      raw: true,
    });

    // Format response
    const formattedData = data.map((item) => ({
      id: item[groupField] || 'unknown',
      name: item[groupField] || 'Unknown',
      value: parseInt(item.count),
    }));

    res.json({
      data: formattedData,
      dimension,
      level: parseInt(level),
      parentId,
    });
  } catch (error) {
    console.error('Error fetching drilldown data:', error);
    res.status(500).json({ error: 'Failed to fetch drilldown data' });
  }
});

// GET /api/analytics/heatmap - Get calendar heatmap data
router.get('/heatmap', async (req, res) => {
  try {
    const {
      year = new Date().getFullYear(),
      metric = 'detections', // detections, files, critical
    } = req.query;

    const startOfYear = new Date(parseInt(year), 0, 1);
    const endOfYear = new Date(parseInt(year), 11, 31, 23, 59, 59);

    let where = {
      detectedAt: {
        [Op.between]: [startOfYear, endOfYear],
      },
    };

    // For critical metric, only count critical severity
    if (metric === 'critical') {
      where.severity = 'critical';
    }

    const dailyCounts = await Detection.findAll({
      where,
      attributes: [
        [sequelize.fn('DATE', sequelize.col('detectedAt')), 'date'],
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
      ],
      group: [sequelize.fn('DATE', sequelize.col('detectedAt'))],
      order: [[sequelize.fn('DATE', sequelize.col('detectedAt')), 'ASC']],
      raw: true,
    });

    // Format dates to YYYY-MM-DD
    const heatmapData = dailyCounts.map((item) => ({
      date: item.date,
      value: parseInt(item.count),
    }));

    res.json({
      data: heatmapData,
      year: parseInt(year),
      metric,
    });
  } catch (error) {
    console.error('Error fetching heatmap data:', error);
    res.status(500).json({ error: 'Failed to fetch heatmap data' });
  }
});

// GET /api/analytics/compare - Compare two time periods
router.get('/compare', async (req, res) => {
  try {
    const {
      currentStart,
      currentEnd,
      compareStart,
      compareEnd,
    } = req.query;

    if (!currentStart || !currentEnd || !compareStart || !compareEnd) {
      return res.status(400).json({
        error: 'All date parameters are required: currentStart, currentEnd, compareStart, compareEnd',
      });
    }

    const getCounts = async (start, end) => {
      const where = {
        detectedAt: {
          [Op.between]: [new Date(start), new Date(end)],
        },
      };

      const [total, bySeverity, byType] = await Promise.all([
        Detection.count({ where }),
        Detection.findAll({
          where,
          attributes: ['severity', [sequelize.fn('COUNT', sequelize.col('id')), 'count']],
          group: ['severity'],
          raw: true,
        }),
        Detection.findAll({
          where,
          attributes: ['detectionType', [sequelize.fn('COUNT', sequelize.col('id')), 'count']],
          group: ['detectionType'],
          order: [[sequelize.fn('COUNT', sequelize.col('id')), 'DESC']],
          limit: 10,
          raw: true,
        }),
      ]);

      return {
        total,
        bySeverity: bySeverity.reduce((acc, item) => {
          acc[item.severity] = parseInt(item.count);
          return acc;
        }, {}),
        byType,
      };
    };

    const [currentPeriod, comparePeriod] = await Promise.all([
      getCounts(currentStart, currentEnd),
      getCounts(compareStart, compareEnd),
    ]);

    // Calculate changes
    const changes = {
      total: comparePeriod.total > 0
        ? ((currentPeriod.total - comparePeriod.total) / comparePeriod.total) * 100
        : 0,
      bySeverity: {},
    };

    ['critical', 'high', 'medium', 'low'].forEach((severity) => {
      const current = currentPeriod.bySeverity[severity] || 0;
      const compare = comparePeriod.bySeverity[severity] || 0;
      changes.bySeverity[severity] = compare > 0
        ? ((current - compare) / compare) * 100
        : 0;
    });

    res.json({
      current: currentPeriod,
      compare: comparePeriod,
      changes,
      periods: {
        current: { start: currentStart, end: currentEnd },
        compare: { start: compareStart, end: compareEnd },
      },
    });
  } catch (error) {
    console.error('Error fetching comparison data:', error);
    res.status(500).json({ error: 'Failed to fetch comparison data' });
  }
});

// GET /api/analytics/summary - Get summary statistics
router.get('/summary', async (req, res) => {
  try {
    const { days = 30 } = req.query;
    const startDate = new Date(Date.now() - parseInt(days) * 24 * 60 * 60 * 1000);

    const where = {
      detectedAt: {
        [Op.gte]: startDate,
      },
    };

    const [
      totalDetections,
      unresolvedDetections,
      criticalDetections,
      bySeverity,
      byType,
      bySource,
      dailyAverage,
    ] = await Promise.all([
      Detection.count({ where }),
      Detection.count({ where: { ...where, isResolved: false } }),
      Detection.count({ where: { ...where, severity: 'critical' } }),
      Detection.findAll({
        where,
        attributes: ['severity', [sequelize.fn('COUNT', sequelize.col('id')), 'count']],
        group: ['severity'],
        raw: true,
      }),
      Detection.findAll({
        where,
        attributes: ['detectionType', [sequelize.fn('COUNT', sequelize.col('id')), 'count']],
        group: ['detectionType'],
        order: [[sequelize.fn('COUNT', sequelize.col('id')), 'DESC']],
        limit: 10,
        raw: true,
      }),
      Detection.findAll({
        where,
        attributes: ['scanSource', [sequelize.fn('COUNT', sequelize.col('id')), 'count']],
        group: ['scanSource'],
        raw: true,
      }),
      Detection.findOne({
        where,
        attributes: [[sequelize.fn('COUNT', sequelize.col('id')), 'total']],
        raw: true,
      }),
    ]);

    res.json({
      period: {
        days: parseInt(days),
        startDate,
        endDate: new Date(),
      },
      totals: {
        detections: totalDetections,
        unresolved: unresolvedDetections,
        critical: criticalDetections,
        dailyAverage: Math.round(totalDetections / parseInt(days)),
      },
      bySeverity: bySeverity.reduce((acc, item) => {
        acc[item.severity] = parseInt(item.count);
        return acc;
      }, {}),
      byType: byType.map((item) => ({
        type: item.detectionType,
        count: parseInt(item.count),
      })),
      bySource: bySource.reduce((acc, item) => {
        acc[item.scanSource || 'filesystem'] = parseInt(item.count);
        return acc;
      }, {}),
    });
  } catch (error) {
    console.error('Error fetching analytics summary:', error);
    res.status(500).json({ error: 'Failed to fetch analytics summary' });
  }
});

module.exports = router;

