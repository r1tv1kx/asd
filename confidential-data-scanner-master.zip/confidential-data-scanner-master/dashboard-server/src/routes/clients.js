const express = require('express');
const router = express.Router();
const { Client, ScanSession, Detection } = require('../models');
const { Op } = require('sequelize');
const axios = require('axios');

// GET /api/clients - List all clients
router.get('/', async (req, res) => {
  try {
    const { status, search, limit = 50, offset = 0 } = req.query;
    
    const where = {};
    if (status) {
      where.status = status;
    }
    if (search) {
      where[Op.or] = [
        { hostname: { [Op.iLike]: `%${search}%` } },
        { username: { [Op.iLike]: `%${search}%` } },
      ];
    }

    const clients = await Client.findAndCountAll({
      where,
      limit: parseInt(limit),
      offset: parseInt(offset),
      order: [['lastSeen', 'DESC']],
      include: [
        {
          model: ScanSession,
          as: 'scanSessions',
          limit: 1,
          order: [['startedAt', 'DESC']],
          attributes: ['id', 'status', 'startedAt', 'completedAt', 'filesScanned', 'detectionsFound'],
        },
      ],
    });

    res.json({
      clients: clients.rows,
      total: clients.count,
      limit: parseInt(limit),
      offset: parseInt(offset),
    });
  } catch (error) {
    console.error('Error fetching clients:', error);
    res.status(500).json({ error: 'Failed to fetch clients' });
  }
});

// GET /api/clients/:id - Get single client
router.get('/:id', async (req, res) => {
  try {
    const client = await Client.findByPk(req.params.id, {
      include: [
        {
          model: ScanSession,
          as: 'scanSessions',
          limit: 10,
          order: [['startedAt', 'DESC']],
        },
      ],
    });

    if (!client) {
      return res.status(404).json({ error: 'Client not found' });
    }

    res.json(client);
  } catch (error) {
    console.error('Error fetching client:', error);
    res.status(500).json({ error: 'Failed to fetch client' });
  }
});

// POST /api/clients/register - Register a new client
router.post('/register', async (req, res) => {
  try {
    const { hostname, username, osVersion, clientVersion, ipAddress } = req.body;

    if (!hostname) {
      return res.status(400).json({ error: 'Hostname is required' });
    }

    // Check if client already exists
    let client = await Client.findOne({ where: { hostname } });

    if (client) {
      // Update existing client
      await client.update({
        username,
        osVersion,
        clientVersion,
        ipAddress,
        lastSeen: new Date(),
        status: 'active',
      });
    } else {
      // Create new client
      client = await Client.create({
        hostname,
        username,
        osVersion,
        clientVersion,
        ipAddress,
        lastSeen: new Date(),
        status: 'active',
      });
    }

    res.status(201).json(client);
  } catch (error) {
    console.error('Error registering client:', error);
    res.status(500).json({ error: 'Failed to register client' });
  }
});

// PUT /api/clients/:id/status - Update client status
router.put('/:id/status', async (req, res) => {
  try {
    const { status } = req.body;
    const client = await Client.findByPk(req.params.id);

    if (!client) {
      return res.status(404).json({ error: 'Client not found' });
    }

    await client.update({ status, lastSeen: new Date() });
    res.json(client);
  } catch (error) {
    console.error('Error updating client status:', error);
    res.status(500).json({ error: 'Failed to update client status' });
  }
});

// GET /api/clients/:id/detections - Get detections for a client
router.get('/:id/detections', async (req, res) => {
  try {
    const { limit = 100, offset = 0, severity, detectionType, isResolved } = req.query;
    
    const where = { clientId: req.params.id };
    if (severity) where.severity = severity;
    if (detectionType) where.detectionType = detectionType;
    if (isResolved !== undefined) where.isResolved = isResolved === 'true';

    const detections = await Detection.findAndCountAll({
      where,
      limit: parseInt(limit),
      offset: parseInt(offset),
      order: [['detectedAt', 'DESC']],
    });

    res.json({
      detections: detections.rows,
      total: detections.count,
      limit: parseInt(limit),
      offset: parseInt(offset),
    });
  } catch (error) {
    console.error('Error fetching client detections:', error);
    res.status(500).json({ error: 'Failed to fetch detections' });
  }
});

// GET /api/clients/:id/config - Get client configuration from Windows service
router.get('/:id/config', async (req, res) => {
  try {
    const client = await Client.findByPk(req.params.id);
    if (!client) {
      return res.status(404).json({ error: 'Client not found' });
    }

    // Try to get config from the Windows service
    // The Windows service runs on port 8080 on the client machine
    // When running in Docker, use host.docker.internal to reach the host machine
    // Use localhost for local development or if IP is link-local (169.254.x.x)
    const isLocalOrLinkLocal = !client.ipAddress || 
      client.ipAddress === '127.0.0.1' || 
      client.ipAddress.startsWith('169.254.');
    const isDocker = process.env.DB_HOST === 'postgres'; // Running in Docker if DB_HOST is postgres
    const serviceHost = isLocalOrLinkLocal 
      ? (isDocker ? 'host.docker.internal' : 'localhost')
      : client.ipAddress;
    const serviceUrl = `http://${serviceHost}:8080`;

    try {
      const response = await axios.get(`${serviceUrl}/api/config`, { timeout: 5000 });
      res.json(response.data);
    } catch (serviceError) {
      console.log('Could not reach Windows service, returning default config');
      // Return default config if service is not reachable
      res.json({
        scan: {
          directories: [
            'C:\\Users\\%USERNAME%\\Documents',
            'C:\\Users\\%USERNAME%\\Desktop',
            'C:\\Users\\%USERNAME%\\Downloads',
          ],
          file_types: ['.txt', '.pdf', '.doc', '.docx'],
          interval_hours: 24,
          max_file_size_mb: 50,
          worker_count: 4,
        },
        servers: {
          analyzer_url: 'http://localhost:8000',
          dashboard_url: 'http://localhost:3001',
        },
        api: {
          port: 8080,
        },
      });
    }
  } catch (error) {
    console.error('Error fetching client config:', error);
    res.status(500).json({ error: 'Failed to fetch client configuration' });
  }
});

// PUT /api/clients/:id/config - Update client configuration on Windows service
router.put('/:id/config', async (req, res) => {
  try {
    const client = await Client.findByPk(req.params.id);
    if (!client) {
      return res.status(404).json({ error: 'Client not found' });
    }

    const newConfig = req.body;

    // Validate config structure
    if (!newConfig.scan || !newConfig.scan.directories) {
      return res.status(400).json({ error: 'Invalid configuration structure' });
    }

    // Try to update config on the Windows service
    // When running in Docker, use host.docker.internal to reach the host machine
    // Use localhost for local development or if IP is link-local (169.254.x.x)
    const isLocalOrLinkLocal = !client.ipAddress || 
      client.ipAddress === '127.0.0.1' || 
      client.ipAddress.startsWith('169.254.');
    const isDocker = process.env.DB_HOST === 'postgres'; // Running in Docker if DB_HOST is postgres
    const serviceHost = isLocalOrLinkLocal 
      ? (isDocker ? 'host.docker.internal' : 'localhost')
      : client.ipAddress;
    const serviceUrl = `http://${serviceHost}:8080`;

    try {
      const response = await axios.put(`${serviceUrl}/api/config`, newConfig, { 
        timeout: 5000,
        headers: { 'Content-Type': 'application/json' }
      });
      
      // Update last seen
      await client.update({ lastSeen: new Date() });
      
      res.json(response.data);
    } catch (serviceError) {
      console.error('Could not reach Windows service:', serviceError.message);
      res.status(503).json({ 
        error: 'Could not reach the Windows service. Make sure the client is online and the service is running.',
        details: serviceError.message
      });
    }
  } catch (error) {
    console.error('Error updating client config:', error);
    res.status(500).json({ error: 'Failed to update client configuration' });
  }
});

// POST /api/clients/:id/scan/start - Trigger a scan on the client
router.post('/:id/scan/start', async (req, res) => {
  try {
    const client = await Client.findByPk(req.params.id);
    if (!client) {
      return res.status(404).json({ error: 'Client not found' });
    }

    // When running in Docker, use host.docker.internal to reach the host machine
    // Use localhost for local development or if IP is link-local (169.254.x.x)
    const isLocalOrLinkLocal = !client.ipAddress || 
      client.ipAddress === '127.0.0.1' || 
      client.ipAddress.startsWith('169.254.');
    const isDocker = process.env.DB_HOST === 'postgres'; // Running in Docker if DB_HOST is postgres
    const serviceHost = isLocalOrLinkLocal 
      ? (isDocker ? 'host.docker.internal' : 'localhost')
      : client.ipAddress;
    const serviceUrl = `http://${serviceHost}:8080`;

    try {
      const scanType = req.body.type || 'manual';
      const response = await axios.post(`${serviceUrl}/api/scan/start?type=${scanType}`, {}, { 
        timeout: 5000 
      });
      
      // Update client status
      await client.update({ status: 'scanning', lastSeen: new Date() });
      
      res.json(response.data);
    } catch (serviceError) {
      if (serviceError.response && serviceError.response.status === 409) {
        res.status(409).json({ error: 'Scan already in progress' });
      } else {
        res.status(503).json({ 
          error: 'Could not reach the Windows service',
          details: serviceError.message
        });
      }
    }
  } catch (error) {
    console.error('Error starting scan:', error);
    res.status(500).json({ error: 'Failed to start scan' });
  }
});

// POST /api/clients/:id/scan/stop - Stop a scan on the client
router.post('/:id/scan/stop', async (req, res) => {
  try {
    const client = await Client.findByPk(req.params.id);
    if (!client) {
      return res.status(404).json({ error: 'Client not found' });
    }

    // When running in Docker, use host.docker.internal to reach the host machine
    // Use localhost for local development or if IP is link-local (169.254.x.x)
    const isLocalOrLinkLocal = !client.ipAddress || 
      client.ipAddress === '127.0.0.1' || 
      client.ipAddress.startsWith('169.254.');
    const isDocker = process.env.DB_HOST === 'postgres'; // Running in Docker if DB_HOST is postgres
    const serviceHost = isLocalOrLinkLocal 
      ? (isDocker ? 'host.docker.internal' : 'localhost')
      : client.ipAddress;
    const serviceUrl = `http://${serviceHost}:8080`;

    try {
      const response = await axios.post(`${serviceUrl}/api/scan/stop`, {}, { timeout: 5000 });
      
      // Update client status
      await client.update({ status: 'active', lastSeen: new Date() });
      
      res.json(response.data);
    } catch (serviceError) {
      res.status(503).json({ 
        error: 'Could not reach the Windows service',
        details: serviceError.message
      });
    }
  } catch (error) {
    console.error('Error stopping scan:', error);
    res.status(500).json({ error: 'Failed to stop scan' });
  }
});

module.exports = router;

