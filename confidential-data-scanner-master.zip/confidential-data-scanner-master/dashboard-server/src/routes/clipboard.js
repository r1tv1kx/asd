const express = require('express');
const router = express.Router();
const { ClipboardDetection, Client } = require('../models');
const { Op } = require('sequelize');

// Get all clipboard detections with optional filters
router.get('/detections', async (req, res) => {
  try {
    const {
      clientId,
      detectionType,
      severity,
      startDate,
      endDate,
      limit = 100,
      offset = 0,
    } = req.query;

    const where = {};

    if (clientId) {
      where.clientId = clientId;
    }

    if (detectionType) {
      where.detectionType = detectionType;
    }

    if (severity) {
      where.severity = severity;
    }

    if (startDate || endDate) {
      where.detectedAt = {};
      if (startDate) {
        where.detectedAt[Op.gte] = new Date(startDate);
      }
      if (endDate) {
        where.detectedAt[Op.lte] = new Date(endDate);
      }
    }

    const { count, rows } = await ClipboardDetection.findAndCountAll({
      where,
      include: [
        {
          model: Client,
          as: 'client',
          attributes: ['id', 'hostname', 'username'],
        },
      ],
      order: [['detectedAt', 'DESC']],
      limit: parseInt(limit),
      offset: parseInt(offset),
    });

    res.json({
      detections: rows,
      total: count,
      limit: parseInt(limit),
      offset: parseInt(offset),
    });
  } catch (error) {
    console.error('Error fetching clipboard detections:', error);
    res.status(500).json({ error: 'Failed to fetch clipboard detections' });
  }
});

// Get clipboard detection statistics
router.get('/stats', async (req, res) => {
  try {
    const { clientId } = req.query;

    const where = {};
    if (clientId) {
      where.clientId = clientId;
    }

    // Total detections
    const totalDetections = await ClipboardDetection.count({ where });

    // Detections by type
    const byType = await ClipboardDetection.findAll({
      where,
      attributes: [
        'detectionType',
        [ClipboardDetection.sequelize.fn('COUNT', '*'), 'count'],
      ],
      group: ['detectionType'],
    });

    // Detections by severity
    const bySeverity = await ClipboardDetection.findAll({
      where,
      attributes: [
        'severity',
        [ClipboardDetection.sequelize.fn('COUNT', '*'), 'count'],
      ],
      group: ['severity'],
    });

    // Recent detections (last 24 hours)
    const recentWhere = {
      ...where,
      detectedAt: {
        [Op.gte]: new Date(Date.now() - 24 * 60 * 60 * 1000),
      },
    };
    const recentCount = await ClipboardDetection.count({ where: recentWhere });

    res.json({
      totalDetections,
      recentDetections: recentCount,
      byType: byType.reduce((acc, item) => {
        acc[item.detectionType] = parseInt(item.get('count'));
        return acc;
      }, {}),
      bySeverity: bySeverity.reduce((acc, item) => {
        acc[item.severity] = parseInt(item.get('count'));
        return acc;
      }, {}),
    });
  } catch (error) {
    console.error('Error fetching clipboard stats:', error);
    res.status(500).json({ error: 'Failed to fetch clipboard statistics' });
  }
});

// Submit clipboard detection from client
router.post('/detections', async (req, res) => {
  try {
    const { clientId, detections } = req.body;

    if (!clientId || !detections || !Array.isArray(detections)) {
      return res.status(400).json({ error: 'Invalid request body' });
    }

    // Verify client exists
    const client = await Client.findByPk(clientId);
    if (!client) {
      return res.status(404).json({ error: 'Client not found' });
    }

    // Create detections
    const created = await ClipboardDetection.bulkCreate(
      detections.map((det) => ({
        ...det,
        clientId,
      }))
    );

    res.status(201).json({
      message: 'Clipboard detections saved',
      count: created.length,
    });
  } catch (error) {
    console.error('Error saving clipboard detections:', error);
    res.status(500).json({ error: 'Failed to save clipboard detections' });
  }
});

// Get clipboard detections for a specific client
router.get('/clients/:clientId/detections', async (req, res) => {
  try {
    const { clientId } = req.params;
    const { limit = 50, offset = 0 } = req.query;

    const { count, rows } = await ClipboardDetection.findAndCountAll({
      where: { clientId },
      order: [['detectedAt', 'DESC']],
      limit: parseInt(limit),
      offset: parseInt(offset),
    });

    res.json({
      detections: rows,
      total: count,
      limit: parseInt(limit),
      offset: parseInt(offset),
    });
  } catch (error) {
    console.error('Error fetching client clipboard detections:', error);
    res.status(500).json({ error: 'Failed to fetch clipboard detections' });
  }
});

module.exports = router;

