const express = require('express');
const router = express.Router();
const { Client, ScanSession, Detection, USBDevice, ClipboardDetection, sequelize } = require('../models');
const { Op } = require('sequelize');

// GET /api/dashboard/stats - Get overall dashboard statistics
router.get('/stats', async (req, res) => {
  try {
    // Total clients
    const totalClients = await Client.count();
    
    // Active clients (seen in last 24 hours)
    const activeClients = await Client.count({
      where: {
        lastSeen: {
          [Op.gte]: new Date(Date.now() - 24 * 60 * 60 * 1000),
        },
      },
    });

    // Total detections
    const totalDetections = await Detection.count();
    
    // Unresolved detections
    const unresolvedDetections = await Detection.count({
      where: { isResolved: false },
    });

    // Detections by severity
    const bySeverity = await Detection.findAll({
      attributes: [
        'severity',
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
      ],
      group: ['severity'],
      raw: true,
    });

    // Detections by type
    const byType = await Detection.findAll({
      attributes: [
        'detectionType',
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
      ],
      group: ['detectionType'],
      order: [[sequelize.fn('COUNT', sequelize.col('id')), 'DESC']],
      limit: 10,
      raw: true,
    });

    // Total scans
    const totalScans = await ScanSession.count();
    
    // Scans today
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const scansToday = await ScanSession.count({
      where: {
        startedAt: { [Op.gte]: today },
      },
    });

    // Files scanned total
    const filesScannedResult = await ScanSession.findOne({
      attributes: [[sequelize.fn('SUM', sequelize.col('filesScanned')), 'total']],
      raw: true,
    });
    const filesScanned = parseInt(filesScannedResult?.total || 0);

    // Detections by scan source
    const bySource = await Detection.findAll({
      attributes: [
        'scanSource',
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
      ],
      group: ['scanSource'],
      raw: true,
    });

    // USB devices count
    const totalUSBDevices = await USBDevice.count();

    // Clipboard detections count
    const totalClipboardDetections = await ClipboardDetection.count();

    res.json({
      clients: {
        total: totalClients,
        active: activeClients,
      },
      detections: {
        total: totalDetections,
        unresolved: unresolvedDetections,
        bySeverity: bySeverity.reduce((acc, item) => {
          acc[item.severity] = parseInt(item.count);
          return acc;
        }, {}),
        byType,
        bySource: bySource.reduce((acc, item) => {
          acc[item.scanSource || 'filesystem'] = parseInt(item.count);
          return acc;
        }, {}),
      },
      scans: {
        total: totalScans,
        today: scansToday,
        filesScanned,
      },
      usb: {
        totalDevices: totalUSBDevices,
      },
      clipboard: {
        totalDetections: totalClipboardDetections,
      },
    });
  } catch (error) {
    console.error('Error fetching dashboard stats:', error);
    res.status(500).json({ error: 'Failed to fetch dashboard stats' });
  }
});

// GET /api/dashboard/recent - Get recent activity
router.get('/recent', async (req, res) => {
  try {
    const { limit = 20 } = req.query;

    // Recent detections
    const recentDetections = await Detection.findAll({
      limit: parseInt(limit),
      order: [['detectedAt', 'DESC']],
      include: [
        { model: Client, as: 'client', attributes: ['id', 'hostname', 'username'] },
      ],
    });

    // Recent scans
    const recentScans = await ScanSession.findAll({
      limit: parseInt(limit),
      order: [['startedAt', 'DESC']],
      include: [
        { model: Client, as: 'client', attributes: ['id', 'hostname', 'username'] },
      ],
    });

    // Recently active clients
    const recentClients = await Client.findAll({
      limit: parseInt(limit),
      order: [['lastSeen', 'DESC']],
      attributes: ['id', 'hostname', 'username', 'status', 'lastSeen'],
    });

    res.json({
      detections: recentDetections,
      scans: recentScans,
      clients: recentClients,
    });
  } catch (error) {
    console.error('Error fetching recent activity:', error);
    res.status(500).json({ error: 'Failed to fetch recent activity' });
  }
});

// GET /api/dashboard/trends - Get detection trends over time
router.get('/trends', async (req, res) => {
  try {
    const { days = 7 } = req.query;
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - parseInt(days));
    startDate.setHours(0, 0, 0, 0);

    // Daily detection counts
    const dailyDetections = await Detection.findAll({
      where: {
        detectedAt: { [Op.gte]: startDate },
      },
      attributes: [
        [sequelize.fn('DATE', sequelize.col('detectedAt')), 'date'],
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
      ],
      group: [sequelize.fn('DATE', sequelize.col('detectedAt'))],
      order: [[sequelize.fn('DATE', sequelize.col('detectedAt')), 'ASC']],
      raw: true,
    });

    // Daily scan counts
    const dailyScans = await ScanSession.findAll({
      where: {
        startedAt: { [Op.gte]: startDate },
      },
      attributes: [
        [sequelize.fn('DATE', sequelize.col('startedAt')), 'date'],
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
        [sequelize.fn('SUM', sequelize.col('filesScanned')), 'filesScanned'],
      ],
      group: [sequelize.fn('DATE', sequelize.col('startedAt'))],
      order: [[sequelize.fn('DATE', sequelize.col('startedAt')), 'ASC']],
      raw: true,
    });

    res.json({
      detections: dailyDetections,
      scans: dailyScans,
    });
  } catch (error) {
    console.error('Error fetching trends:', error);
    res.status(500).json({ error: 'Failed to fetch trends' });
  }
});

// GET /api/dashboard/high-risk - Get high-risk files/clients
router.get('/high-risk', async (req, res) => {
  try {
    const { limit = 10 } = req.query;

    // Clients with most unresolved high/critical detections
    const highRiskClients = await Client.findAll({
      attributes: [
        'id',
        'hostname',
        'username',
        'lastSeen',
        [
          sequelize.literal(`(
            SELECT COUNT(*) FROM detections 
            WHERE detections."clientId" = "Client".id 
            AND detections."isResolved" = false 
            AND detections.severity IN ('high', 'critical')
          )`),
          'unresolvedHighRisk',
        ],
      ],
      order: [[sequelize.literal('"unresolvedHighRisk"'), 'DESC']],
      limit: parseInt(limit),
    });

    // Files with multiple detections
    const highRiskFiles = await Detection.findAll({
      where: { isResolved: false },
      attributes: [
        'filePath',
        'clientId',
        [sequelize.fn('COUNT', sequelize.col('Detection.id')), 'detectionCount'],
        [sequelize.fn('MAX', sequelize.col('severity')), 'maxSeverity'],
      ],
      group: ['filePath', 'clientId'],
      order: [[sequelize.fn('COUNT', sequelize.col('Detection.id')), 'DESC']],
      limit: parseInt(limit),
      include: [
        { model: Client, as: 'client', attributes: ['hostname'] },
      ],
    });

    res.json({
      clients: highRiskClients,
      files: highRiskFiles,
    });
  } catch (error) {
    console.error('Error fetching high-risk data:', error);
    res.status(500).json({ error: 'Failed to fetch high-risk data' });
  }
});

module.exports = router;

