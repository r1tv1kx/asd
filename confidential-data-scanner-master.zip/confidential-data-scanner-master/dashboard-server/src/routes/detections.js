const express = require('express');
const router = express.Router();
const { Detection, Client, ScanSession, sequelize } = require('../models');
const { Op } = require('sequelize');

// POST /api/detections - Submit new detection(s)
router.post('/', async (req, res) => {
  try {
    const { clientId, sessionId, detections } = req.body;

    if (!clientId) {
      return res.status(400).json({ error: 'Client ID is required' });
    }

    if (!detections || !Array.isArray(detections) || detections.length === 0) {
      return res.status(400).json({ error: 'Detections array is required' });
    }

    // Verify client exists
    const client = await Client.findByPk(clientId);
    if (!client) {
      return res.status(404).json({ error: 'Client not found' });
    }

    // Map severity based on detection type
    const getSeverity = (type) => {
      const highSeverity = ['AADHAR', 'PAN', 'US_SSN', 'CREDIT_CARD', 'US_BANK_NUMBER'];
      const criticalSeverity = ['US_SSN', 'CREDIT_CARD'];
      
      if (criticalSeverity.includes(type)) return 'critical';
      if (highSeverity.includes(type)) return 'high';
      return 'medium';
    };

    // Create detections
    const detectionsToCreate = detections.map(d => ({
      clientId,
      sessionId,
      filePath: d.filePath,
      fileName: d.fileName || d.filePath.split(/[/\\]/).pop(),
      fileType: d.fileType || d.filePath.split('.').pop(),
      fileSize: d.fileSize,
      detectionType: d.detectionType,
      matchedTextHash: d.matchedTextHash,
      redactedPreview: d.redactedPreview,
      confidence: d.confidence,
      severity: d.severity || getSeverity(d.detectionType),
      position: d.position,
      scanSource: d.scanSource || 'filesystem',
    }));

    const createdDetections = await Detection.bulkCreate(detectionsToCreate);

    // Update session detection count if session provided
    if (sessionId) {
      const session = await ScanSession.findByPk(sessionId);
      if (session) {
        await session.increment('detectionsFound', { by: detections.length });
      }
    }

    // Update client last seen
    await client.update({ lastSeen: new Date() });

    res.status(201).json({
      created: createdDetections.length,
      detections: createdDetections,
    });
  } catch (error) {
    console.error('Error creating detections:', error);
    res.status(500).json({ error: 'Failed to create detections' });
  }
});

// GET /api/detections - List all detections
router.get('/', async (req, res) => {
  try {
    const { 
      clientId, 
      sessionId, 
      severity, 
      detectionType, 
      isResolved,
      scanSource,
      startDate,
      endDate,
      limit = 100, 
      offset = 0 
    } = req.query;
    
    const where = {};
    if (clientId) where.clientId = clientId;
    if (sessionId) where.sessionId = sessionId;
    if (severity) where.severity = severity;
    if (detectionType) where.detectionType = detectionType;
    if (isResolved !== undefined) where.isResolved = isResolved === 'true';
    if (scanSource) where.scanSource = scanSource;
    
    if (startDate || endDate) {
      where.detectedAt = {};
      if (startDate) where.detectedAt[Op.gte] = new Date(startDate);
      if (endDate) where.detectedAt[Op.lte] = new Date(endDate);
    }

    const detections = await Detection.findAndCountAll({
      where,
      limit: parseInt(limit),
      offset: parseInt(offset),
      order: [['detectedAt', 'DESC']],
      include: [
        { model: Client, as: 'client', attributes: ['id', 'hostname', 'username'] },
      ],
    });

    res.json({
      detections: detections.rows,
      total: detections.count,
      limit: parseInt(limit),
      offset: parseInt(offset),
    });
  } catch (error) {
    console.error('Error fetching detections:', error);
    res.status(500).json({ error: 'Failed to fetch detections' });
  }
});

// PUT /api/detections/:id/resolve - Mark detection as resolved
router.put('/:id/resolve', async (req, res) => {
  try {
    const { resolvedBy } = req.body;
    
    const detection = await Detection.findByPk(req.params.id);
    if (!detection) {
      return res.status(404).json({ error: 'Detection not found' });
    }

    await detection.update({
      isResolved: true,
      resolvedAt: new Date(),
      resolvedBy,
    });

    res.json(detection);
  } catch (error) {
    console.error('Error resolving detection:', error);
    res.status(500).json({ error: 'Failed to resolve detection' });
  }
});

// PUT /api/detections/bulk-resolve - Bulk resolve detections
router.put('/bulk-resolve', async (req, res) => {
  try {
    const { ids, resolvedBy } = req.body;
    
    if (!ids || !Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ error: 'Detection IDs array is required' });
    }

    const [updatedCount] = await Detection.update(
      {
        isResolved: true,
        resolvedAt: new Date(),
        resolvedBy,
      },
      {
        where: { id: { [Op.in]: ids } },
      }
    );

    res.json({ updated: updatedCount });
  } catch (error) {
    console.error('Error bulk resolving detections:', error);
    res.status(500).json({ error: 'Failed to bulk resolve detections' });
  }
});

// GET /api/detections/stats - Get detection statistics
router.get('/stats', async (req, res) => {
  try {
    const { clientId, startDate, endDate } = req.query;
    
    const where = {};
    if (clientId) where.clientId = clientId;
    if (startDate || endDate) {
      where.detectedAt = {};
      if (startDate) where.detectedAt[Op.gte] = new Date(startDate);
      if (endDate) where.detectedAt[Op.lte] = new Date(endDate);
    }

    // Get counts by detection type
    const byType = await Detection.findAll({
      where,
      attributes: [
        'detectionType',
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
      ],
      group: ['detectionType'],
      raw: true,
    });

    // Get counts by severity
    const bySeverity = await Detection.findAll({
      where,
      attributes: [
        'severity',
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
      ],
      group: ['severity'],
      raw: true,
    });

    // Get resolved vs unresolved
    const byResolved = await Detection.findAll({
      where,
      attributes: [
        'isResolved',
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
      ],
      group: ['isResolved'],
      raw: true,
    });

    // Get total count
    const total = await Detection.count({ where });

    res.json({
      total,
      byType,
      bySeverity,
      byResolved,
    });
  } catch (error) {
    console.error('Error fetching detection stats:', error);
    res.status(500).json({ error: 'Failed to fetch detection stats' });
  }
});

module.exports = router;

