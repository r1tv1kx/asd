const express = require('express');
const multer = require('multer');
const axios = require('axios');
const path = require('path');
const fs = require('fs').promises;
const os = require('os');

const router = express.Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: async (req, file, cb) => {
    const uploadDir = path.join(os.tmpdir(), 'scanner-uploads');
    try {
      await fs.mkdir(uploadDir, { recursive: true });
      cb(null, uploadDir);
    } catch (err) {
      cb(err);
    }
  },
  filename: (req, file, cb) => {
    // Keep original filename with timestamp prefix
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + '-' + file.originalname);
  }
});

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB limit
  },
  fileFilter: (req, file, cb) => {
    // Allow common document types
    const allowedTypes = [
      '.txt', '.pdf', '.doc', '.docx', '.xlsx', '.xls',
      '.csv', '.json', '.xml', '.html', '.md', '.rtf'
    ];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowedTypes.includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error(`File type ${ext} not supported. Allowed: ${allowedTypes.join(', ')}`));
    }
  }
});

// Text extraction functions
const extractTextFromFile = async (filePath, fileType) => {
  const ext = fileType.toLowerCase();
  
  if (ext === '.txt' || ext === '.csv' || ext === '.json' || ext === '.xml' || ext === '.html' || ext === '.md') {
    // Plain text files - read directly
    const content = await fs.readFile(filePath, 'utf-8');
    return content;
  }
  
  if (ext === '.pdf') {
    // For PDF, we'll send the raw content to the analyzer
    // The analyzer server will need to handle it, or we extract here
    try {
      const pdfParse = require('pdf-parse');
      const dataBuffer = await fs.readFile(filePath);
      const data = await pdfParse(dataBuffer);
      return data.text;
    } catch (err) {
      throw new Error(`Failed to extract text from PDF: ${err.message}`);
    }
  }
  
  if (ext === '.docx') {
    try {
      const mammoth = require('mammoth');
      const result = await mammoth.extractRawText({ path: filePath });
      return result.value;
    } catch (err) {
      throw new Error(`Failed to extract text from DOCX: ${err.message}`);
    }
  }
  
  if (ext === '.doc') {
    // .doc files are harder to parse - try basic extraction
    throw new Error('Legacy .doc format not supported. Please convert to .docx');
  }
  
  if (ext === '.xlsx' || ext === '.xls') {
    try {
      const XLSX = require('xlsx');
      const workbook = XLSX.readFile(filePath);
      let text = '';
      workbook.SheetNames.forEach(sheetName => {
        const sheet = workbook.Sheets[sheetName];
        text += XLSX.utils.sheet_to_csv(sheet) + '\n';
      });
      return text;
    } catch (err) {
      throw new Error(`Failed to extract text from Excel: ${err.message}`);
    }
  }
  
  throw new Error(`Unsupported file type: ${ext}`);
};

// POST /api/scan/file - Upload and scan a single file
router.post('/file', upload.single('file'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }

  const filePath = req.file.path;
  const originalName = req.file.originalname;
  const fileType = path.extname(originalName).toLowerCase();
  const fileSize = req.file.size;

  try {
    // Extract text from file
    console.log(`Extracting text from ${originalName} (${fileType})`);
    const text = await extractTextFromFile(filePath, fileType);
    
    if (!text || text.trim().length === 0) {
      // Clean up uploaded file
      await fs.unlink(filePath).catch(() => {});
      return res.json({
        success: true,
        fileName: originalName,
        fileType: fileType,
        fileSize: fileSize,
        textLength: 0,
        detections: [],
        totalDetections: 0,
        hasPII: false,
        message: 'File is empty or contains no extractable text'
      });
    }

    // Send to analyzer server
    // When running in Docker, use the service name from docker-compose
    const isDocker = process.env.DB_HOST === 'postgres';
    const analyzerHost = isDocker ? 'scanner-analyzer' : 'localhost';
    const finalAnalyzerUrl = `http://${analyzerHost}:8000`;
    
    console.log(`Sending ${text.length} chars to analyzer at ${finalAnalyzerUrl}`);
    
    const analyzeResponse = await axios.post(`${finalAnalyzerUrl}/api/analyze`, {
      text: text,
      file_path: originalName,
      language: 'en'
    }, {
      timeout: 60000, // 60 second timeout for large files
      headers: { 'Content-Type': 'application/json' }
    });

    const result = analyzeResponse.data;

    // Clean up uploaded file
    await fs.unlink(filePath).catch(() => {});

    // Format response
    const response = {
      success: true,
      fileName: originalName,
      fileType: fileType,
      fileSize: fileSize,
      textLength: text.length,
      detections: result.detections.map(d => ({
        type: d.entity_type,
        text: d.redacted_text,
        confidence: d.score,
        severity: getSeverity(d.entity_type, d.score),
        position: { start: d.start, end: d.end }
      })),
      totalDetections: result.total_detections,
      hasPII: result.has_pii,
      summary: generateSummary(result.detections)
    };

    res.json(response);

  } catch (err) {
    console.error('Error scanning file:', err);
    
    // Clean up uploaded file on error
    await fs.unlink(filePath).catch(() => {});
    
    if (err.response) {
      // Analyzer server error
      res.status(502).json({ 
        error: 'Analyzer service error', 
        details: err.response.data 
      });
    } else if (err.code === 'ECONNREFUSED') {
      res.status(503).json({ 
        error: 'Analyzer service not available. Make sure the analyzer server is running.' 
      });
    } else {
      res.status(500).json({ 
        error: err.message || 'Failed to scan file' 
      });
    }
  }
});

// POST /api/scan/text - Scan raw text directly
router.post('/text', async (req, res) => {
  const { text, fileName } = req.body;

  if (!text || text.trim().length === 0) {
    return res.status(400).json({ error: 'No text provided' });
  }

  try {
    // Send to analyzer server
    // When running in Docker, use the service name from docker-compose
    const isDocker = process.env.DB_HOST === 'postgres';
    const analyzerHost = isDocker ? 'scanner-analyzer' : 'localhost';
    const analyzerUrl = `http://${analyzerHost}:8000`;
    
    const analyzeResponse = await axios.post(`${analyzerUrl}/api/analyze`, {
      text: text,
      file_path: fileName || 'direct-input.txt',
      language: 'en'
    }, {
      timeout: 60000,
      headers: { 'Content-Type': 'application/json' }
    });

    const result = analyzeResponse.data;

    const response = {
      success: true,
      fileName: fileName || 'Direct Text Input',
      fileType: '.txt',
      fileSize: Buffer.byteLength(text, 'utf8'),
      textLength: text.length,
      detections: result.detections.map(d => ({
        type: d.entity_type,
        text: d.redacted_text,
        confidence: d.score,
        severity: getSeverity(d.entity_type, d.score),
        position: { start: d.start, end: d.end }
      })),
      totalDetections: result.total_detections,
      hasPII: result.has_pii,
      summary: generateSummary(result.detections)
    };

    res.json(response);

  } catch (err) {
    console.error('Error scanning text:', err);
    
    if (err.response) {
      res.status(502).json({ 
        error: 'Analyzer service error', 
        details: err.response.data 
      });
    } else if (err.code === 'ECONNREFUSED') {
      res.status(503).json({ 
        error: 'Analyzer service not available. Make sure the analyzer server is running.' 
      });
    } else {
      res.status(500).json({ 
        error: err.message || 'Failed to scan text' 
      });
    }
  }
});

// Helper function to determine severity based on entity type and confidence
function getSeverity(entityType, confidence) {
  const criticalTypes = ['US_SSN', 'CREDIT_CARD', 'US_PASSPORT', 'INDIAN_PASSPORT', 'AADHAR'];
  const highTypes = ['US_BANK_NUMBER', 'IBAN', 'PAN', 'DRIVING_LICENSE'];
  const mediumTypes = ['PHONE_NUMBER', 'EMAIL_ADDRESS', 'DATE_OF_BIRTH'];
  
  if (criticalTypes.includes(entityType) && confidence > 0.5) {
    return 'critical';
  }
  if (highTypes.includes(entityType) || (criticalTypes.includes(entityType) && confidence <= 0.5)) {
    return 'high';
  }
  if (mediumTypes.includes(entityType)) {
    return 'medium';
  }
  return 'low';
}

// Helper function to generate summary of detections
function generateSummary(detections) {
  const byType = {};
  const bySeverity = { critical: 0, high: 0, medium: 0, low: 0 };
  
  detections.forEach(d => {
    const type = d.entity_type;
    const severity = getSeverity(type, d.score);
    
    byType[type] = (byType[type] || 0) + 1;
    bySeverity[severity]++;
  });
  
  return {
    byType: Object.entries(byType).map(([type, count]) => ({ type, count }))
      .sort((a, b) => b.count - a.count),
    bySeverity
  };
}

module.exports = router;

