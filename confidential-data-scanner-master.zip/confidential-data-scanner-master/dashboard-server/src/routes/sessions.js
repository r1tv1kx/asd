const express = require('express');
const router = express.Router();
const { ScanSession, Client, Detection } = require('../models');

// POST /api/sessions - Create a new scan session
router.post('/', async (req, res) => {
  try {
    const { clientId, scanType, scanDirectories } = req.body;

    if (!clientId) {
      return res.status(400).json({ error: 'Client ID is required' });
    }

    // Verify client exists
    const client = await Client.findByPk(clientId);
    if (!client) {
      return res.status(404).json({ error: 'Client not found' });
    }

    // Update client status
    await client.update({ status: 'scanning', lastSeen: new Date() });

    const session = await ScanSession.create({
      clientId,
      scanType: scanType || 'full',
      scanDirectories,
      status: 'running',
    });

    res.status(201).json(session);
  } catch (error) {
    console.error('Error creating scan session:', error);
    res.status(500).json({ error: 'Failed to create scan session' });
  }
});

// GET /api/sessions/:id - Get session details
router.get('/:id', async (req, res) => {
  try {
    const session = await ScanSession.findByPk(req.params.id, {
      include: [
        { model: Client, as: 'client' },
        { 
          model: Detection, 
          as: 'detections',
          limit: 100,
          order: [['detectedAt', 'DESC']],
        },
      ],
    });

    if (!session) {
      return res.status(404).json({ error: 'Session not found' });
    }

    res.json(session);
  } catch (error) {
    console.error('Error fetching session:', error);
    res.status(500).json({ error: 'Failed to fetch session' });
  }
});

// PUT /api/sessions/:id - Update session (complete/fail)
router.put('/:id', async (req, res) => {
  try {
    const { status, filesScanned, detectionsFound, errorMessage } = req.body;
    
    const session = await ScanSession.findByPk(req.params.id, {
      include: [{ model: Client, as: 'client' }],
    });

    if (!session) {
      return res.status(404).json({ error: 'Session not found' });
    }

    const updates = {};
    if (status) updates.status = status;
    if (filesScanned !== undefined) updates.filesScanned = filesScanned;
    if (detectionsFound !== undefined) updates.detectionsFound = detectionsFound;
    if (errorMessage) updates.errorMessage = errorMessage;
    
    if (status === 'completed' || status === 'failed' || status === 'cancelled') {
      updates.completedAt = new Date();
      // Update client status back to active
      if (session.client) {
        await session.client.update({ status: 'active', lastSeen: new Date() });
      }
    }

    await session.update(updates);
    res.json(session);
  } catch (error) {
    console.error('Error updating session:', error);
    res.status(500).json({ error: 'Failed to update session' });
  }
});

// GET /api/sessions - List recent sessions
router.get('/', async (req, res) => {
  try {
    const { clientId, status, limit = 50, offset = 0 } = req.query;
    
    const where = {};
    if (clientId) where.clientId = clientId;
    if (status) where.status = status;

    const sessions = await ScanSession.findAndCountAll({
      where,
      limit: parseInt(limit),
      offset: parseInt(offset),
      order: [['startedAt', 'DESC']],
      include: [
        { model: Client, as: 'client', attributes: ['id', 'hostname', 'username'] },
      ],
    });

    res.json({
      sessions: sessions.rows,
      total: sessions.count,
      limit: parseInt(limit),
      offset: parseInt(offset),
    });
  } catch (error) {
    console.error('Error fetching sessions:', error);
    res.status(500).json({ error: 'Failed to fetch sessions' });
  }
});

module.exports = router;

