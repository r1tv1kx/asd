const express = require('express');
const router = express.Router();
const { USBDevice, Detection, Client } = require('../models');
const { Op } = require('sequelize');

// Get all USB devices with optional filters
router.get('/devices', async (req, res) => {
  try {
    const {
      clientId,
      isWhitelisted,
      isBlacklisted,
      limit = 100,
      offset = 0,
    } = req.query;

    const where = {};

    if (clientId) {
      where.clientId = clientId;
    }

    if (isWhitelisted !== undefined) {
      where.isWhitelisted = isWhitelisted === 'true';
    }

    if (isBlacklisted !== undefined) {
      where.isBlacklisted = isBlacklisted === 'true';
    }

    const { count, rows } = await USBDevice.findAndCountAll({
      where,
      include: [
        {
          model: Client,
          as: 'client',
          attributes: ['id', 'hostname', 'username'],
        },
      ],
      order: [['lastSeen', 'DESC']],
      limit: parseInt(limit),
      offset: parseInt(offset),
    });

    res.json({
      devices: rows,
      total: count,
      limit: parseInt(limit),
      offset: parseInt(offset),
    });
  } catch (error) {
    console.error('Error fetching USB devices:', error);
    res.status(500).json({ error: 'Failed to fetch USB devices' });
  }
});

// Get USB device by ID
router.get('/devices/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const device = await USBDevice.findByPk(id, {
      include: [
        {
          model: Client,
          as: 'client',
          attributes: ['id', 'hostname', 'username'],
        },
      ],
    });

    if (!device) {
      return res.status(404).json({ error: 'USB device not found' });
    }

    // Get detections for this device
    const detections = await Detection.findAll({
      where: { usbDeviceId: id },
      order: [['detectedAt', 'DESC']],
      limit: 10,
    });

    res.json({
      device,
      recentDetections: detections,
    });
  } catch (error) {
    console.error('Error fetching USB device:', error);
    res.status(500).json({ error: 'Failed to fetch USB device' });
  }
});

// Get USB devices for a specific client
router.get('/clients/:clientId/devices', async (req, res) => {
  try {
    const { clientId } = req.params;
    const { limit = 50, offset = 0 } = req.query;

    const { count, rows } = await USBDevice.findAndCountAll({
      where: { clientId },
      order: [['lastSeen', 'DESC']],
      limit: parseInt(limit),
      offset: parseInt(offset),
    });

    res.json({
      devices: rows,
      total: count,
      limit: parseInt(limit),
      offset: parseInt(offset),
    });
  } catch (error) {
    console.error('Error fetching client USB devices:', error);
    res.status(500).json({ error: 'Failed to fetch USB devices' });
  }
});

// Submit USB device from client
router.post('/devices', async (req, res) => {
  try {
    const { clientId, device } = req.body;

    if (!clientId || !device) {
      return res.status(400).json({ error: 'Invalid request body' });
    }

    // Verify client exists
    const client = await Client.findByPk(clientId);
    if (!client) {
      return res.status(404).json({ error: 'Client not found' });
    }

    // Check if device already exists for this client
    let existingDevice = await USBDevice.findOne({
      where: {
        clientId,
        deviceSerial: device.deviceSerial,
      },
    });

    if (existingDevice) {
      // Update existing device
      await existingDevice.update({
        deviceName: device.deviceName || existingDevice.deviceName,
        deviceVendor: device.deviceVendor || existingDevice.deviceVendor,
        driveLetter: device.driveLetter,
        lastSeen: new Date(),
      });
      res.json({ device: existingDevice, created: false });
    } else {
      // Create new device
      const newDevice = await USBDevice.create({
        ...device,
        clientId,
        firstSeen: new Date(),
        lastSeen: new Date(),
      });
      res.status(201).json({ device: newDevice, created: true });
    }
  } catch (error) {
    console.error('Error saving USB device:', error);
    res.status(500).json({ error: 'Failed to save USB device' });
  }
});

// Update USB device whitelist status
router.post('/devices/:id/whitelist', async (req, res) => {
  try {
    const { id } = req.params;

    const device = await USBDevice.findByPk(id);
    if (!device) {
      return res.status(404).json({ error: 'USB device not found' });
    }

    await device.update({
      isWhitelisted: true,
      isBlacklisted: false,
    });

    res.json({ message: 'Device added to whitelist', device });
  } catch (error) {
    console.error('Error whitelisting USB device:', error);
    res.status(500).json({ error: 'Failed to whitelist USB device' });
  }
});

// Update USB device blacklist status
router.post('/devices/:id/blacklist', async (req, res) => {
  try {
    const { id } = req.params;

    const device = await USBDevice.findByPk(id);
    if (!device) {
      return res.status(404).json({ error: 'USB device not found' });
    }

    await device.update({
      isWhitelisted: false,
      isBlacklisted: true,
    });

    res.json({ message: 'Device added to blacklist', device });
  } catch (error) {
    console.error('Error blacklisting USB device:', error);
    res.status(500).json({ error: 'Failed to blacklist USB device' });
  }
});

// Remove USB device from whitelist
router.delete('/devices/:id/whitelist', async (req, res) => {
  try {
    const { id } = req.params;

    const device = await USBDevice.findByPk(id);
    if (!device) {
      return res.status(404).json({ error: 'USB device not found' });
    }

    await device.update({ isWhitelisted: false });

    res.json({ message: 'Device removed from whitelist', device });
  } catch (error) {
    console.error('Error removing USB device from whitelist:', error);
    res.status(500).json({ error: 'Failed to update USB device' });
  }
});

// Remove USB device from blacklist
router.delete('/devices/:id/blacklist', async (req, res) => {
  try {
    const { id } = req.params;

    const device = await USBDevice.findByPk(id);
    if (!device) {
      return res.status(404).json({ error: 'USB device not found' });
    }

    await device.update({ isBlacklisted: false });

    res.json({ message: 'Device removed from blacklist', device });
  } catch (error) {
    console.error('Error removing USB device from blacklist:', error);
    res.status(500).json({ error: 'Failed to update USB device' });
  }
});

// Get USB statistics
router.get('/stats', async (req, res) => {
  try {
    const { clientId } = req.query;

    const where = {};
    if (clientId) {
      where.clientId = clientId;
    }

    // Total devices
    const totalDevices = await USBDevice.count({ where });

    // Whitelisted devices
    const whitelistedCount = await USBDevice.count({
      where: { ...where, isWhitelisted: true },
    });

    // Blacklisted devices
    const blacklistedCount = await USBDevice.count({
      where: { ...where, isBlacklisted: true },
    });

    // USB detections
    const usbDetectionWhere = { scanSource: 'usb' };
    if (clientId) {
      usbDetectionWhere.clientId = clientId;
    }
    const totalUsbDetections = await Detection.count({ where: usbDetectionWhere });

    // Recent USB detections (last 24 hours)
    const recentUsbDetections = await Detection.count({
      where: {
        ...usbDetectionWhere,
        detectedAt: {
          [Op.gte]: new Date(Date.now() - 24 * 60 * 60 * 1000),
        },
      },
    });

    res.json({
      totalDevices,
      whitelistedDevices: whitelistedCount,
      blacklistedDevices: blacklistedCount,
      totalUsbDetections,
      recentUsbDetections,
    });
  } catch (error) {
    console.error('Error fetching USB stats:', error);
    res.status(500).json({ error: 'Failed to fetch USB statistics' });
  }
});

// Get USB detections
router.get('/detections', async (req, res) => {
  try {
    const { clientId, deviceId, limit = 100, offset = 0 } = req.query;

    const where = { scanSource: 'usb' };

    if (clientId) {
      where.clientId = clientId;
    }

    if (deviceId) {
      where.usbDeviceId = deviceId;
    }

    const { count, rows } = await Detection.findAndCountAll({
      where,
      include: [
        {
          model: Client,
          as: 'client',
          attributes: ['id', 'hostname', 'username'],
        },
      ],
      order: [['detectedAt', 'DESC']],
      limit: parseInt(limit),
      offset: parseInt(offset),
    });

    res.json({
      detections: rows,
      total: count,
      limit: parseInt(limit),
      offset: parseInt(offset),
    });
  } catch (error) {
    console.error('Error fetching USB detections:', error);
    res.status(500).json({ error: 'Failed to fetch USB detections' });
  }
});

module.exports = router;

