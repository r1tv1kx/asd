# Dashboard UI

React-based web dashboard for the Confidential Data Scanner system.

## Features

- Overview dashboard with key metrics and charts
- Client management and monitoring
- Detection viewing with filtering and bulk actions
- Real-time data updates

## Setup

### Prerequisites

- Node.js 18+

### Installation

```bash
cd dashboard-ui

# Install dependencies
npm install
```

### Configuration

Create a `.env` file (optional):

```
REACT_APP_API_URL=http://localhost:3001
```

### Running the App

```bash
# Development mode
npm start
```

The app will be available at `http://localhost:3000`

### Building for Production

```bash
npm run build
```

## Pages

### Dashboard (`/`)
- Overview statistics (clients, detections, scans)
- Detection trends chart (last 7 days)
- Severity breakdown pie chart
- Recent detections and active clients

### Clients (`/clients`)
- List of all registered clients
- Search by hostname or username
- View last scan info and detection counts
- Click to view client details

### Client Detail (`/clients/:id`)
- Client information (hostname, IP, OS, etc.)
- Recent scan sessions
- All detections for this client
- Resolve individual detections

### Detections (`/detections`)
- All detections across all clients
- Filter by severity, type, and status
- Bulk resolve functionality
- Navigate to client details

## Tech Stack

- React 18 with TypeScript
- Material-UI v5 for components
- Recharts for data visualization
- React Router v6 for navigation
- Axios for API calls

