import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardProps, useTheme } from '@mui/material';

interface AnimatedCardProps extends CardProps {
  delay?: number;
  glowColor?: 'primary' | 'secondary' | 'success' | 'error' | 'warning';
  enableHoverGlow?: boolean;
  children: React.ReactNode;
}

const AnimatedCard: React.FC<AnimatedCardProps> = ({
  delay = 0,
  glowColor,
  enableHoverGlow = false,
  children,
  sx,
  ...props
}) => {
  const theme = useTheme();

  const getGlowStyle = () => {
    if (!glowColor) return {};
    const glowMap = {
      primary: theme.custom.glows.primary,
      secondary: theme.custom.glows.secondary,
      success: theme.custom.glows.success,
      error: theme.custom.glows.error,
      warning: theme.custom.glows.warning,
    };
    return {
      boxShadow: glowMap[glowColor],
    };
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        duration: 0.5,
        delay: delay,
        ease: [0.4, 0, 0.2, 1],
      }}
      whileHover={enableHoverGlow ? { scale: 1.02 } : undefined}
    >
      <Card
        sx={{
          ...getGlowStyle(),
          ...sx,
        }}
        {...props}
      >
        {children}
      </Card>
    </motion.div>
  );
};

export default AnimatedCard;

// Stagger container for multiple animated cards
export const AnimatedCardContainer: React.FC<{
  children: React.ReactNode;
  staggerDelay?: number;
}> = ({ children, staggerDelay = 0.1 }) => {
  return (
    <motion.div
      initial="hidden"
      animate="visible"
      variants={{
        hidden: { opacity: 0 },
        visible: {
          opacity: 1,
          transition: {
            staggerChildren: staggerDelay,
          },
        },
      }}
    >
      {children}
    </motion.div>
  );
};

// Individual item for stagger animation
export const AnimatedCardItem: React.FC<{
  children: React.ReactNode;
}> = ({ children }) => {
  return (
    <motion.div
      variants={{
        hidden: { opacity: 0, y: 20 },
        visible: {
          opacity: 1,
          y: 0,
          transition: {
            duration: 0.5,
            ease: [0.4, 0, 0.2, 1],
          },
        },
      }}
    >
      {children}
    </motion.div>
  );
};

