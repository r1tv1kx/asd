import React from 'react';
import { Box, CircularProgress, LinearProgress, Typography, useTheme } from '@mui/material';
import { motion } from 'framer-motion';

interface AnimatedProgressProps {
  value: number;
  variant?: 'circular' | 'linear';
  size?: number;
  thickness?: number;
  showLabel?: boolean;
  label?: string;
  color?: 'primary' | 'secondary' | 'success' | 'error' | 'warning';
  gradientColors?: [string, string];
  animate?: boolean;
  pulseOnComplete?: boolean;
}

const AnimatedProgress: React.FC<AnimatedProgressProps> = ({
  value,
  variant = 'circular',
  size = 80,
  thickness = 4,
  showLabel = true,
  label,
  color = 'primary',
  gradientColors,
  animate = true,
  pulseOnComplete = true,
}) => {
  const theme = useTheme();
  const isComplete = value >= 100;

  const getGradientId = () => `progress-gradient-${Math.random().toString(36).substr(2, 9)}`;
  const gradientId = getGradientId();

  if (variant === 'linear') {
    return (
      <Box sx={{ width: '100%' }}>
        {(showLabel || label) && (
          <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
            {label && (
              <Typography variant="body2" color="text.secondary">
                {label}
              </Typography>
            )}
            {showLabel && (
              <Typography variant="body2" fontWeight={600} color={`${color}.main`}>
                {Math.round(value)}%
              </Typography>
            )}
          </Box>
        )}
        <motion.div
          initial={animate ? { scaleX: 0 } : undefined}
          animate={animate ? { scaleX: 1 } : undefined}
          transition={{ duration: 0.5, ease: [0.4, 0, 0.2, 1] }}
          style={{ originX: 0 }}
        >
          <Box
            sx={{
              position: 'relative',
              height: thickness * 2,
              borderRadius: thickness,
              bgcolor: `rgba(99, 102, 241, 0.15)`,
              overflow: 'hidden',
            }}
          >
            {gradientColors && (
              <svg width="0" height="0">
                <defs>
                  <linearGradient id={gradientId} x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor={gradientColors[0]} />
                    <stop offset="100%" stopColor={gradientColors[1]} />
                  </linearGradient>
                </defs>
              </svg>
            )}
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${Math.min(value, 100)}%` }}
              transition={{ duration: 1, ease: [0.4, 0, 0.2, 1] }}
              style={{
                height: '100%',
                borderRadius: thickness,
                background: gradientColors
                  ? `url(#${gradientId})`
                  : theme.custom.gradients.primary,
              }}
            />
            {isComplete && pulseOnComplete && (
              <motion.div
                initial={{ opacity: 0.5 }}
                animate={{ opacity: [0.5, 0, 0.5] }}
                transition={{ duration: 2, repeat: Infinity }}
                style={{
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  right: 0,
                  bottom: 0,
                  background: 'rgba(255, 255, 255, 0.3)',
                  borderRadius: thickness,
                }}
              />
            )}
          </Box>
        </motion.div>
      </Box>
    );
  }

  // Circular variant
  return (
    <Box
      sx={{
        position: 'relative',
        display: 'inline-flex',
        width: size,
        height: size,
      }}
    >
      {/* Background circle */}
      <CircularProgress
        variant="determinate"
        value={100}
        size={size}
        thickness={thickness}
        sx={{
          color: 'rgba(99, 102, 241, 0.15)',
          position: 'absolute',
        }}
      />

      {/* Foreground animated circle */}
      <motion.div
        initial={animate ? { rotate: -90 } : undefined}
        animate={animate ? { rotate: -90 } : undefined}
        style={{
          position: 'absolute',
          width: size,
          height: size,
        }}
      >
        <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
          <defs>
            <linearGradient id={gradientId} x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor={gradientColors?.[0] || theme.palette[color].main} />
              <stop offset="100%" stopColor={gradientColors?.[1] || theme.palette[color].light} />
            </linearGradient>
          </defs>
          <motion.circle
            cx={size / 2}
            cy={size / 2}
            r={(size - thickness * 2) / 2}
            fill="none"
            stroke={`url(#${gradientId})`}
            strokeWidth={thickness * 2}
            strokeLinecap="round"
            strokeDasharray={Math.PI * (size - thickness * 2)}
            initial={{ strokeDashoffset: Math.PI * (size - thickness * 2) }}
            animate={{
              strokeDashoffset:
                Math.PI * (size - thickness * 2) * (1 - Math.min(value, 100) / 100),
            }}
            transition={{ duration: 1, ease: [0.4, 0, 0.2, 1] }}
          />
        </svg>
      </motion.div>

      {/* Glow effect when complete */}
      {isComplete && pulseOnComplete && (
        <motion.div
          initial={{ scale: 1, opacity: 0 }}
          animate={{ scale: [1, 1.1, 1], opacity: [0, 0.5, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          style={{
            position: 'absolute',
            width: size,
            height: size,
            borderRadius: '50%',
            boxShadow: theme.custom.glows[color],
          }}
        />
      )}

      {/* Center label */}
      {showLabel && (
        <Box
          sx={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.5, type: 'spring', stiffness: 200 }}
          >
            <Typography
              variant="body1"
              fontWeight={700}
              sx={{
                fontSize: size * 0.2,
                color: `${color}.main`,
              }}
            >
              {Math.round(value)}%
            </Typography>
          </motion.div>
        </Box>
      )}
    </Box>
  );
};

export default AnimatedProgress;

// Smaller inline progress indicator
export const MiniProgress: React.FC<{
  value: number;
  color?: 'primary' | 'secondary' | 'success' | 'error' | 'warning';
  width?: number;
}> = ({ value, color = 'primary', width = 60 }) => {
  const theme = useTheme();

  return (
    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
      <Box
        sx={{
          width,
          height: 6,
          bgcolor: 'rgba(99, 102, 241, 0.15)',
          borderRadius: 3,
          overflow: 'hidden',
        }}
      >
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${Math.min(value, 100)}%` }}
          transition={{ duration: 0.5, ease: [0.4, 0, 0.2, 1] }}
          style={{
            height: '100%',
            backgroundColor: theme.palette[color].main,
            borderRadius: 3,
          }}
        />
      </Box>
      <Typography variant="caption" color="text.secondary" sx={{ minWidth: 30 }}>
        {Math.round(value)}%
      </Typography>
    </Box>
  );
};

