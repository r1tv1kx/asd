import React, { useMemo } from 'react';
import { Box, Typography, Tooltip, useTheme } from '@mui/material';
import { motion } from 'framer-motion';
import { format, startOfYear, endOfYear, eachDayOfInterval, getDay, getWeek, isSameDay } from 'date-fns';

interface HeatmapData {
  date: string; // YYYY-MM-DD format
  value: number;
}

interface CalendarHeatmapProps {
  data: HeatmapData[];
  year?: number;
  colorScale?: string[];
  onDayClick?: (date: string, value: number) => void;
  showMonthLabels?: boolean;
  showWeekdayLabels?: boolean;
  cellSize?: number;
  cellGap?: number;
}

const CalendarHeatmap: React.FC<CalendarHeatmapProps> = ({
  data,
  year = new Date().getFullYear(),
  colorScale,
  onDayClick,
  showMonthLabels = true,
  showWeekdayLabels = true,
  cellSize = 12,
  cellGap = 3,
}) => {
  const theme = useTheme();

  // Default color scale (light to dark based on theme)
  const defaultColorScale = [
    'rgba(99, 102, 241, 0.05)',  // Empty/zero
    'rgba(99, 102, 241, 0.2)',   // Low
    'rgba(99, 102, 241, 0.4)',   // Medium-low
    'rgba(99, 102, 241, 0.6)',   // Medium
    'rgba(99, 102, 241, 0.8)',   // Medium-high
    '#6366f1',                    // High
  ];

  const colors = colorScale || defaultColorScale;

  // Create a map for quick lookup
  const dataMap = useMemo(() => {
    const map = new Map<string, number>();
    data.forEach((item) => {
      map.set(item.date, item.value);
    });
    return map;
  }, [data]);

  // Get max value for scaling
  const maxValue = useMemo(() => {
    return Math.max(...data.map((d) => d.value), 1);
  }, [data]);

  // Generate all days of the year
  const yearStart = startOfYear(new Date(year, 0, 1));
  const yearEnd = endOfYear(new Date(year, 0, 1));
  const allDays = eachDayOfInterval({ start: yearStart, end: yearEnd });

  // Group days by week
  const weeks = useMemo(() => {
    const weekMap = new Map<number, Date[]>();
    allDays.forEach((day) => {
      const weekNum = getWeek(day, { weekStartsOn: 0 });
      // Use a unique key that combines week number and month to handle year boundaries
      const monthOffset = day.getMonth() < 1 && weekNum > 50 ? -1 : 0;
      const uniqueWeekKey = weekNum + monthOffset * 100 + (day.getMonth() * 1000);
      
      if (!weekMap.has(uniqueWeekKey)) {
        weekMap.set(uniqueWeekKey, []);
      }
      weekMap.get(uniqueWeekKey)!.push(day);
    });
    
    // Sort weeks and convert to array
    return Array.from(weekMap.entries())
      .sort((a, b) => {
        const aFirst = a[1][0];
        const bFirst = b[1][0];
        return aFirst.getTime() - bFirst.getTime();
      })
      .map(([_, days]) => days);
  }, [allDays]);

  // Get color for a value
  const getColor = (value: number): string => {
    if (value === 0) return colors[0];
    const ratio = value / maxValue;
    const index = Math.min(Math.floor(ratio * (colors.length - 1)) + 1, colors.length - 1);
    return colors[index];
  };

  // Month labels
  const monthLabels = useMemo(() => {
    const labels: { label: string; position: number }[] = [];
    let currentMonth = -1;
    let weekPosition = 0;

    weeks.forEach((week) => {
      const firstDayOfWeek = week[0];
      const month = firstDayOfWeek.getMonth();
      
      if (month !== currentMonth) {
        labels.push({
          label: format(firstDayOfWeek, 'MMM'),
          position: weekPosition,
        });
        currentMonth = month;
      }
      weekPosition++;
    });

    return labels;
  }, [weeks]);

  const weekdayLabels = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const totalWidth = weeks.length * (cellSize + cellGap);

  return (
    <Box sx={{ overflowX: 'auto', pb: 2 }}>
      {/* Month labels */}
      {showMonthLabels && (
        <Box
          sx={{
            display: 'flex',
            ml: showWeekdayLabels ? '30px' : 0,
            mb: 1,
            position: 'relative',
            height: 20,
            width: totalWidth,
          }}
        >
          {monthLabels.map((month, index) => (
            <Typography
              key={`${month.label}-${index}`}
              variant="caption"
              sx={{
                position: 'absolute',
                left: month.position * (cellSize + cellGap),
                color: 'text.secondary',
                fontSize: '0.7rem',
              }}
            >
              {month.label}
            </Typography>
          ))}
        </Box>
      )}

      <Box sx={{ display: 'flex' }}>
        {/* Weekday labels */}
        {showWeekdayLabels && (
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              gap: `${cellGap}px`,
              mr: 1,
              width: 24,
            }}
          >
            {weekdayLabels.map((day, index) => (
              <Typography
                key={day}
                variant="caption"
                sx={{
                  height: cellSize,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'flex-end',
                  color: 'text.secondary',
                  fontSize: '0.6rem',
                  visibility: index % 2 === 1 ? 'visible' : 'hidden',
                }}
              >
                {day}
              </Typography>
            ))}
          </Box>
        )}

        {/* Heatmap grid */}
        <Box sx={{ display: 'flex', gap: `${cellGap}px` }}>
          {weeks.map((week, weekIndex) => (
            <Box
              key={weekIndex}
              sx={{
                display: 'flex',
                flexDirection: 'column',
                gap: `${cellGap}px`,
              }}
            >
              {/* Fill empty days at the start of the first week */}
              {weekIndex === 0 &&
                Array.from({ length: getDay(week[0]) }).map((_, i) => (
                  <Box
                    key={`empty-start-${i}`}
                    sx={{
                      width: cellSize,
                      height: cellSize,
                    }}
                  />
                ))}

              {week.map((day) => {
                const dateStr = format(day, 'yyyy-MM-dd');
                const value = dataMap.get(dateStr) || 0;
                const color = getColor(value);

                return (
                  <Tooltip
                    key={dateStr}
                    title={
                      <Box>
                        <Typography variant="body2" fontWeight={600}>
                          {format(day, 'MMM d, yyyy')}
                        </Typography>
                        <Typography variant="body2">
                          {value} detection{value !== 1 ? 's' : ''}
                        </Typography>
                      </Box>
                    }
                    arrow
                    placement="top"
                  >
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{
                        delay: weekIndex * 0.01,
                        duration: 0.2,
                      }}
                    >
                      <Box
                        onClick={() => onDayClick?.(dateStr, value)}
                        sx={{
                          width: cellSize,
                          height: cellSize,
                          bgcolor: color,
                          borderRadius: '3px',
                          cursor: onDayClick ? 'pointer' : 'default',
                          transition: 'all 0.2s ease',
                          border: isSameDay(day, new Date())
                            ? '2px solid #f472b6'
                            : '1px solid rgba(99, 102, 241, 0.1)',
                          '&:hover': {
                            transform: 'scale(1.3)',
                            boxShadow: '0 0 10px rgba(99, 102, 241, 0.5)',
                            zIndex: 1,
                          },
                        }}
                      />
                    </motion.div>
                  </Tooltip>
                );
              })}

              {/* Fill empty days at the end of the last week */}
              {weekIndex === weeks.length - 1 &&
                Array.from({ length: 6 - getDay(week[week.length - 1]) }).map((_, i) => (
                  <Box
                    key={`empty-end-${i}`}
                    sx={{
                      width: cellSize,
                      height: cellSize,
                    }}
                  />
                ))}
            </Box>
          ))}
        </Box>
      </Box>

      {/* Legend */}
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'flex-end',
          gap: 1,
          mt: 2,
          ml: showWeekdayLabels ? '30px' : 0,
        }}
      >
        <Typography variant="caption" color="text.secondary">
          Less
        </Typography>
        {colors.map((color, index) => (
          <Box
            key={index}
            sx={{
              width: cellSize,
              height: cellSize,
              bgcolor: color,
              borderRadius: '2px',
              border: '1px solid rgba(99, 102, 241, 0.1)',
            }}
          />
        ))}
        <Typography variant="caption" color="text.secondary">
          More
        </Typography>
      </Box>
    </Box>
  );
};

export default CalendarHeatmap;

