import React, { useEffect, useState, useRef } from 'react';
import { Typography, TypographyProps } from '@mui/material';

interface CountUpProps extends Omit<TypographyProps, 'children'> {
  end: number;
  start?: number;
  duration?: number;
  decimals?: number;
  prefix?: string;
  suffix?: string;
  separator?: string;
  useGrouping?: boolean;
}

const easeOutExpo = (t: number): number => {
  return t === 1 ? 1 : 1 - Math.pow(2, -10 * t);
};

const CountUp: React.FC<CountUpProps> = ({
  end,
  start = 0,
  duration = 1.5,
  decimals = 0,
  prefix = '',
  suffix = '',
  separator = ',',
  useGrouping = true,
  ...typographyProps
}) => {
  const [currentValue, setCurrentValue] = useState(start);
  const startTime = useRef<number | null>(null);
  const animationFrame = useRef<number | null>(null);
  const previousEnd = useRef(end);

  const formatNumber = (num: number): string => {
    const fixed = num.toFixed(decimals);
    if (!useGrouping) return `${prefix}${fixed}${suffix}`;
    
    const parts = fixed.split('.');
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, separator);
    return `${prefix}${parts.join('.')}${suffix}`;
  };

  useEffect(() => {
    // Reset if the end value changes
    if (previousEnd.current !== end) {
      previousEnd.current = end;
      startTime.current = null;
    }

    const animate = (timestamp: number) => {
      if (startTime.current === null) {
        startTime.current = timestamp;
      }

      const elapsed = timestamp - startTime.current;
      const progress = Math.min(elapsed / (duration * 1000), 1);
      const easedProgress = easeOutExpo(progress);
      
      const value = start + (end - start) * easedProgress;
      setCurrentValue(value);

      if (progress < 1) {
        animationFrame.current = requestAnimationFrame(animate);
      }
    };

    animationFrame.current = requestAnimationFrame(animate);

    return () => {
      if (animationFrame.current !== null) {
        cancelAnimationFrame(animationFrame.current);
      }
    };
  }, [end, start, duration]);

  return (
    <Typography {...typographyProps}>
      {formatNumber(currentValue)}
    </Typography>
  );
};

export default CountUp;

// Hook for count up functionality (for custom implementations)
export const useCountUp = (
  end: number,
  options?: {
    start?: number;
    duration?: number;
    decimals?: number;
  }
) => {
  const { start = 0, duration = 1.5, decimals = 0 } = options || {};
  const [value, setValue] = useState(start);
  const startTime = useRef<number | null>(null);
  const animationFrame = useRef<number | null>(null);

  useEffect(() => {
    startTime.current = null;

    const animate = (timestamp: number) => {
      if (startTime.current === null) {
        startTime.current = timestamp;
      }

      const elapsed = timestamp - startTime.current;
      const progress = Math.min(elapsed / (duration * 1000), 1);
      const easedProgress = easeOutExpo(progress);
      
      const newValue = start + (end - start) * easedProgress;
      setValue(Number(newValue.toFixed(decimals)));

      if (progress < 1) {
        animationFrame.current = requestAnimationFrame(animate);
      }
    };

    animationFrame.current = requestAnimationFrame(animate);

    return () => {
      if (animationFrame.current !== null) {
        cancelAnimationFrame(animationFrame.current);
      }
    };
  }, [end, start, duration, decimals]);

  return value;
};

