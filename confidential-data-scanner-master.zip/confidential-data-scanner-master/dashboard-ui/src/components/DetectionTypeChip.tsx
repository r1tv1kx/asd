import React from 'react';
import { Chip, ChipProps } from '@mui/material';

interface DetectionTypeChipProps {
  type: string;
  size?: ChipProps['size'];
}

const typeConfig: Record<string, { label: string; color: string; bgColor: string }> = {
  AADHAR: {
    label: 'Aadhar',
    color: '#6366f1',
    bgColor: 'rgba(99, 102, 241, 0.15)',
  },
  PAN: {
    label: 'PAN',
    color: '#8b5cf6',
    bgColor: 'rgba(139, 92, 246, 0.15)',
  },
  US_SSN: {
    label: 'SSN',
    color: '#ec4899',
    bgColor: 'rgba(236, 72, 153, 0.15)',
  },
  CREDIT_CARD: {
    label: 'Credit Card',
    color: '#f59e0b',
    bgColor: 'rgba(245, 158, 11, 0.15)',
  },
  EMAIL_ADDRESS: {
    label: 'Email',
    color: '#14b8a6',
    bgColor: 'rgba(20, 184, 166, 0.15)',
  },
  PHONE_NUMBER: {
    label: 'Phone',
    color: '#06b6d4',
    bgColor: 'rgba(6, 182, 212, 0.15)',
  },
  INDIAN_PASSPORT: {
    label: 'Passport',
    color: '#84cc16',
    bgColor: 'rgba(132, 204, 22, 0.15)',
  },
  VOTER_ID: {
    label: 'Voter ID',
    color: '#f472b6',
    bgColor: 'rgba(244, 114, 182, 0.15)',
  },
  DRIVING_LICENSE: {
    label: 'DL',
    color: '#a78bfa',
    bgColor: 'rgba(167, 139, 250, 0.15)',
  },
};

const defaultConfig = {
  label: 'Unknown',
  color: '#94a3b8',
  bgColor: 'rgba(148, 163, 184, 0.15)',
};

export default function DetectionTypeChip({ type, size = 'small' }: DetectionTypeChipProps) {
  const config = typeConfig[type] || { ...defaultConfig, label: type };

  return (
    <Chip
      label={config.label}
      size={size}
      sx={{
        color: config.color,
        backgroundColor: config.bgColor,
        fontWeight: 500,
        border: `1px solid ${config.color}30`,
      }}
    />
  );
}

