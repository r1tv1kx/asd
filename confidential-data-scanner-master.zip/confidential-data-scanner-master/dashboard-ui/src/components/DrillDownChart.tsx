import React, { useState } from 'react';
import { Box, Typography, IconButton, Breadcrumbs, Link, useTheme, Chip } from '@mui/material';
import { ArrowBack as ArrowBackIcon, NavigateNext as NavigateNextIcon } from '@mui/icons-material';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';
import { motion, AnimatePresence } from 'framer-motion';

interface DrillDownLevel {
  id: string;
  label: string;
}

interface DrillDownDataItem {
  name: string;
  value: number;
  color?: string;
  id: string;
  children?: DrillDownDataItem[];
}

interface DrillDownChartProps {
  data: DrillDownDataItem[];
  title: string;
  type?: 'pie' | 'bar';
  height?: number;
  onDrillDown?: (item: DrillDownDataItem, level: number) => void;
  onBack?: () => void;
  colors?: string[];
}

const DEFAULT_COLORS = [
  '#6366f1', // primary
  '#f472b6', // secondary
  '#10b981', // success
  '#f59e0b', // warning
  '#ef4444', // error
  '#8b5cf6', // purple
  '#06b6d4', // cyan
  '#ec4899', // pink
  '#14b8a6', // teal
  '#f97316', // orange
];

const DrillDownChart: React.FC<DrillDownChartProps> = ({
  data,
  title,
  type = 'pie',
  height = 300,
  onDrillDown,
  colors = DEFAULT_COLORS,
}) => {
  const theme = useTheme();
  const [currentData, setCurrentData] = useState<DrillDownDataItem[]>(data);
  const [breadcrumbs, setBreadcrumbs] = useState<DrillDownLevel[]>([{ id: 'root', label: 'All' }]);
  const [animationKey, setAnimationKey] = useState(0);

  const handleClick = (item: DrillDownDataItem, level: number) => {
    if (item.children && item.children.length > 0) {
      setCurrentData(item.children);
      setBreadcrumbs([...breadcrumbs, { id: item.id, label: item.name }]);
      setAnimationKey((prev) => prev + 1);
      onDrillDown?.(item, level);
    }
  };

  const handleBreadcrumbClick = (index: number) => {
    if (index === 0) {
      setCurrentData(data);
      setBreadcrumbs([{ id: 'root', label: 'All' }]);
    } else {
      // Navigate to specific level
      let newData = data;
      const newBreadcrumbs = breadcrumbs.slice(0, index + 1);
      
      for (let i = 1; i < newBreadcrumbs.length; i++) {
        const found = newData.find((d) => d.id === newBreadcrumbs[i].id);
        if (found?.children) {
          newData = found.children;
        }
      }
      
      setCurrentData(newData);
      setBreadcrumbs(newBreadcrumbs);
    }
    setAnimationKey((prev) => prev + 1);
  };

  const handleBack = () => {
    if (breadcrumbs.length > 1) {
      handleBreadcrumbClick(breadcrumbs.length - 2);
    }
  };

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <Box
          sx={{
            bgcolor: 'rgba(18, 18, 31, 0.95)',
            border: '1px solid rgba(99, 102, 241, 0.2)',
            borderRadius: 2,
            p: 1.5,
            backdropFilter: 'blur(10px)',
          }}
        >
          <Typography variant="body2" fontWeight={600}>
            {data.name}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Count: {data.value.toLocaleString()}
          </Typography>
          {data.children && (
            <Typography variant="caption" color="primary">
              Click to drill down
            </Typography>
          )}
        </Box>
      );
    }
    return null;
  };

  const renderPieChart = () => (
    <ResponsiveContainer width="100%" height={height}>
      <PieChart>
        <Pie
          data={currentData}
          cx="50%"
          cy="50%"
          innerRadius={60}
          outerRadius={100}
          paddingAngle={3}
          dataKey="value"
          onClick={(data, index) => handleClick(currentData[index], breadcrumbs.length)}
          style={{ cursor: 'pointer' }}
        >
          {currentData.map((entry, index) => (
            <Cell
              key={`cell-${index}`}
              fill={entry.color || colors[index % colors.length]}
              stroke="transparent"
              style={{
                filter: 'drop-shadow(0px 2px 4px rgba(0,0,0,0.3))',
                transition: 'all 0.3s ease',
              }}
            />
          ))}
        </Pie>
        <Tooltip content={<CustomTooltip />} />
      </PieChart>
    </ResponsiveContainer>
  );

  const renderBarChart = () => (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart
        data={currentData}
        layout="vertical"
        margin={{ top: 5, right: 30, left: 80, bottom: 5 }}
      >
        <CartesianGrid strokeDasharray="3 3" stroke="rgba(99, 102, 241, 0.1)" horizontal={false} />
        <XAxis type="number" stroke="#94a3b8" />
        <YAxis
          type="category"
          dataKey="name"
          stroke="#94a3b8"
          tick={{ fill: '#94a3b8', fontSize: 12 }}
          width={70}
        />
        <Tooltip content={<CustomTooltip />} />
        <Bar
          dataKey="value"
          radius={[0, 4, 4, 0]}
          onClick={(data, index) => handleClick(currentData[index], breadcrumbs.length)}
          style={{ cursor: 'pointer' }}
        >
          {currentData.map((entry, index) => (
            <Cell
              key={`cell-${index}`}
              fill={entry.color || colors[index % colors.length]}
            />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );

  const total = currentData.reduce((sum, item) => sum + item.value, 0);

  return (
    <Box>
      {/* Header with breadcrumbs */}
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 2, flexWrap: 'wrap', gap: 1 }}>
        {breadcrumbs.length > 1 && (
          <IconButton size="small" onClick={handleBack} sx={{ mr: 1 }}>
            <ArrowBackIcon />
          </IconButton>
        )}
        <Typography variant="h6" sx={{ mr: 2 }}>
          {title}
        </Typography>
        <Breadcrumbs separator={<NavigateNextIcon fontSize="small" />} sx={{ flex: 1 }}>
          {breadcrumbs.map((crumb, index) => (
            <Link
              key={crumb.id}
              component="button"
              variant="body2"
              underline={index < breadcrumbs.length - 1 ? 'hover' : 'none'}
              color={index === breadcrumbs.length - 1 ? 'primary' : 'text.secondary'}
              onClick={() => index < breadcrumbs.length - 1 && handleBreadcrumbClick(index)}
              sx={{
                cursor: index < breadcrumbs.length - 1 ? 'pointer' : 'default',
                fontWeight: index === breadcrumbs.length - 1 ? 600 : 400,
              }}
            >
              {crumb.label}
            </Link>
          ))}
        </Breadcrumbs>
      </Box>

      {/* Chart */}
      {/* @ts-ignore */}
      <AnimatePresence mode="wait">
        <motion.div
          key={animationKey}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ duration: 0.3 }}
        >
          {type === 'pie' ? renderPieChart() : renderBarChart()}
        </motion.div>
      </AnimatePresence>

      {/* Legend */}
      <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mt: 2, justifyContent: 'center' }}>
        {currentData.slice(0, 6).map((item, index) => (
          <Chip
            key={item.id}
            label={`${item.name}: ${item.value.toLocaleString()} (${((item.value / total) * 100).toFixed(1)}%)`}
            size="small"
            onClick={() => handleClick(item, breadcrumbs.length)}
            sx={{
              bgcolor: `${item.color || colors[index % colors.length]}20`,
              color: item.color || colors[index % colors.length],
              border: `1px solid ${item.color || colors[index % colors.length]}40`,
              cursor: item.children ? 'pointer' : 'default',
              '&:hover': item.children
                ? {
                    bgcolor: `${item.color || colors[index % colors.length]}30`,
                  }
                : {},
            }}
          />
        ))}
        {currentData.length > 6 && (
          <Chip
            label={`+${currentData.length - 6} more`}
            size="small"
            variant="outlined"
          />
        )}
      </Box>
    </Box>
  );
};

export default DrillDownChart;

