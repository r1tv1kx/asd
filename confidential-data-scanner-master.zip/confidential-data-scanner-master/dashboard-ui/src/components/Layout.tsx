import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  Box,
  Drawer,
  AppBar,
  Toolbar,
  List,
  Typography,
  Divider,
  IconButton,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  useTheme,
  Chip,
  Tooltip,
} from '@mui/material';
import {
  Menu as MenuIcon,
  Dashboard as DashboardIcon,
  Computer as ComputerIcon,
  Warning as WarningIcon,
  Shield as ShieldIcon,
  Settings as SettingsIcon,
  DocumentScanner as ScanIcon,
  Analytics as AnalyticsIcon,
  Brightness4 as ThemeIcon,
} from '@mui/icons-material';
import { motion, AnimatePresence } from 'framer-motion';

const drawerWidth = 260;

interface LayoutProps {
  children: React.ReactNode;
}

const menuItems = [
  { text: 'Dashboard', icon: <DashboardIcon />, path: '/' },
  { text: 'Analytics', icon: <AnalyticsIcon />, path: '/analytics', badge: 'New' },
  { text: 'Clients', icon: <ComputerIcon />, path: '/clients' },
  { text: 'Detections', icon: <WarningIcon />, path: '/detections' },
  { text: 'Quick Scan', icon: <ScanIcon />, path: '/scan' },
  { text: 'Settings', icon: <SettingsIcon />, path: '/settings' },
];

export default function Layout({ children }: LayoutProps) {
  const theme = useTheme();
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const drawer = (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* Logo Section */}
      <Toolbar
        sx={{
          px: 2,
          py: 2.5,
          borderBottom: '1px solid rgba(99, 102, 241, 0.1)',
        }}
      >
        <motion.div
          initial={{ rotate: -180, opacity: 0 }}
          animate={{ rotate: 0, opacity: 1 }}
          transition={{ duration: 0.5, type: 'spring' }}
        >
          <Box
            sx={{
              p: 1,
              borderRadius: 2,
              background: theme.custom.gradients.primary,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              mr: 1.5,
              boxShadow: theme.custom.glows.primary,
            }}
          >
            <ShieldIcon sx={{ color: 'white', fontSize: 24 }} />
          </Box>
        </motion.div>
        <Box>
        <Typography
          variant="h6"
          noWrap
          sx={{
            fontWeight: 700,
              background: theme.custom.gradients.accent,
            backgroundClip: 'text',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
              lineHeight: 1.2,
          }}
        >
          Data Scanner
        </Typography>
          <Typography variant="caption" color="text.secondary">
            Security Dashboard
          </Typography>
        </Box>
      </Toolbar>

      {/* Navigation */}
      <List sx={{ px: 1.5, py: 2, flex: 1 }}>
        {menuItems.map((item, index) => {
          const isActive =
            location.pathname === item.path ||
            (item.path !== '/' && location.pathname.startsWith(item.path));

          return (
            <motion.div
              key={item.text}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <ListItem disablePadding sx={{ mb: 0.5 }}>
              <ListItemButton
                onClick={() => navigate(item.path)}
                sx={{
                  borderRadius: 2,
                    py: 1.25,
                    position: 'relative',
                    overflow: 'hidden',
                    backgroundColor: isActive ? 'rgba(99, 102, 241, 0.12)' : 'transparent',
                    transition: 'all 0.2s ease',
                    '&::before': isActive
                      ? {
                          content: '""',
                          position: 'absolute',
                          left: 0,
                          top: '50%',
                          transform: 'translateY(-50%)',
                          width: 4,
                          height: '60%',
                          borderRadius: '0 4px 4px 0',
                          background: theme.custom.gradients.primary,
                        }
                      : {},
                  '&:hover': {
                    backgroundColor: isActive
                        ? 'rgba(99, 102, 241, 0.18)'
                      : 'rgba(99, 102, 241, 0.08)',
                  },
                }}
              >
                <ListItemIcon
                  sx={{
                    color: isActive ? 'primary.main' : 'text.secondary',
                    minWidth: 40,
                      transition: 'color 0.2s ease',
                  }}
                >
                  {item.icon}
                </ListItemIcon>
                <ListItemText
                  primary={item.text}
                  primaryTypographyProps={{
                    fontWeight: isActive ? 600 : 400,
                    color: isActive ? 'primary.main' : 'text.primary',
                      fontSize: '0.9rem',
                    }}
                  />
                  {item.badge && (
                    <Chip
                      label={item.badge}
                      size="small"
                      sx={{
                        height: 20,
                        fontSize: '0.65rem',
                        fontWeight: 600,
                        background: theme.custom.gradients.accent,
                        color: 'white',
                  }}
                />
                  )}
              </ListItemButton>
            </ListItem>
            </motion.div>
          );
        })}
      </List>

      {/* Footer */}
      <Box
        sx={{
          p: 2,
          borderTop: '1px solid rgba(99, 102, 241, 0.1)',
        }}
      >
        <Box
          sx={{
            p: 1.5,
            borderRadius: 2,
            bgcolor: 'rgba(99, 102, 241, 0.05)',
            border: '1px solid rgba(99, 102, 241, 0.1)',
          }}
        >
          <Typography variant="caption" color="text.secondary" display="block">
            Confidential Data Scanner
          </Typography>
          <Typography variant="caption" color="primary" fontWeight={500}>
            v1.1.0 - Enhanced UI
        </Typography>
        </Box>
      </Box>
    </Box>
  );

  // Get current page title
  const currentPage = menuItems.find(
    (item) =>
      location.pathname === item.path ||
      (item.path !== '/' && location.pathname.startsWith(item.path))
  );

  return (
    <Box sx={{ display: 'flex', width: '100%' }}>
      <AppBar
        position="fixed"
        sx={{
          width: { sm: `calc(100% - ${drawerWidth}px)` },
          ml: { sm: `${drawerWidth}px` },
          backgroundColor: 'rgba(10, 10, 18, 0.8)',
          backdropFilter: 'blur(20px)',
          borderBottom: '1px solid rgba(99, 102, 241, 0.1)',
          boxShadow: 'none',
        }}
      >
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            edge="start"
            onClick={handleDrawerToggle}
            sx={{ mr: 2, display: { sm: 'none' } }}
          >
            <MenuIcon />
          </IconButton>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
            {currentPage?.icon &&
              React.cloneElement(currentPage.icon as React.ReactElement, {
                sx: { color: 'primary.main', fontSize: 20 },
              })}
            <Typography
              variant="h6"
              noWrap
              component="div"
              sx={{ color: 'text.primary', fontWeight: 600 }}
            >
              {currentPage?.text || 'Dashboard'}
          </Typography>
          </Box>
          <Box sx={{ flex: 1 }} />
          <Tooltip title="Theme options coming soon">
            <IconButton size="small" sx={{ color: 'text.secondary' }}>
              <ThemeIcon fontSize="small" />
            </IconButton>
          </Tooltip>
        </Toolbar>
      </AppBar>
      <Box
        component="nav"
        sx={{ width: { sm: drawerWidth }, flexShrink: { sm: 0 } }}
      >
        <Drawer
          variant="temporary"
          open={mobileOpen}
          onClose={handleDrawerToggle}
          ModalProps={{ keepMounted: true }}
          sx={{
            display: { xs: 'block', sm: 'none' },
            '& .MuiDrawer-paper': {
              boxSizing: 'border-box',
              width: drawerWidth,
              backgroundColor: 'background.paper',
              borderRight: '1px solid rgba(99, 102, 241, 0.1)',
            },
          }}
        >
          {drawer}
        </Drawer>
        <Drawer
          variant="permanent"
          sx={{
            display: { xs: 'none', sm: 'block' },
            '& .MuiDrawer-paper': {
              boxSizing: 'border-box',
              width: drawerWidth,
              backgroundColor: 'background.paper',
              borderRight: '1px solid rgba(99, 102, 241, 0.1)',
              backgroundImage: 'none',
            },
          }}
          open
        >
          {drawer}
        </Drawer>
      </Box>
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          p: 3,
          width: { sm: `calc(100% - ${drawerWidth}px)` },
          minHeight: '100vh',
          backgroundColor: 'background.default',
        }}
      >
        <Toolbar />
        {/* @ts-ignore */}
        <AnimatePresence mode="wait">
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
        {children}
          </motion.div>
        </AnimatePresence>
      </Box>
    </Box>
  );
}
