import React from 'react';
import { Box, Skeleton, Card, CardContent, Grid } from '@mui/material';
import { motion } from 'framer-motion';

// Shimmer animation keyframes
const shimmerAnimation = {
  animate: {
    backgroundPosition: ['200% 0', '-200% 0'],
  },
  transition: {
    duration: 1.5,
    repeat: Infinity,
    ease: 'linear',
  },
};

interface SkeletonProps {
  animation?: 'wave' | 'pulse' | false;
}

// Card skeleton with gradient shimmer
export const CardSkeleton: React.FC<SkeletonProps & { height?: number }> = ({
  animation = 'wave',
  height = 150,
}) => {
  return (
    <Card sx={{ height }}>
      <CardContent>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
          <Skeleton
            animation={animation}
            variant="text"
            width="40%"
            height={20}
          />
          <Skeleton
            animation={animation}
            variant="circular"
            width={40}
            height={40}
          />
        </Box>
        <Skeleton
          animation={animation}
          variant="text"
          width="60%"
          height={40}
        />
        <Skeleton
          animation={animation}
          variant="text"
          width="30%"
          height={20}
        />
      </CardContent>
    </Card>
  );
};

// Stat card skeleton
export const StatCardSkeleton: React.FC<SkeletonProps> = ({
  animation = 'wave',
}) => {
  return (
    <Card
      sx={{
        height: '100%',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      <Box
        sx={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          height: 4,
          bgcolor: 'rgba(99, 102, 241, 0.3)',
        }}
      />
      <CardContent sx={{ p: 3 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <Box sx={{ flex: 1 }}>
            <Skeleton animation={animation} variant="text" width="50%" height={16} />
            <Skeleton animation={animation} variant="text" width="40%" height={48} sx={{ my: 1 }} />
            <Skeleton animation={animation} variant="text" width="60%" height={14} />
            <Box sx={{ mt: 2 }}>
              <Skeleton animation={animation} variant="rectangular" width="100%" height={30} sx={{ borderRadius: 1 }} />
            </Box>
          </Box>
          <Skeleton animation={animation} variant="rounded" width={48} height={48} sx={{ borderRadius: 2 }} />
        </Box>
      </CardContent>
    </Card>
  );
};

// Table skeleton
export const TableSkeleton: React.FC<SkeletonProps & {
  rows?: number;
  columns?: number;
}> = ({ animation = 'wave', rows = 5, columns = 5 }) => {
  return (
    <Box>
      {/* Header */}
      <Box
        sx={{
          display: 'flex',
          gap: 2,
          p: 2,
          bgcolor: 'rgba(99, 102, 241, 0.05)',
          borderRadius: '12px 12px 0 0',
        }}
      >
        {Array.from({ length: columns }).map((_, i) => (
          <Skeleton
            key={`header-${i}`}
            animation={animation}
            variant="text"
            width={`${100 / columns}%`}
            height={20}
          />
        ))}
      </Box>

      {/* Rows */}
      {Array.from({ length: rows }).map((_, rowIndex) => (
        <Box
          key={`row-${rowIndex}`}
          sx={{
            display: 'flex',
            gap: 2,
            p: 2,
            borderBottom: '1px solid rgba(99, 102, 241, 0.08)',
          }}
        >
          {Array.from({ length: columns }).map((_, colIndex) => (
            <Skeleton
              key={`cell-${rowIndex}-${colIndex}`}
              animation={animation}
              variant="text"
              width={`${100 / columns}%`}
              height={24}
            />
          ))}
        </Box>
      ))}
    </Box>
  );
};

// Chart skeleton
export const ChartSkeleton: React.FC<SkeletonProps & {
  height?: number;
  type?: 'bar' | 'line' | 'pie';
}> = ({ animation = 'wave', height = 300, type = 'bar' }) => {
  if (type === 'pie') {
    return (
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          height,
        }}
      >
        <Skeleton
          animation={animation}
          variant="circular"
          width={Math.min(height * 0.7, 200)}
          height={Math.min(height * 0.7, 200)}
        />
      </Box>
    );
  }

  return (
    <Box sx={{ height, display: 'flex', flexDirection: 'column' }}>
      {/* Y-axis labels */}
      <Box sx={{ display: 'flex', flex: 1 }}>
        <Box sx={{ width: 40, display: 'flex', flexDirection: 'column', justifyContent: 'space-between', pr: 1 }}>
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton
              key={`y-${i}`}
              animation={animation}
              variant="text"
              width={30}
              height={12}
            />
          ))}
        </Box>

        {/* Bars or line area */}
        <Box sx={{ flex: 1, display: 'flex', alignItems: 'flex-end', gap: 1, pb: 4 }}>
          {Array.from({ length: 7 }).map((_, i) => (
            <motion.div
              key={`bar-${i}`}
              initial={{ height: 0 }}
              animate={{ height: `${30 + Math.random() * 60}%` }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              style={{ flex: 1 }}
            >
              <Skeleton
                animation={animation}
                variant="rectangular"
                width="100%"
                height="100%"
                sx={{ borderRadius: '4px 4px 0 0' }}
              />
            </motion.div>
          ))}
        </Box>
      </Box>

      {/* X-axis labels */}
      <Box sx={{ display: 'flex', gap: 1, pl: 5 }}>
        {Array.from({ length: 7 }).map((_, i) => (
          <Skeleton
            key={`x-${i}`}
            animation={animation}
            variant="text"
            sx={{ flex: 1 }}
            height={16}
          />
        ))}
      </Box>
    </Box>
  );
};

// Grid of stat card skeletons
export const StatsGridSkeleton: React.FC<{ count?: number }> = ({ count = 4 }) => {
  return (
    <Grid container spacing={3}>
      {Array.from({ length: count }).map((_, i) => (
        <Grid item xs={12} sm={6} md={3} key={i}>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <StatCardSkeleton />
          </motion.div>
        </Grid>
      ))}
    </Grid>
  );
};

// Full page loading skeleton
export const PageSkeleton: React.FC = () => {
  return (
    <Box>
      {/* Header */}
      <Box sx={{ mb: 3 }}>
        <Skeleton variant="text" width={200} height={40} />
        <Skeleton variant="text" width={300} height={20} />
      </Box>

      {/* Stats */}
      <StatsGridSkeleton count={4} />

      {/* Charts */}
      <Grid container spacing={3} sx={{ mt: 1 }}>
        <Grid item xs={12} md={8}>
          <Card>
            <CardContent>
              <Skeleton variant="text" width={150} height={28} sx={{ mb: 2 }} />
              <ChartSkeleton height={300} type="bar" />
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={4}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Skeleton variant="text" width={120} height={28} sx={{ mb: 2 }} />
              <ChartSkeleton height={250} type="pie" />
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default {
  Card: CardSkeleton,
  StatCard: StatCardSkeleton,
  Table: TableSkeleton,
  Chart: ChartSkeleton,
  StatsGrid: StatsGridSkeleton,
  Page: PageSkeleton,
};

