import React from 'react';
import { Chip } from '@mui/material';
import {
  Folder as FolderIcon,
  ContentPaste as ClipboardIcon,
  Usb as UsbIcon,
} from '@mui/icons-material';

interface ScanSourceChipProps {
  source?: 'filesystem' | 'clipboard' | 'usb' | string;
  size?: 'small' | 'medium';
}

const sourceConfig: Record<string, { label: string; color: string; bgColor: string; icon: React.ReactNode }> = {
  filesystem: {
    label: 'File System',
    color: '#818cf8',
    bgColor: 'rgba(129, 140, 248, 0.15)',
    icon: <FolderIcon sx={{ fontSize: 14 }} />,
  },
  clipboard: {
    label: 'Clipboard',
    color: '#f59e0b',
    bgColor: 'rgba(245, 158, 11, 0.15)',
    icon: <ClipboardIcon sx={{ fontSize: 14 }} />,
  },
  usb: {
    label: 'USB Device',
    color: '#10b981',
    bgColor: 'rgba(16, 185, 129, 0.15)',
    icon: <UsbIcon sx={{ fontSize: 14 }} />,
  },
};

export default function ScanSourceChip({ source = 'filesystem', size = 'small' }: ScanSourceChipProps) {
  const config = sourceConfig[source] || sourceConfig.filesystem;

  return (
    <Chip
      size={size}
      icon={config.icon as React.ReactElement}
      label={config.label}
      sx={{
        backgroundColor: config.bgColor,
        color: config.color,
        border: `1px solid ${config.color}30`,
        fontWeight: 500,
        '& .MuiChip-icon': {
          color: config.color,
        },
      }}
    />
  );
}

