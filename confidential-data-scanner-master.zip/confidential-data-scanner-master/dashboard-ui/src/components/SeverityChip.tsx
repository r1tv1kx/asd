import React from 'react';
import { Chip, ChipProps } from '@mui/material';

interface SeverityChipProps {
  severity: 'low' | 'medium' | 'high' | 'critical';
  size?: ChipProps['size'];
}

const severityConfig = {
  low: {
    label: 'Low',
    color: '#22c55e',
    bgColor: 'rgba(34, 197, 94, 0.15)',
  },
  medium: {
    label: 'Medium',
    color: '#f59e0b',
    bgColor: 'rgba(245, 158, 11, 0.15)',
  },
  high: {
    label: 'High',
    color: '#f97316',
    bgColor: 'rgba(249, 115, 22, 0.15)',
  },
  critical: {
    label: 'Critical',
    color: '#ef4444',
    bgColor: 'rgba(239, 68, 68, 0.15)',
  },
};

export default function SeverityChip({ severity, size = 'small' }: SeverityChipProps) {
  const config = severityConfig[severity] || severityConfig.medium;

  return (
    <Chip
      label={config.label}
      size={size}
      sx={{
        color: config.color,
        backgroundColor: config.bgColor,
        fontWeight: 600,
        border: `1px solid ${config.color}30`,
      }}
    />
  );
}

