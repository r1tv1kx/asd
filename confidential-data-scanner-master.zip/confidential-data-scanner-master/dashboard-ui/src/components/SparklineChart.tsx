import React from 'react';
import { Box, useTheme } from '@mui/material';
import { AreaChart, Area, ResponsiveContainer, YAxis } from 'recharts';
import { motion } from 'framer-motion';

interface SparklineChartProps {
  data: number[];
  color?: 'primary' | 'secondary' | 'success' | 'error' | 'warning';
  height?: number;
  showAnimation?: boolean;
  gradientOpacity?: number;
}

const SparklineChart: React.FC<SparklineChartProps> = ({
  data,
  color = 'primary',
  height = 40,
  showAnimation = true,
  gradientOpacity = 0.3,
}) => {
  const theme = useTheme();

  const getColor = () => {
    const colorMap = {
      primary: theme.palette.primary.main,
      secondary: theme.palette.secondary.main,
      success: theme.palette.success.main,
      error: theme.palette.error.main,
      warning: theme.palette.warning.main,
    };
    return colorMap[color];
  };

  const chartColor = getColor();
  const gradientId = `sparkline-gradient-${color}-${Math.random().toString(36).substr(2, 9)}`;

  // Format data for Recharts
  const chartData = data.map((value, index) => ({
    index,
    value,
  }));

  // Calculate domain with some padding
  const minValue = Math.min(...data);
  const maxValue = Math.max(...data);
  const padding = (maxValue - minValue) * 0.1 || 1;

  return (
    <motion.div
      initial={showAnimation ? { opacity: 0, scaleX: 0 } : undefined}
      animate={showAnimation ? { opacity: 1, scaleX: 1 } : undefined}
      transition={{ duration: 0.8, ease: [0.4, 0, 0.2, 1] }}
      style={{ originX: 0 }}
    >
      <Box sx={{ width: '100%', height }}>
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart
            data={chartData}
            margin={{ top: 2, right: 2, left: 2, bottom: 2 }}
          >
            <defs>
              <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
                <stop
                  offset="0%"
                  stopColor={chartColor}
                  stopOpacity={gradientOpacity}
                />
                <stop
                  offset="100%"
                  stopColor={chartColor}
                  stopOpacity={0}
                />
              </linearGradient>
            </defs>
            <YAxis
              hide
              domain={[minValue - padding, maxValue + padding]}
            />
            <Area
              type="monotone"
              dataKey="value"
              stroke={chartColor}
              strokeWidth={2}
              fill={`url(#${gradientId})`}
              isAnimationActive={showAnimation}
              animationDuration={1000}
              animationEasing="ease-out"
            />
          </AreaChart>
        </ResponsiveContainer>
      </Box>
    </motion.div>
  );
};

export default SparklineChart;

// Mini bar variant for compact spaces
export const SparklineBars: React.FC<{
  data: number[];
  color?: 'primary' | 'secondary' | 'success' | 'error' | 'warning';
  height?: number;
  barWidth?: number;
  gap?: number;
}> = ({ data, color = 'primary', height = 30, barWidth = 4, gap = 2 }) => {
  const theme = useTheme();

  const getColor = () => {
    const colorMap = {
      primary: theme.palette.primary.main,
      secondary: theme.palette.secondary.main,
      success: theme.palette.success.main,
      error: theme.palette.error.main,
      warning: theme.palette.warning.main,
    };
    return colorMap[color];
  };

  const maxValue = Math.max(...data, 1);
  const barColor = getColor();

  return (
    <Box
      sx={{
        display: 'flex',
        alignItems: 'flex-end',
        height,
        gap: `${gap}px`,
      }}
    >
      {data.map((value, index) => {
        const barHeight = (value / maxValue) * height;
        return (
          <motion.div
            key={index}
            initial={{ height: 0 }}
            animate={{ height: barHeight }}
            transition={{
              duration: 0.5,
              delay: index * 0.05,
              ease: [0.4, 0, 0.2, 1],
            }}
            style={{
              width: barWidth,
              backgroundColor: barColor,
              borderRadius: barWidth / 2,
              opacity: 0.6 + (value / maxValue) * 0.4,
            }}
          />
        );
      })}
    </Box>
  );
};

