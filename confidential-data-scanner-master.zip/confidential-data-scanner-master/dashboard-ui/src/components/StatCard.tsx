import React from 'react';
import { Card, CardContent, Typography, Box, useTheme, Skeleton } from '@mui/material';
import { TrendingUp as TrendingUpIcon, TrendingDown as TrendingDownIcon } from '@mui/icons-material';
import { motion } from 'framer-motion';
import CountUp from './CountUp';
import SparklineChart from './SparklineChart';

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: React.ReactNode;
  color?: 'primary' | 'secondary' | 'error' | 'warning' | 'success';
  trend?: {
    value: number;
    label: string;
  };
  sparklineData?: number[];
  loading?: boolean;
  onClick?: () => void;
  delay?: number;
}

export default function StatCard({
  title,
  value,
  subtitle,
  icon,
  color = 'primary',
  trend,
  sparklineData,
  loading = false,
  onClick,
  delay = 0,
}: StatCardProps) {
  const theme = useTheme();
  const colorValue = theme.palette[color].main;
  const numericValue = typeof value === 'number' ? value : parseFloat(value) || 0;
  const isNumeric = typeof value === 'number' || !isNaN(parseFloat(value as string));

  // Determine if trend is positive or negative from context
  const isTrendPositive = trend ? trend.value >= 0 : false;
  // For error color (detections), positive trend is bad
  const isGoodTrend = color === 'error' ? !isTrendPositive : isTrendPositive;

  if (loading) {
    return (
      <Card
        sx={{
          height: '100%',
          position: 'relative',
          overflow: 'hidden',
        }}
      >
        <Box
          sx={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            height: 4,
            bgcolor: 'rgba(99, 102, 241, 0.3)',
          }}
        />
        <CardContent sx={{ p: 3 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <Box sx={{ flex: 1 }}>
              <Skeleton variant="text" width="50%" height={20} />
              <Skeleton variant="text" width="40%" height={48} sx={{ my: 1 }} />
              <Skeleton variant="text" width="60%" height={16} />
              <Box sx={{ mt: 2 }}>
                <Skeleton variant="rectangular" width="100%" height={35} sx={{ borderRadius: 1 }} />
              </Box>
            </Box>
            <Skeleton variant="rounded" width={48} height={48} sx={{ borderRadius: 2 }} />
          </Box>
        </CardContent>
      </Card>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.5, ease: [0.4, 0, 0.2, 1] }}
      whileHover={{ y: -4 }}
      onClick={onClick}
      style={{ height: '100%', cursor: onClick ? 'pointer' : 'default' }}
    >
      <Card
        sx={{
          height: '100%',
          position: 'relative',
          overflow: 'hidden',
          transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
          '&::before': {
            content: '""',
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            height: 4,
            background: `linear-gradient(90deg, ${colorValue} 0%, ${theme.palette[color].light} 100%)`,
          },
          '&:hover': {
            boxShadow: theme.custom?.glows?.[color] || `0 0 30px ${colorValue}40`,
            borderColor: `${colorValue}40`,
          },
        }}
      >
        <CardContent sx={{ p: 3 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <Box sx={{ flex: 1, minWidth: 0 }}>
              <Typography variant="body2" color="text.secondary" gutterBottom noWrap>
                {title}
              </Typography>
              
              {isNumeric ? (
                <CountUp
                  end={numericValue}
                  duration={1.5}
                  variant="h3"
                  sx={{
                    fontWeight: 700,
                    fontFamily: '"JetBrains Mono", monospace',
                    color: colorValue,
                  }}
                />
              ) : (
                <Typography
                  variant="h3"
                  sx={{
                    fontWeight: 700,
                    fontFamily: '"JetBrains Mono", monospace',
                    color: colorValue,
                  }}
                >
                  {value}
                </Typography>
              )}

              {/* Subtitle and Trend Row */}
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 0.5, flexWrap: 'wrap' }}>
                {subtitle && (
                  <Typography variant="body2" color="text.secondary" noWrap>
                    {subtitle}
                  </Typography>
                )}
                {trend && (
                  <Box
                    sx={{
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: 0.5,
                      px: 1,
                      py: 0.25,
                      borderRadius: 1,
                      bgcolor: isGoodTrend ? 'rgba(16, 185, 129, 0.1)' : 'rgba(239, 68, 68, 0.1)',
                    }}
                  >
                    {isTrendPositive ? (
                      <TrendingUpIcon
                        sx={{
                          fontSize: 14,
                          color: isGoodTrend ? 'success.main' : 'error.main',
                        }}
                      />
                    ) : (
                      <TrendingDownIcon
                        sx={{
                          fontSize: 14,
                          color: isGoodTrend ? 'success.main' : 'error.main',
                        }}
                      />
                    )}
                    <Typography
                      variant="caption"
                      sx={{
                        color: isGoodTrend ? 'success.main' : 'error.main',
                        fontWeight: 600,
                      }}
                    >
                      {isTrendPositive ? '+' : ''}{trend.value}%
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {trend.label}
                    </Typography>
                  </Box>
                )}
              </Box>

              {/* Sparkline Chart */}
              {sparklineData && sparklineData.length > 0 && (
                <Box sx={{ mt: 2 }}>
                  <SparklineChart
                    data={sparklineData}
                    color={color}
                    height={35}
                    showAnimation
                  />
                </Box>
              )}
            </Box>

            {/* Icon */}
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: delay + 0.2, type: 'spring', stiffness: 200 }}
            >
              <Box
                sx={{
                  p: 1.5,
                  borderRadius: 2,
                  backgroundColor: `${colorValue}15`,
                  color: colorValue,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  transition: 'all 0.3s ease',
                  '&:hover': {
                    backgroundColor: `${colorValue}25`,
                    transform: 'rotate(5deg)',
                  },
                }}
              >
                {icon}
              </Box>
            </motion.div>
          </Box>
        </CardContent>
      </Card>
    </motion.div>
  );
}

// Compact variant for smaller spaces
export function StatCardCompact({
  title,
  value,
  icon,
  color = 'primary',
  trend,
}: Pick<StatCardProps, 'title' | 'value' | 'icon' | 'color' | 'trend'>) {
  const theme = useTheme();
  const colorValue = theme.palette[color].main;
  const numericValue = typeof value === 'number' ? value : parseFloat(value as string) || 0;
  const isNumeric = typeof value === 'number' || !isNaN(parseFloat(value as string));

  return (
    <Box
      sx={{
        display: 'flex',
        alignItems: 'center',
        gap: 2,
        p: 2,
        borderRadius: 2,
        bgcolor: 'rgba(18, 18, 31, 0.5)',
        border: '1px solid rgba(99, 102, 241, 0.1)',
        transition: 'all 0.2s ease',
        '&:hover': {
          bgcolor: 'rgba(18, 18, 31, 0.7)',
          borderColor: `${colorValue}30`,
        },
      }}
    >
      <Box
        sx={{
          p: 1,
          borderRadius: 1.5,
          backgroundColor: `${colorValue}15`,
          color: colorValue,
        }}
      >
        {icon}
      </Box>
      <Box sx={{ flex: 1 }}>
        <Typography variant="caption" color="text.secondary" display="block">
          {title}
        </Typography>
        {isNumeric ? (
          <CountUp
            end={numericValue}
            variant="h6"
            sx={{ fontWeight: 600, color: colorValue }}
          />
        ) : (
          <Typography variant="h6" sx={{ fontWeight: 600, color: colorValue }}>
            {value}
          </Typography>
        )}
      </Box>
      {trend && (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
          {trend.value >= 0 ? (
            <TrendingUpIcon sx={{ fontSize: 16, color: 'success.main' }} />
          ) : (
            <TrendingDownIcon sx={{ fontSize: 16, color: 'error.main' }} />
          )}
          <Typography
            variant="caption"
            sx={{
              color: trend.value >= 0 ? 'success.main' : 'error.main',
              fontWeight: 600,
            }}
          >
            {trend.value >= 0 ? '+' : ''}{trend.value}%
          </Typography>
        </Box>
      )}
    </Box>
  );
}
