import React, { useState, useEffect, useMemo } from 'react';
import {
  Box,
  Grid,
  Card,
  CardContent,
  Typography,
  Button,
  ButtonGroup,
  ToggleButton,
  ToggleButtonGroup,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  CircularProgress,
  Alert,
  Divider,
  useTheme,
} from '@mui/material';
import {
  TrendingUp as TrendingUpIcon,
  TrendingDown as TrendingDownIcon,
  Warning as WarningIcon,
  Security as SecurityIcon,
  Computer as ComputerIcon,
  InsertDriveFile as FileIcon,
  CalendarMonth as CalendarIcon,
  BarChart as BarChartIcon,
  PieChart as PieChartIcon,
} from '@mui/icons-material';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';
import { motion, AnimatePresence } from 'framer-motion';
import { format, subDays, startOfDay, endOfDay } from 'date-fns';

import AnimatedCard from '../components/AnimatedCard';
import CountUp from '../components/CountUp';
import SparklineChart from '../components/SparklineChart';
import DrillDownChart from '../components/DrillDownChart';
import CalendarHeatmap from '../components/CalendarHeatmap';
import { StatsGridSkeleton, ChartSkeleton } from '../components/LoadingSkeleton';
import SeverityChip from '../components/SeverityChip';
import DetectionTypeChip from '../components/DetectionTypeChip';
import { dashboardApi, detectionsApi, DashboardStats, TrendData } from '../services/api';

type TimeRange = '1d' | '7d' | '30d' | '90d';

interface MetricCardProps {
  title: string;
  value: number;
  previousValue?: number;
  icon: React.ReactNode;
  color: 'primary' | 'secondary' | 'success' | 'error' | 'warning';
  sparklineData?: number[];
  delay?: number;
}

const MetricCard: React.FC<MetricCardProps> = ({
  title,
  value,
  previousValue,
  icon,
  color,
  sparklineData,
  delay = 0,
}) => {
  const theme = useTheme();
  const colorValue = theme.palette[color].main;
  
  const change = previousValue
    ? ((value - previousValue) / previousValue) * 100
    : 0;
  const isPositive = change >= 0;

  return (
    <AnimatedCard delay={delay}>
      <Card
        sx={{
          height: '100%',
          position: 'relative',
          overflow: 'hidden',
          '&::before': {
            content: '""',
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            height: 4,
            background: `linear-gradient(90deg, ${colorValue} 0%, ${theme.palette[color].light} 100%)`,
          },
        }}
      >
        <CardContent sx={{ p: 3 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <Box sx={{ flex: 1 }}>
              <Typography variant="body2" color="text.secondary" gutterBottom>
                {title}
              </Typography>
              <CountUp
                end={value}
                duration={1.5}
                variant="h3"
                sx={{
                  fontWeight: 700,
                  fontFamily: '"JetBrains Mono", monospace',
                  color: colorValue,
                }}
              />
              {previousValue !== undefined && (
                <Box sx={{ display: 'flex', alignItems: 'center', mt: 1, gap: 0.5 }}>
                  {isPositive ? (
                    <TrendingUpIcon sx={{ fontSize: 16, color: color === 'error' ? 'error.main' : 'success.main' }} />
                  ) : (
                    <TrendingDownIcon sx={{ fontSize: 16, color: color === 'error' ? 'success.main' : 'error.main' }} />
                  )}
                  <Typography
                    variant="body2"
                    sx={{
                      color: (color === 'error' ? !isPositive : isPositive)
                        ? 'success.main'
                        : 'error.main',
                      fontWeight: 500,
                    }}
                  >
                    {isPositive ? '+' : ''}{change.toFixed(1)}%
                  </Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ ml: 0.5 }}>
                    vs previous
                  </Typography>
                </Box>
              )}
              {sparklineData && sparklineData.length > 0 && (
                <Box sx={{ mt: 2 }}>
                  <SparklineChart data={sparklineData} color={color} height={35} />
                </Box>
              )}
            </Box>
            <Box
              sx={{
                p: 1.5,
                borderRadius: 2,
                backgroundColor: `${colorValue}15`,
                color: colorValue,
              }}
            >
              {icon}
            </Box>
          </Box>
        </CardContent>
      </Card>
    </AnimatedCard>
  );
};

export default function Analytics() {
  const theme = useTheme();
  const [timeRange, setTimeRange] = useState<TimeRange>('7d');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [trends, setTrends] = useState<TrendData | null>(null);
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [drillDownView, setDrillDownView] = useState<'type' | 'severity'>('type');

  // Get days count from time range
  const getDaysFromRange = (range: TimeRange): number => {
    switch (range) {
      case '1d': return 1;
      case '7d': return 7;
      case '30d': return 30;
      case '90d': return 90;
      default: return 7;
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const days = getDaysFromRange(timeRange);
        const [statsRes, trendsRes] = await Promise.all([
          dashboardApi.getStats(),
          dashboardApi.getTrends(days),
        ]);
        setStats(statsRes.data);
        setTrends(trendsRes.data);
        setError(null);
      } catch (err) {
        console.error('Error fetching analytics data:', err);
        setError('Failed to load analytics data. Make sure the server is running.');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [timeRange]);

  // Prepare trend chart data
  const trendChartData = useMemo(() => {
    if (!trends?.detections) return [];
    return trends.detections.map((d) => ({
      date: format(new Date(d.date), 'MMM d'),
      fullDate: d.date,
      detections: parseInt(d.count),
    }));
  }, [trends]);

  // Prepare sparkline data
  const sparklineData = useMemo(() => {
    return trendChartData.map((d) => d.detections);
  }, [trendChartData]);

  // Prepare drill-down data for detection types
  const typesDrillDownData = useMemo(() => {
    if (!stats?.detections.byType) return [];
    
    // Group types into categories
    const categories: Record<string, { name: string; value: number; color: string; id: string; children: any[] }> = {
      identity: { name: 'Identity', value: 0, color: '#6366f1', id: 'identity', children: [] },
      financial: { name: 'Financial', value: 0, color: '#10b981', id: 'financial', children: [] },
      contact: { name: 'Contact', value: 0, color: '#f472b6', id: 'contact', children: [] },
      other: { name: 'Other', value: 0, color: '#f59e0b', id: 'other', children: [] },
    };

    stats.detections.byType.forEach((item) => {
      const type = item.detectionType;
      const count = parseInt(item.count);

      let category = 'other';
      if (['AADHAR', 'PAN', 'US_SSN', 'INDIAN_PASSPORT', 'VOTER_ID', 'DRIVING_LICENSE', 'PERSON'].includes(type)) {
        category = 'identity';
      } else if (['CREDIT_CARD', 'IBAN', 'BANK_ACCOUNT'].includes(type)) {
        category = 'financial';
      } else if (['EMAIL_ADDRESS', 'PHONE_NUMBER', 'IP_ADDRESS', 'URL'].includes(type)) {
        category = 'contact';
      }

      categories[category].value += count;
      categories[category].children.push({
        name: type.replace(/_/g, ' '),
        value: count,
        id: type,
      });
    });

    return Object.values(categories).filter((c) => c.value > 0);
  }, [stats]);

  // Prepare drill-down data for severity
  const severityDrillDownData = useMemo(() => {
    if (!stats?.detections.bySeverity) return [];
    
    const severityColors: Record<string, string> = {
      critical: '#ef4444',
      high: '#f97316',
      medium: '#f59e0b',
      low: '#22c55e',
    };

    return Object.entries(stats.detections.bySeverity).map(([severity, count]) => ({
      name: severity.charAt(0).toUpperCase() + severity.slice(1),
      value: count,
      color: severityColors[severity] || '#94a3b8',
      id: severity,
    }));
  }, [stats]);

  // Prepare heatmap data
  const heatmapData = useMemo(() => {
    if (!trends?.detections) return [];
    return trends.detections.map((d) => ({
      date: d.date,
      value: parseInt(d.count),
    }));
  }, [trends]);

  // Calculate previous period values for comparison
  const previousDetections = useMemo(() => {
    const midPoint = Math.floor(sparklineData.length / 2);
    const firstHalf = sparklineData.slice(0, midPoint);
    const secondHalf = sparklineData.slice(midPoint);
    const prevSum = firstHalf.reduce((a, b) => a + b, 0);
    return prevSum;
  }, [sparklineData]);

  if (loading) {
    return (
      <Box>
        <Typography variant="h4" sx={{ mb: 3, fontWeight: 700 }}>
          Analytics
        </Typography>
        <StatsGridSkeleton count={4} />
        <Grid container spacing={3} sx={{ mt: 1 }}>
          <Grid item xs={12}>
            <Card>
              <CardContent>
                <ChartSkeleton height={300} type="line" />
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </Box>
    );
  }

  if (error) {
    return (
      <Box>
        <Typography variant="h4" sx={{ mb: 3, fontWeight: 700 }}>
          Analytics
        </Typography>
        <Alert severity="error">{error}</Alert>
      </Box>
    );
  }

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <Box
          sx={{
            bgcolor: 'rgba(18, 18, 31, 0.95)',
            border: '1px solid rgba(99, 102, 241, 0.2)',
            borderRadius: 2,
            p: 2,
            backdropFilter: 'blur(10px)',
          }}
        >
          <Typography variant="body2" fontWeight={600} gutterBottom>
            {label}
          </Typography>
          {payload.map((entry: any, index: number) => (
            <Typography key={index} variant="body2" sx={{ color: entry.color }}>
              {entry.name}: {entry.value.toLocaleString()}
            </Typography>
          ))}
        </Box>
      );
    }
    return null;
  };

  return (
    <Box>
      {/* Header */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3, flexWrap: 'wrap', gap: 2 }}>
        <Typography variant="h4" sx={{ fontWeight: 700 }}>
          Analytics
        </Typography>
        
        {/* Time Range Selector */}
        <ButtonGroup variant="outlined" size="small">
          {(['1d', '7d', '30d', '90d'] as TimeRange[]).map((range) => (
            <Button
              key={range}
              onClick={() => setTimeRange(range)}
              variant={timeRange === range ? 'contained' : 'outlined'}
              sx={{
                minWidth: 50,
                ...(timeRange === range && {
                  background: theme.custom.gradients.primary,
                }),
              }}
            >
              {range === '1d' ? 'Today' : range.toUpperCase()}
            </Button>
          ))}
        </ButtonGroup>
      </Box>

      {/* Metric Cards */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <MetricCard
            title="Total Detections"
            value={stats?.detections.total || 0}
            previousValue={previousDetections}
            icon={<WarningIcon />}
            color="error"
            sparklineData={sparklineData}
            delay={0}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <MetricCard
            title="Critical Issues"
            value={stats?.detections.bySeverity?.critical || 0}
            icon={<SecurityIcon />}
            color="error"
            delay={0.1}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <MetricCard
            title="Files Scanned"
            value={stats?.scans.filesScanned || 0}
            icon={<FileIcon />}
            color="primary"
            delay={0.2}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <MetricCard
            title="Active Clients"
            value={stats?.clients.active || 0}
            previousValue={stats?.clients.total}
            icon={<ComputerIcon />}
            color="success"
            delay={0.3}
          />
        </Grid>
      </Grid>

      {/* Detection Trends Chart */}
      <AnimatedCard delay={0.4}>
        <Card sx={{ mb: 4 }}>
          <CardContent>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
              <Typography variant="h6">
                Detection Trends
              </Typography>
              <Chip
                label={`Last ${getDaysFromRange(timeRange)} days`}
                size="small"
                color="primary"
                variant="outlined"
              />
            </Box>
            <Box sx={{ height: 350 }}>
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={trendChartData}>
                  <defs>
                    <linearGradient id="colorDetections" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(99, 102, 241, 0.1)" />
                  <XAxis
                    dataKey="date"
                    stroke="#94a3b8"
                    tick={{ fill: '#94a3b8', fontSize: 12 }}
                  />
                  <YAxis
                    stroke="#94a3b8"
                    tick={{ fill: '#94a3b8', fontSize: 12 }}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Area
                    type="monotone"
                    dataKey="detections"
                    name="Detections"
                    stroke="#6366f1"
                    strokeWidth={2}
                    fillOpacity={1}
                    fill="url(#colorDetections)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </Box>
          </CardContent>
        </Card>
      </AnimatedCard>

      {/* Drill-Down Charts */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={6}>
          <AnimatedCard delay={0.5}>
            <Card sx={{ height: '100%' }}>
              <CardContent>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                  <Typography variant="h6">By Detection Type</Typography>
                  <ToggleButtonGroup
                    size="small"
                    value={drillDownView}
                    exclusive
                    onChange={(_, v) => v && setDrillDownView(v)}
                  >
                    <ToggleButton value="type" sx={{ px: 2 }}>
                      <PieChartIcon fontSize="small" />
                    </ToggleButton>
                    <ToggleButton value="severity" sx={{ px: 2 }}>
                      <BarChartIcon fontSize="small" />
                    </ToggleButton>
                  </ToggleButtonGroup>
                </Box>
                {/* @ts-ignore */}
                <AnimatePresence mode="wait">
                  {drillDownView === 'type' ? (
                    <motion.div
                      key="type"
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 20 }}
                    >
                      <DrillDownChart
                        data={typesDrillDownData}
                        title=""
                        type="pie"
                        height={280}
                      />
                    </motion.div>
                  ) : (
                    <motion.div
                      key="severity"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                    >
                      <DrillDownChart
                        data={severityDrillDownData}
                        title=""
                        type="bar"
                        height={280}
                      />
                    </motion.div>
                  )}
                </AnimatePresence>
              </CardContent>
            </Card>
          </AnimatedCard>
        </Grid>

        <Grid item xs={12} md={6}>
          <AnimatedCard delay={0.6}>
            <Card sx={{ height: '100%' }}>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  By Severity
                </Typography>
                <DrillDownChart
                  data={severityDrillDownData}
                  title=""
                  type="pie"
                  height={320}
                />
              </CardContent>
            </Card>
          </AnimatedCard>
        </Grid>
      </Grid>

      {/* Calendar Heatmap */}
      <AnimatedCard delay={0.7}>
        <Card sx={{ mb: 4 }}>
          <CardContent>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 3 }}>
              <CalendarIcon />
              <Typography variant="h6">
                Activity Heatmap ({new Date().getFullYear()})
              </Typography>
            </Box>
            <CalendarHeatmap
              data={heatmapData}
              year={new Date().getFullYear()}
              onDayClick={(date, value) => {
                setSelectedDate(date);
              }}
            />
            {selectedDate && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <Alert
                  severity="info"
                  sx={{ mt: 2 }}
                  onClose={() => setSelectedDate(null)}
                >
                  Selected: {format(new Date(selectedDate), 'MMMM d, yyyy')} - 
                  {' '}{heatmapData.find((d) => d.date === selectedDate)?.value || 0} detections
                </Alert>
              </motion.div>
            )}
          </CardContent>
        </Card>
      </AnimatedCard>

      {/* Quick Stats Summary */}
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <AnimatedCard delay={0.8}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Detection Type Breakdown
                </Typography>
                <Divider sx={{ my: 2 }} />
                <TableContainer>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>Type</TableCell>
                        <TableCell align="right">Count</TableCell>
                        <TableCell align="right">Percentage</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {stats?.detections.byType.slice(0, 8).map((item) => {
                        const total = stats?.detections.total || 1;
                        const count = parseInt(item.count);
                        const percentage = ((count / total) * 100).toFixed(1);
                        return (
                          <TableRow key={item.detectionType} hover>
                            <TableCell>
                              <DetectionTypeChip type={item.detectionType} />
                            </TableCell>
                            <TableCell align="right">
                              <Typography variant="body2" fontWeight={500}>
                                {count.toLocaleString()}
                              </Typography>
                            </TableCell>
                            <TableCell align="right">
                              <Typography variant="body2" color="text.secondary">
                                {percentage}%
                              </Typography>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </TableContainer>
              </CardContent>
            </Card>
          </AnimatedCard>
        </Grid>

        <Grid item xs={12} md={6}>
          <AnimatedCard delay={0.9}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Scan Source Distribution
                </Typography>
                <Divider sx={{ my: 2 }} />
                <Grid container spacing={2}>
                  {stats?.detections.bySource && Object.entries(stats.detections.bySource).map(([source, count]) => (
                    <Grid item xs={4} key={source}>
                      <Box
                        sx={{
                          textAlign: 'center',
                          p: 2,
                          borderRadius: 2,
                          bgcolor: 'rgba(99, 102, 241, 0.05)',
                          border: '1px solid rgba(99, 102, 241, 0.1)',
                        }}
                      >
                        <CountUp
                          end={count}
                          variant="h4"
                          sx={{ fontWeight: 700, color: 'primary.main' }}
                        />
                        <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                          {source.charAt(0).toUpperCase() + source.slice(1)}
                        </Typography>
                      </Box>
                    </Grid>
                  ))}
                </Grid>
              </CardContent>
            </Card>
          </AnimatedCard>
        </Grid>
      </Grid>
    </Box>
  );
}

