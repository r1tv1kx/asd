import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Grid,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  CircularProgress,
  Alert,
  Button,
  IconButton,
  Tooltip,
  Divider,
} from '@mui/material';
import {
  ArrowBack as BackIcon,
  Computer as ComputerIcon,
  CheckCircle as ResolveIcon,
} from '@mui/icons-material';
import SeverityChip from '../components/SeverityChip';
import DetectionTypeChip from '../components/DetectionTypeChip';
import { clientsApi, detectionsApi, Client, Detection } from '../services/api';

export default function ClientDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [client, setClient] = useState<Client | null>(null);
  const [detections, setDetections] = useState<Detection[]>([]);
  const [totalDetections, setTotalDetections] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  useEffect(() => {
    const fetchData = async () => {
      if (!id) return;
      try {
        setLoading(true);
        const [clientRes, detectionsRes] = await Promise.all([
          clientsApi.getById(id),
          clientsApi.getDetections(id, { limit: rowsPerPage, offset: page * rowsPerPage }),
        ]);
        setClient(clientRes.data);
        setDetections(detectionsRes.data.detections);
        setTotalDetections(detectionsRes.data.total);
        setError(null);
      } catch (err) {
        console.error('Error fetching client data:', err);
        setError('Failed to load client data.');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [id, page, rowsPerPage]);

  const handleResolve = async (detectionId: string) => {
    try {
      await detectionsApi.resolve(detectionId, 'dashboard-user');
      setDetections((prev) =>
        prev.map((d) =>
          d.id === detectionId ? { ...d, isResolved: true, resolvedAt: new Date().toISOString() } : d
        )
      );
    } catch (err) {
      console.error('Error resolving detection:', err);
    }
  };

  if (loading && !client) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: 400 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box>
        <Button startIcon={<BackIcon />} onClick={() => navigate('/clients')} sx={{ mb: 2 }}>
          Back to Clients
        </Button>
        <Alert severity="error">{error}</Alert>
      </Box>
    );
  }

  if (!client) {
    return (
      <Box>
        <Button startIcon={<BackIcon />} onClick={() => navigate('/clients')} sx={{ mb: 2 }}>
          Back to Clients
        </Button>
        <Alert severity="warning">Client not found</Alert>
      </Box>
    );
  }

  return (
    <Box>
      <Button startIcon={<BackIcon />} onClick={() => navigate('/clients')} sx={{ mb: 3 }}>
        Back to Clients
      </Button>

      {/* Client Info Card */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 3 }}>
            <Box
              sx={{
                p: 2,
                borderRadius: 2,
                backgroundColor: 'primary.main',
                color: 'white',
              }}
            >
              <ComputerIcon sx={{ fontSize: 40 }} />
            </Box>
            <Box sx={{ flex: 1 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 1 }}>
                <Typography variant="h5" fontWeight={700}>
                  {client.hostname}
                </Typography>
                <Chip
                  label={client.status}
                  size="small"
                  color={
                    client.status === 'active'
                      ? 'success'
                      : client.status === 'scanning'
                      ? 'warning'
                      : 'default'
                  }
                />
              </Box>
              <Grid container spacing={3}>
                <Grid item xs={6} sm={3}>
                  <Typography variant="caption" color="text.secondary">
                    Username
                  </Typography>
                  <Typography variant="body2">{client.username || '-'}</Typography>
                </Grid>
                <Grid item xs={6} sm={3}>
                  <Typography variant="caption" color="text.secondary">
                    IP Address
                  </Typography>
                  <Typography variant="body2">{client.ipAddress || '-'}</Typography>
                </Grid>
                <Grid item xs={6} sm={3}>
                  <Typography variant="caption" color="text.secondary">
                    OS Version
                  </Typography>
                  <Typography variant="body2">{client.osVersion || '-'}</Typography>
                </Grid>
                <Grid item xs={6} sm={3}>
                  <Typography variant="caption" color="text.secondary">
                    Last Seen
                  </Typography>
                  <Typography variant="body2">
                    {client.lastSeen ? new Date(client.lastSeen).toLocaleString() : 'Never'}
                  </Typography>
                </Grid>
              </Grid>
            </Box>
          </Box>
        </CardContent>
      </Card>

      {/* Scan Sessions */}
      {client.scanSessions && client.scanSessions.length > 0 && (
        <Card sx={{ mb: 3 }}>
          <CardContent>
            <Typography variant="h6" sx={{ mb: 2 }}>
              Recent Scan Sessions
            </Typography>
            <TableContainer>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell>Started</TableCell>
                    <TableCell>Status</TableCell>
                    <TableCell>Files Scanned</TableCell>
                    <TableCell>Detections</TableCell>
                    <TableCell>Duration</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {client.scanSessions.map((session) => (
                    <TableRow key={session.id}>
                      <TableCell>
                        {new Date(session.startedAt).toLocaleString()}
                      </TableCell>
                      <TableCell>
                        <Chip
                          label={session.status}
                          size="small"
                          color={
                            session.status === 'completed'
                              ? 'success'
                              : session.status === 'running'
                              ? 'warning'
                              : session.status === 'failed'
                              ? 'error'
                              : 'default'
                          }
                        />
                      </TableCell>
                      <TableCell>{session.filesScanned}</TableCell>
                      <TableCell>
                        <Chip
                          label={session.detectionsFound}
                          size="small"
                          color={session.detectionsFound > 0 ? 'error' : 'default'}
                        />
                      </TableCell>
                      <TableCell>
                        {session.completedAt
                          ? `${Math.round(
                              (new Date(session.completedAt).getTime() -
                                new Date(session.startedAt).getTime()) /
                                1000
                            )}s`
                          : '-'}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </CardContent>
        </Card>
      )}

      {/* Detections */}
      <Card>
        <CardContent>
          <Typography variant="h6" sx={{ mb: 2 }}>
            Detections ({totalDetections})
          </Typography>
          <Divider sx={{ mb: 2 }} />
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>File</TableCell>
                  <TableCell>Type</TableCell>
                  <TableCell>Severity</TableCell>
                  <TableCell>Preview</TableCell>
                  <TableCell>Detected</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell align="right">Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={7} align="center" sx={{ py: 4 }}>
                      <CircularProgress size={32} />
                    </TableCell>
                  </TableRow>
                ) : detections.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} align="center" sx={{ py: 4 }}>
                      <Typography color="text.secondary">No detections found</Typography>
                    </TableCell>
                  </TableRow>
                ) : (
                  detections.map((detection) => (
                    <TableRow key={detection.id} hover>
                      <TableCell>
                        <Typography variant="body2" fontWeight={500}>
                          {detection.fileName || detection.filePath.split(/[/\\]/).pop()}
                        </Typography>
                        <Typography
                          variant="caption"
                          color="text.secondary"
                          sx={{
                            display: 'block',
                            maxWidth: 200,
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            whiteSpace: 'nowrap',
                          }}
                        >
                          {detection.filePath}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <DetectionTypeChip type={detection.detectionType} />
                      </TableCell>
                      <TableCell>
                        <SeverityChip severity={detection.severity} />
                      </TableCell>
                      <TableCell>
                        <Typography
                          variant="body2"
                          sx={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '0.75rem' }}
                        >
                          {detection.redactedPreview || '-'}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2" color="text.secondary">
                          {new Date(detection.detectedAt).toLocaleString()}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Chip
                          label={detection.isResolved ? 'Resolved' : 'Open'}
                          size="small"
                          color={detection.isResolved ? 'success' : 'warning'}
                        />
                      </TableCell>
                      <TableCell align="right">
                        {!detection.isResolved && (
                          <Tooltip title="Mark as Resolved">
                            <IconButton
                              size="small"
                              color="success"
                              onClick={() => handleResolve(detection.id)}
                            >
                              <ResolveIcon />
                            </IconButton>
                          </Tooltip>
                        )}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </TableContainer>
          <TablePagination
            rowsPerPageOptions={[5, 10, 25, 50]}
            component="div"
            count={totalDetections}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={(_, newPage) => setPage(newPage)}
            onRowsPerPageChange={(e) => {
              setRowsPerPage(parseInt(e.target.value, 10));
              setPage(0);
            }}
          />
        </CardContent>
      </Card>
    </Box>
  );
}

