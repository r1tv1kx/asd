import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Grid,
  Card,
  CardContent,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Alert,
  Chip,
  IconButton,
  Tooltip,
  useTheme,
} from '@mui/material';
import {
  Computer as ComputerIcon,
  Warning as WarningIcon,
  Scanner as ScannerIcon,
  InsertDriveFile as FileIcon,
  ContentPaste as ClipboardIcon,
  Usb as UsbIcon,
  TrendingUp as TrendingUpIcon,
  TrendingDown as TrendingDownIcon,
  ArrowForward as ArrowForwardIcon,
} from '@mui/icons-material';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RechartsTooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { motion, AnimatePresence } from 'framer-motion';

import AnimatedCard from '../components/AnimatedCard';
import CountUp from '../components/CountUp';
import SparklineChart from '../components/SparklineChart';
import { StatsGridSkeleton, ChartSkeleton, TableSkeleton } from '../components/LoadingSkeleton';
import SeverityChip from '../components/SeverityChip';
import DetectionTypeChip from '../components/DetectionTypeChip';
import { dashboardApi, DashboardStats, RecentActivity, TrendData } from '../services/api';

const SEVERITY_COLORS = {
  critical: '#ef4444',
  high: '#f97316',
  medium: '#f59e0b',
  low: '#22c55e',
};

interface EnhancedStatCardProps {
  title: string;
  value: number;
  subtitle?: string;
  icon: React.ReactNode;
  color: 'primary' | 'secondary' | 'success' | 'error' | 'warning';
  sparklineData?: number[];
  trend?: number;
  delay?: number;
  onClick?: () => void;
}

const EnhancedStatCard: React.FC<EnhancedStatCardProps> = ({
  title,
  value,
  subtitle,
  icon,
  color,
  sparklineData,
  trend,
  delay = 0,
  onClick,
}) => {
  const theme = useTheme();
  const colorValue = theme.palette[color].main;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.5, ease: [0.4, 0, 0.2, 1] }}
      whileHover={{ y: -4 }}
      onClick={onClick}
      style={{ cursor: onClick ? 'pointer' : 'default' }}
    >
      <Card
        sx={{
          height: '100%',
          position: 'relative',
          overflow: 'hidden',
          transition: 'all 0.3s ease',
          '&::before': {
            content: '""',
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            height: 4,
            background: `linear-gradient(90deg, ${colorValue} 0%, ${theme.palette[color].light} 100%)`,
          },
          '&:hover': {
            boxShadow: theme.custom.glows[color],
          },
        }}
      >
        <CardContent sx={{ p: 3 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <Box sx={{ flex: 1, minWidth: 0 }}>
              <Typography variant="body2" color="text.secondary" gutterBottom noWrap>
                {title}
              </Typography>
              <CountUp
                end={value}
                duration={1.5}
                variant="h3"
                sx={{
                  fontWeight: 700,
                  fontFamily: '"JetBrains Mono", monospace',
                  color: colorValue,
                }}
              />
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 0.5 }}>
                {subtitle && (
                  <Typography variant="body2" color="text.secondary" noWrap>
                    {subtitle}
                  </Typography>
                )}
                {trend !== undefined && trend !== 0 && (
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                    {trend > 0 ? (
                      <TrendingUpIcon
                        sx={{
                          fontSize: 14,
                          color: color === 'error' ? 'error.main' : 'success.main',
                        }}
                      />
                    ) : (
                      <TrendingDownIcon
                        sx={{
                          fontSize: 14,
                          color: color === 'error' ? 'success.main' : 'error.main',
                        }}
                      />
                    )}
                    <Typography
                      variant="caption"
                      sx={{
                        color: (color === 'error' ? trend < 0 : trend > 0)
                          ? 'success.main'
                          : 'error.main',
                        fontWeight: 600,
                      }}
                    >
                      {trend > 0 ? '+' : ''}{trend.toFixed(0)}%
                    </Typography>
                  </Box>
                )}
              </Box>
              {sparklineData && sparklineData.length > 0 && (
                <Box sx={{ mt: 2 }}>
                  <SparklineChart data={sparklineData} color={color} height={35} />
                </Box>
              )}
            </Box>
            <Box
              sx={{
                p: 1.5,
                borderRadius: 2,
                backgroundColor: `${colorValue}15`,
                color: colorValue,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              {icon}
            </Box>
          </Box>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default function Dashboard() {
  const navigate = useNavigate();
  const theme = useTheme();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [recent, setRecent] = useState<RecentActivity | null>(null);
  const [trends, setTrends] = useState<TrendData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const [statsRes, recentRes, trendsRes] = await Promise.all([
          dashboardApi.getStats(),
          dashboardApi.getRecent(10),
          dashboardApi.getTrends(7),
        ]);
        setStats(statsRes.data);
        setRecent(recentRes.data);
        setTrends(trendsRes.data);
        setError(null);
      } catch (err) {
        console.error('Error fetching dashboard data:', err);
        setError('Failed to load dashboard data. Make sure the server is running.');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
    const interval = setInterval(fetchData, 30000); // Refresh every 30s
    return () => clearInterval(interval);
  }, []);

  // Calculate sparkline data from trends
  const sparklineData = useMemo(() => {
    if (!trends?.detections) return [];
    return trends.detections.map((d) => parseInt(d.count));
  }, [trends]);

  const severityData = useMemo(() => {
    if (!stats?.detections.bySeverity) return [];
    return Object.entries(stats.detections.bySeverity).map(([name, value]) => ({
      name: name.charAt(0).toUpperCase() + name.slice(1),
      value,
      color: SEVERITY_COLORS[name as keyof typeof SEVERITY_COLORS] || '#94a3b8',
    }));
  }, [stats]);

  const trendData = useMemo(() => {
    if (!trends?.detections) return [];
    return trends.detections.map((d) => ({
      date: new Date(d.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      detections: parseInt(d.count),
    }));
  }, [trends]);

  // Custom tooltip for charts
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <Box
          sx={{
            bgcolor: 'rgba(18, 18, 31, 0.95)',
            border: '1px solid rgba(99, 102, 241, 0.2)',
            borderRadius: 2,
            p: 2,
            backdropFilter: 'blur(10px)',
          }}
        >
          <Typography variant="body2" fontWeight={600}>
            {label}
          </Typography>
          {payload.map((entry: any, index: number) => (
            <Typography key={index} variant="body2" sx={{ color: entry.color || '#6366f1' }}>
              Detections: {entry.value.toLocaleString()}
            </Typography>
          ))}
        </Box>
      );
    }
    return null;
  };

  if (loading) {
    return (
      <Box>
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Typography variant="h4" sx={{ mb: 3, fontWeight: 700 }}>
            Overview
          </Typography>
        </motion.div>
        <StatsGridSkeleton count={4} />
        <Grid container spacing={3} sx={{ mt: 1 }}>
          <Grid item xs={12} md={8}>
            <Card>
              <CardContent>
                <ChartSkeleton height={300} type="bar" />
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} md={4}>
            <Card sx={{ height: '100%' }}>
              <CardContent>
                <ChartSkeleton height={250} type="pie" />
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </Box>
    );
  }

  if (error) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
      >
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      </motion.div>
    );
  }

  return (
    <Box>
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
          <Typography variant="h4" sx={{ fontWeight: 700 }}>
            Overview
          </Typography>
          <Chip
            label="Live"
            size="small"
            color="success"
            sx={{
              animation: 'pulse 2s infinite',
              '@keyframes pulse': {
                '0%, 100%': { opacity: 1 },
                '50%': { opacity: 0.5 },
              },
            }}
          />
        </Box>
      </motion.div>

      {/* Stats Cards */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <EnhancedStatCard
            title="Total Clients"
            value={stats?.clients.total || 0}
            subtitle={`${stats?.clients.active || 0} active`}
            icon={<ComputerIcon />}
            color="primary"
            delay={0}
            onClick={() => navigate('/clients')}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <EnhancedStatCard
            title="Detections"
            value={stats?.detections.total || 0}
            subtitle={`${stats?.detections.unresolved || 0} unresolved`}
            icon={<WarningIcon />}
            color="error"
            sparklineData={sparklineData}
            delay={0.1}
            onClick={() => navigate('/detections')}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <EnhancedStatCard
            title="Clipboard Alerts"
            value={stats?.clipboard?.totalDetections || 0}
            subtitle="clipboard detections"
            icon={<ClipboardIcon />}
            color="warning"
            delay={0.2}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <EnhancedStatCard
            title="USB Devices"
            value={stats?.usb?.totalDevices || 0}
            subtitle="devices tracked"
            icon={<UsbIcon />}
            color="success"
            delay={0.3}
          />
        </Grid>
      </Grid>

      {/* Secondary Stats */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <EnhancedStatCard
            title="Scans Today"
            value={stats?.scans.today || 0}
            subtitle={`${stats?.scans.total || 0} total`}
            icon={<ScannerIcon />}
            color="secondary"
            delay={0.4}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <EnhancedStatCard
            title="Files Scanned"
            value={stats?.scans.filesScanned || 0}
            icon={<FileIcon />}
            color="primary"
            delay={0.5}
          />
        </Grid>
        {stats?.detections.bySource && (
          <>
            <Grid item xs={12} sm={6} md={3}>
              <EnhancedStatCard
                title="File System"
                value={stats.detections.bySource.filesystem || 0}
                subtitle="detections"
                icon={<FileIcon />}
                color="secondary"
                delay={0.6}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <EnhancedStatCard
                title="USB Detections"
                value={stats.detections.bySource.usb || 0}
                subtitle="from USB devices"
                icon={<UsbIcon />}
                color="success"
                delay={0.7}
              />
            </Grid>
          </>
        )}
      </Grid>

      {/* Charts */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={8}>
          <AnimatedCard delay={0.8}>
            <Card>
              <CardContent>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                  <Typography variant="h6">
                    Detection Trends (Last 7 Days)
                  </Typography>
                  <Tooltip title="View detailed analytics">
                    <IconButton size="small" onClick={() => navigate('/analytics')}>
                      <ArrowForwardIcon />
                    </IconButton>
                  </Tooltip>
                </Box>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={trendData}>
                    <defs>
                      <linearGradient id="colorDetections" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(99, 102, 241, 0.1)" />
                    <XAxis dataKey="date" stroke="#94a3b8" tick={{ fontSize: 12 }} />
                    <YAxis stroke="#94a3b8" tick={{ fontSize: 12 }} />
                    <RechartsTooltip content={<CustomTooltip />} />
                    <Area
                      type="monotone"
                      dataKey="detections"
                      stroke="#6366f1"
                      strokeWidth={2}
                      fillOpacity={1}
                      fill="url(#colorDetections)"
                      animationDuration={1500}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </AnimatedCard>
        </Grid>
        <Grid item xs={12} md={4}>
          <AnimatedCard delay={0.9}>
            <Card sx={{ height: '100%' }}>
              <CardContent>
                <Typography variant="h6" sx={{ mb: 2 }}>
                  By Severity
                </Typography>
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie
                      data={severityData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={85}
                      paddingAngle={4}
                      dataKey="value"
                      animationDuration={1000}
                    >
                      {severityData.map((entry, index) => (
                        <Cell
                          key={`cell-${index}`}
                          fill={entry.color}
                          style={{ filter: 'drop-shadow(0 2px 4px rgba(0,0,0,0.2))' }}
                        />
                      ))}
                    </Pie>
                    <RechartsTooltip
                      content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          const data = payload[0].payload;
                          return (
                            <Box
                              sx={{
                                bgcolor: 'rgba(18, 18, 31, 0.95)',
                                border: '1px solid rgba(99, 102, 241, 0.2)',
                                borderRadius: 2,
                                p: 1.5,
                                backdropFilter: 'blur(10px)',
                              }}
                            >
                              <Typography variant="body2" fontWeight={600} sx={{ color: data.color }}>
                                {data.name}: {data.value}
                              </Typography>
                            </Box>
                          );
                        }
                        return null;
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, justifyContent: 'center' }}>
                  {severityData.map((item, index) => (
                    <motion.div
                      key={item.name}
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 1.2 + index * 0.1 }}
                    >
                      <Chip
                        label={`${item.name}: ${item.value}`}
                        size="small"
                        sx={{
                          backgroundColor: `${item.color}20`,
                          color: item.color,
                          fontWeight: 500,
                          border: `1px solid ${item.color}40`,
                        }}
                      />
                    </motion.div>
                  ))}
                </Box>
              </CardContent>
            </Card>
          </AnimatedCard>
        </Grid>
      </Grid>

      {/* Recent Activity */}
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <AnimatedCard delay={1.0}>
            <Card>
              <CardContent>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                  <Typography variant="h6">
                    Recent Detections
                  </Typography>
                  <Chip
                    label={`${recent?.detections.length || 0} new`}
                    size="small"
                    color="error"
                    variant="outlined"
                  />
                </Box>
                <TableContainer>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>File</TableCell>
                        <TableCell>Type</TableCell>
                        <TableCell>Severity</TableCell>
                        <TableCell>Client</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {/* @ts-ignore */}
                      <AnimatePresence>
                        {recent?.detections.slice(0, 5).map((detection, index) => (
                          <motion.tr
                            key={detection.id}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: 1.2 + index * 0.1 }}
                            style={{ display: 'table-row' }}
                          >
                            <TableCell>
                              <Typography variant="body2" noWrap sx={{ maxWidth: 150 }}>
                                {detection.fileName || detection.filePath.split(/[/\\]/).pop()}
                              </Typography>
                            </TableCell>
                            <TableCell>
                              <DetectionTypeChip type={detection.detectionType} />
                            </TableCell>
                            <TableCell>
                              <SeverityChip severity={detection.severity} />
                            </TableCell>
                            <TableCell>
                              <Typography variant="body2" color="text.secondary">
                                {detection.client?.hostname || 'Unknown'}
                              </Typography>
                            </TableCell>
                          </motion.tr>
                        ))}
                      </AnimatePresence>
                      {(!recent?.detections || recent.detections.length === 0) && (
                        <TableRow>
                          <TableCell colSpan={4} align="center">
                            <Typography variant="body2" color="text.secondary">
                              No recent detections
                            </Typography>
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </TableContainer>
              </CardContent>
            </Card>
          </AnimatedCard>
        </Grid>
        <Grid item xs={12} md={6}>
          <AnimatedCard delay={1.1}>
            <Card>
              <CardContent>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                  <Typography variant="h6">
                    Active Clients
                  </Typography>
                  <Chip
                    label={`${stats?.clients.active || 0} online`}
                    size="small"
                    color="success"
                    variant="outlined"
                  />
                </Box>
                <TableContainer>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>Hostname</TableCell>
                        <TableCell>Status</TableCell>
                        <TableCell>Last Seen</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {/* @ts-ignore */}
                      <AnimatePresence>
                        {recent?.clients.slice(0, 5).map((client, index) => (
                          <motion.tr
                            key={client.id}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: 1.3 + index * 0.1 }}
                            onClick={() => navigate(`/clients/${client.id}`)}
                            style={{ display: 'table-row', cursor: 'pointer' }}
                          >
                            <TableCell>
                              <Typography variant="body2" fontWeight={500}>
                                {client.hostname}
                              </Typography>
                              {client.username && (
                                <Typography variant="caption" color="text.secondary">
                                  {client.username}
                                </Typography>
                              )}
                            </TableCell>
                            <TableCell>
                              <Chip
                                label={client.status}
                                size="small"
                                color={
                                  client.status === 'active'
                                    ? 'success'
                                    : client.status === 'scanning'
                                    ? 'warning'
                                    : 'default'
                                }
                                sx={{
                                  animation: client.status === 'scanning' ? 'pulse 1.5s infinite' : 'none',
                                }}
                              />
                            </TableCell>
                            <TableCell>
                              <Typography variant="body2" color="text.secondary">
                                {client.lastSeen
                                  ? new Date(client.lastSeen).toLocaleString()
                                  : 'Never'}
                              </Typography>
                            </TableCell>
                          </motion.tr>
                        ))}
                      </AnimatePresence>
                      {(!recent?.clients || recent.clients.length === 0) && (
                        <TableRow>
                          <TableCell colSpan={3} align="center">
                            <Typography variant="body2" color="text.secondary">
                              No clients registered
                            </Typography>
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </TableContainer>
              </CardContent>
            </Card>
          </AnimatedCard>
        </Grid>
      </Grid>
    </Box>
  );
}
