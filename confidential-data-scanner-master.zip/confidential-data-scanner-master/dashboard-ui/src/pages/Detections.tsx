import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  TextField,
  InputAdornment,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  CircularProgress,
  Alert,
  IconButton,
  Tooltip,
  Grid,
  Button,
  Checkbox,
} from '@mui/material';
import {
  Search as SearchIcon,
  CheckCircle as ResolveIcon,
  FilterList as FilterIcon,
} from '@mui/icons-material';
import SeverityChip from '../components/SeverityChip';
import DetectionTypeChip from '../components/DetectionTypeChip';
import ScanSourceChip from '../components/ScanSourceChip';
import { detectionsApi, Detection } from '../services/api';

export default function Detections() {
  const navigate = useNavigate();
  const [detections, setDetections] = useState<Detection[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(25);
  const [severity, setSeverity] = useState<string>('');
  const [detectionType, setDetectionType] = useState<string>('');
  const [isResolved, setIsResolved] = useState<string>('');
  const [scanSource, setScanSource] = useState<string>('');
  const [selected, setSelected] = useState<string[]>([]);

  useEffect(() => {
    const fetchDetections = async () => {
      try {
        setLoading(true);
        const response = await detectionsApi.getAll({
          severity: severity || undefined,
          detectionType: detectionType || undefined,
          isResolved: isResolved ? isResolved === 'true' : undefined,
          scanSource: scanSource || undefined,
          limit: rowsPerPage,
          offset: page * rowsPerPage,
        });
        setDetections(response.data.detections);
        setTotal(response.data.total);
        setError(null);
      } catch (err) {
        console.error('Error fetching detections:', err);
        setError('Failed to load detections. Make sure the server is running.');
      } finally {
        setLoading(false);
      }
    };

    fetchDetections();
  }, [page, rowsPerPage, severity, detectionType, isResolved, scanSource]);

  const handleResolve = async (detectionId: string) => {
    try {
      await detectionsApi.resolve(detectionId, 'dashboard-user');
      setDetections((prev) =>
        prev.map((d) =>
          d.id === detectionId ? { ...d, isResolved: true, resolvedAt: new Date().toISOString() } : d
        )
      );
    } catch (err) {
      console.error('Error resolving detection:', err);
    }
  };

  const handleBulkResolve = async () => {
    if (selected.length === 0) return;
    try {
      await detectionsApi.bulkResolve(selected, 'dashboard-user');
      setDetections((prev) =>
        prev.map((d) =>
          selected.includes(d.id)
            ? { ...d, isResolved: true, resolvedAt: new Date().toISOString() }
            : d
        )
      );
      setSelected([]);
    } catch (err) {
      console.error('Error bulk resolving detections:', err);
    }
  };

  const handleSelectAll = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.checked) {
      const unresolvedIds = detections.filter((d) => !d.isResolved).map((d) => d.id);
      setSelected(unresolvedIds);
    } else {
      setSelected([]);
    }
  };

  const handleSelect = (id: string) => {
    setSelected((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const detectionTypes = [
    'AADHAR',
    'PAN',
    'US_SSN',
    'CREDIT_CARD',
    'EMAIL_ADDRESS',
    'PHONE_NUMBER',
    'INDIAN_PASSPORT',
    'VOTER_ID',
    'DRIVING_LICENSE',
  ];

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" sx={{ fontWeight: 700 }}>
          Detections
        </Typography>
        {selected.length > 0 && (
          <Button
            variant="contained"
            color="success"
            startIcon={<ResolveIcon />}
            onClick={handleBulkResolve}
          >
            Resolve Selected ({selected.length})
          </Button>
        )}
      </Box>

      {/* Filters */}
      <Card sx={{ mb: 3 }}>
        <CardContent sx={{ py: 2 }}>
          <Grid container spacing={2} alignItems="center">
            <Grid item xs={12} sm={4}>
              <FormControl fullWidth size="small">
                <InputLabel>Severity</InputLabel>
                <Select
                  value={severity}
                  label="Severity"
                  onChange={(e) => {
                    setSeverity(e.target.value);
                    setPage(0);
                  }}
                >
                  <MenuItem value="">All</MenuItem>
                  <MenuItem value="critical">Critical</MenuItem>
                  <MenuItem value="high">High</MenuItem>
                  <MenuItem value="medium">Medium</MenuItem>
                  <MenuItem value="low">Low</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={4}>
              <FormControl fullWidth size="small">
                <InputLabel>Detection Type</InputLabel>
                <Select
                  value={detectionType}
                  label="Detection Type"
                  onChange={(e) => {
                    setDetectionType(e.target.value);
                    setPage(0);
                  }}
                >
                  <MenuItem value="">All</MenuItem>
                  {detectionTypes.map((type) => (
                    <MenuItem key={type} value={type}>
                      {type}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={3}>
              <FormControl fullWidth size="small">
                <InputLabel>Status</InputLabel>
                <Select
                  value={isResolved}
                  label="Status"
                  onChange={(e) => {
                    setIsResolved(e.target.value);
                    setPage(0);
                  }}
                >
                  <MenuItem value="">All</MenuItem>
                  <MenuItem value="false">Open</MenuItem>
                  <MenuItem value="true">Resolved</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={3}>
              <FormControl fullWidth size="small">
                <InputLabel>Scan Source</InputLabel>
                <Select
                  value={scanSource}
                  label="Scan Source"
                  onChange={(e) => {
                    setScanSource(e.target.value);
                    setPage(0);
                  }}
                >
                  <MenuItem value="">All Sources</MenuItem>
                  <MenuItem value="filesystem">File System</MenuItem>
                  <MenuItem value="clipboard">Clipboard</MenuItem>
                  <MenuItem value="usb">USB Device</MenuItem>
                </Select>
              </FormControl>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      <Card>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell padding="checkbox">
                  <Checkbox
                    indeterminate={
                      selected.length > 0 &&
                      selected.length < detections.filter((d) => !d.isResolved).length
                    }
                    checked={
                      detections.filter((d) => !d.isResolved).length > 0 &&
                      selected.length === detections.filter((d) => !d.isResolved).length
                    }
                    onChange={handleSelectAll}
                  />
                </TableCell>
                <TableCell>File</TableCell>
                <TableCell>Client</TableCell>
                <TableCell>Type</TableCell>
                <TableCell>Source</TableCell>
                <TableCell>Severity</TableCell>
                <TableCell>Preview</TableCell>
                <TableCell>Detected</TableCell>
                <TableCell>Status</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={10} align="center" sx={{ py: 4 }}>
                    <CircularProgress size={32} />
                  </TableCell>
                </TableRow>
              ) : detections.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={10} align="center" sx={{ py: 4 }}>
                    <Typography color="text.secondary">No detections found</Typography>
                  </TableCell>
                </TableRow>
              ) : (
                detections.map((detection) => (
                  <TableRow key={detection.id} hover>
                    <TableCell padding="checkbox">
                      {!detection.isResolved && (
                        <Checkbox
                          checked={selected.includes(detection.id)}
                          onChange={() => handleSelect(detection.id)}
                        />
                      )}
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" fontWeight={500}>
                        {detection.fileName || detection.filePath.split(/[/\\]/).pop()}
                      </Typography>
                      <Typography
                        variant="caption"
                        color="text.secondary"
                        sx={{
                          display: 'block',
                          maxWidth: 200,
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                          whiteSpace: 'nowrap',
                        }}
                      >
                        {detection.filePath}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Typography
                        variant="body2"
                        sx={{ cursor: 'pointer', '&:hover': { color: 'primary.main' } }}
                        onClick={() => navigate(`/clients/${detection.clientId}`)}
                      >
                        {detection.client?.hostname || 'Unknown'}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <DetectionTypeChip type={detection.detectionType} />
                    </TableCell>
                    <TableCell>
                      <ScanSourceChip source={detection.scanSource} />
                    </TableCell>
                    <TableCell>
                      <SeverityChip severity={detection.severity} />
                    </TableCell>
                    <TableCell>
                      <Typography
                        variant="body2"
                        sx={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '0.75rem' }}
                      >
                        {detection.redactedPreview || '-'}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" color="text.secondary">
                        {new Date(detection.detectedAt).toLocaleString()}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Typography
                        variant="body2"
                        sx={{
                          color: detection.isResolved ? 'success.main' : 'warning.main',
                          fontWeight: 500,
                        }}
                      >
                        {detection.isResolved ? 'Resolved' : 'Open'}
                      </Typography>
                    </TableCell>
                    <TableCell align="right">
                      {!detection.isResolved && (
                        <Tooltip title="Mark as Resolved">
                          <IconButton
                            size="small"
                            color="success"
                            onClick={() => handleResolve(detection.id)}
                          >
                            <ResolveIcon />
                          </IconButton>
                        </Tooltip>
                      )}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>
        <TablePagination
          rowsPerPageOptions={[10, 25, 50, 100]}
          component="div"
          count={total}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={(_, newPage) => setPage(newPage)}
          onRowsPerPageChange={(e) => {
            setRowsPerPage(parseInt(e.target.value, 10));
            setPage(0);
          }}
        />
      </Card>
    </Box>
  );
}

