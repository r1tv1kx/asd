import React, { useState, useEffect, useCallback } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  TextField,
  Button,
  IconButton,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  Chip,
  Alert,
  CircularProgress,
  Divider,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Snackbar,
  Tooltip,
  LinearProgress,
  Tabs,
  Tab,
} from '@mui/material';
import {
  Add as AddIcon,
  Delete as DeleteIcon,
  Folder as FolderIcon,
  Save as SaveIcon,
  Refresh as RefreshIcon,
  Computer as ComputerIcon,
  Settings as SettingsIcon,
  DeleteForever as DeleteForeverIcon,
  Warning as WarningIcon,
  PlayArrow as PlayIcon,
  Stop as StopIcon,
  Scanner as ScannerIcon,
  Usb as UsbIcon,
  ContentPaste as ClipboardIcon,
} from '@mui/icons-material';
import { clientsApi, Client, usbApi, clipboardApi } from '../services/api';

interface ClientConfig {
  scan: {
    directories: string[];
    file_types: string[];
    interval_hours: number;
    max_file_size_mb: number;
    worker_count: number;
  };
  clipboard?: {
    enabled?: boolean;
    check_interval_ms?: number;
    min_text_length?: number;
    ignore_duplicates?: boolean;
    retention_hours?: number;
    alert_on_detection?: boolean;
  };
  usb?: {
    enabled?: boolean;
    auto_scan_on_insert?: boolean;
    scan_hidden_files?: boolean;
    max_scan_size_gb?: number;
    block_on_detection?: boolean;
    scan_timeout_minutes?: number;
  };
  servers: {
    analyzer_url: string;
    dashboard_url: string;
  };
  api: {
    port: number;
  };
}

interface ScanProgress {
  isScanning: boolean;
  currentFile: string;
  filesScanned: number;
  totalFiles: number;
  detectionsFound: number;
  startedAt: string;
  estimatedTimeSeconds: number;
}

interface ServiceStatus {
  status: string;
  version: string;
  uptimeSeconds: number;
  totalDetections: number;
  clientId: string;
  scanProgress?: ScanProgress;
}

export default function Settings() {
  const [activeTab, setActiveTab] = useState(0);
  const [clients, setClients] = useState<Client[]>([]);
  const [selectedClient, setSelectedClient] = useState<string>('');
  const [config, setConfig] = useState<ClientConfig | null>(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [newDirectory, setNewDirectory] = useState('');
  const [newFileType, setNewFileType] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [clearDataDialogOpen, setClearDataDialogOpen] = useState(false);
  const [clearing, setClearing] = useState(false);
  const [serviceStatus, setServiceStatus] = useState<ServiceStatus | null>(null);
  const [statusLoading, setStatusLoading] = useState(false);

  // Fetch clients on mount
  useEffect(() => {
    fetchClients();
  }, []);

  const fetchClients = async () => {
    try {
      const response = await clientsApi.getAll({ limit: 100 });
      setClients(response.data.clients);
      if (response.data.clients.length > 0 && !selectedClient) {
        setSelectedClient(response.data.clients[0].id);
      }
    } catch (err) {
      console.error('Error fetching clients:', err);
      setError('Failed to load clients');
    }
  };

  // Fetch config and status when client changes
  useEffect(() => {
    if (selectedClient) {
      fetchConfig();
      fetchServiceStatus();
    }
  }, [selectedClient]);

  // Poll for status updates when scanning
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (serviceStatus?.scanProgress?.isScanning) {
      interval = setInterval(fetchServiceStatus, 2000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [serviceStatus?.scanProgress?.isScanning]);

  const fetchServiceStatus = useCallback(async () => {
    try {
      const response = await fetch('http://localhost:8080/api/status');
      if (response.ok) {
        const data = await response.json();
        setServiceStatus(data);
      }
    } catch (err) {
      console.log('Service not reachable');
      setServiceStatus(null);
    }
  }, []);

  const fetchConfig = async () => {
    if (!selectedClient) return;
    
    setLoading(true);
    setError(null);
    
    try {
      const response = await fetch(`http://localhost:3001/api/clients/${selectedClient}/config`);
      
      if (response.ok) {
        const data = await response.json();
        setConfig(data);
      } else {
        setConfig({
          scan: {
            directories: [
              'C:\\Users\\%USERNAME%\\Documents',
              'C:\\Users\\%USERNAME%\\Desktop',
              'C:\\Users\\%USERNAME%\\Downloads',
            ],
            file_types: ['.txt', '.pdf', '.doc', '.docx'],
            interval_hours: 24,
            max_file_size_mb: 50,
            worker_count: 4,
          },
          clipboard: {
            enabled: true,
            check_interval_ms: 500,
            min_text_length: 10,
            ignore_duplicates: true,
            retention_hours: 24,
            alert_on_detection: true,
          },
          usb: {
            enabled: true,
            auto_scan_on_insert: true,
            scan_hidden_files: false,
            max_scan_size_gb: 32,
            block_on_detection: false,
            scan_timeout_minutes: 30,
          },
          servers: {
            analyzer_url: 'http://localhost:8000',
            dashboard_url: 'http://localhost:3001',
          },
          api: {
            port: 8080,
          },
        });
      }
    } catch (err) {
      console.error('Error fetching config:', err);
      setConfig({
        scan: {
          directories: [
            'C:\\Users\\%USERNAME%\\Documents',
            'C:\\Users\\%USERNAME%\\Desktop',
            'C:\\Users\\%USERNAME%\\Downloads',
          ],
          file_types: ['.txt', '.pdf', '.doc', '.docx'],
          interval_hours: 24,
          max_file_size_mb: 50,
          worker_count: 4,
        },
        clipboard: {
          enabled: true,
          check_interval_ms: 500,
          min_text_length: 10,
          ignore_duplicates: true,
          retention_hours: 24,
          alert_on_detection: true,
        },
        usb: {
          enabled: true,
          auto_scan_on_insert: true,
          scan_hidden_files: false,
          max_scan_size_gb: 32,
          block_on_detection: false,
          scan_timeout_minutes: 30,
        },
        servers: {
          analyzer_url: 'http://localhost:8000',
          dashboard_url: 'http://localhost:3001',
        },
        api: {
          port: 8080,
        },
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSaveConfig = async () => {
    if (!config || !selectedClient) return;

    setSaving(true);
    setError(null);

    try {
      const response = await fetch(`http://localhost:3001/api/clients/${selectedClient}/config`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config),
      });

      if (response.ok) {
        setSuccess('Configuration saved successfully!');
      } else {
        const data = await response.json();
        setError(data.error || 'Failed to save configuration');
      }
    } catch (err) {
      console.error('Error saving config:', err);
      setError('Failed to save configuration. Make sure the client is online.');
    } finally {
      setSaving(false);
    }
  };

  const handleStartScan = async () => {
    try {
      const response = await fetch('http://localhost:8080/api/scan/start', {
        method: 'POST',
      });
      if (response.ok) {
        setSuccess('Scan started!');
        fetchServiceStatus();
      } else {
        const data = await response.json();
        setError(data.error || 'Failed to start scan');
      }
    } catch (err) {
      setError('Could not connect to the Windows service');
    }
  };

  const handleStopScan = async () => {
    try {
      const response = await fetch('http://localhost:8080/api/scan/stop', {
        method: 'POST',
      });
      if (response.ok) {
        setSuccess('Scan stop requested');
        fetchServiceStatus();
      } else {
        const data = await response.json();
        setError(data.error || 'Failed to stop scan');
      }
    } catch (err) {
      setError('Could not connect to the Windows service');
    }
  };

  const handleClearAllData = async () => {
    setClearing(true);
    setError(null);

    try {
      // Clear data from dashboard server (PostgreSQL)
      const dashboardResponse = await fetch('http://localhost:3001/api/admin/clear-all-data', {
        method: 'DELETE',
      });

      if (!dashboardResponse.ok) {
        const data = await dashboardResponse.json();
        throw new Error(data.error || 'Failed to clear dashboard data');
      }

      // Clear data from Windows service (local SQLite)
      try {
        const serviceResponse = await fetch('http://localhost:8080/api/data/clear', {
          method: 'DELETE',
        });
        if (!serviceResponse.ok) {
          console.warn('Could not clear Windows service data');
        }
      } catch (err) {
        console.warn('Windows service not reachable for data clearing');
      }

      setSuccess('All scan data cleared successfully! Client registrations preserved. Refresh the page to see changes.');
      setClearDataDialogOpen(false);
      fetchClients();
      fetchServiceStatus();
    } catch (err: any) {
      console.error('Error clearing data:', err);
      setError(err.message || 'Failed to clear data');
    } finally {
      setClearing(false);
    }
  };

  const handleAddDirectory = () => {
    if (!config || !newDirectory.trim()) return;
    
    if (config.scan.directories.includes(newDirectory.trim())) {
      setError('Directory already exists');
      return;
    }

    setConfig({
      ...config,
      scan: {
        ...config.scan,
        directories: [...config.scan.directories, newDirectory.trim()],
      },
    });
    setNewDirectory('');
    setDialogOpen(false);
  };

  const handleRemoveDirectory = (index: number) => {
    if (!config) return;
    
    setConfig({
      ...config,
      scan: {
        ...config.scan,
        directories: config.scan.directories.filter((_, i) => i !== index),
      },
    });
  };

  const handleAddFileType = () => {
    if (!config || !newFileType.trim()) return;
    
    let fileType = newFileType.trim();
    if (!fileType.startsWith('.')) {
      fileType = '.' + fileType;
    }

    if (config.scan.file_types.includes(fileType)) {
      setError('File type already exists');
      return;
    }

    setConfig({
      ...config,
      scan: {
        ...config.scan,
        file_types: [...config.scan.file_types, fileType],
      },
    });
    setNewFileType('');
  };

  const handleRemoveFileType = (index: number) => {
    if (!config) return;
    
    setConfig({
      ...config,
      scan: {
        ...config.scan,
        file_types: config.scan.file_types.filter((_, i) => i !== index),
      },
    });
  };

  const selectedClientData = clients.find(c => c.id === selectedClient);
  const scanProgress = serviceStatus?.scanProgress;
  const isScanning = scanProgress?.isScanning ?? false;
  const progressPercent = scanProgress && scanProgress.totalFiles > 0 
    ? Math.round((scanProgress.filesScanned / scanProgress.totalFiles) * 100) 
    : 0;

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" sx={{ fontWeight: 700 }}>
          <SettingsIcon sx={{ mr: 1, verticalAlign: 'middle' }} />
          Scan Settings
        </Typography>
        <Box sx={{ display: 'flex', gap: 1 }}>
          <Button
            variant="outlined"
            color="error"
            startIcon={<DeleteForeverIcon />}
            onClick={() => setClearDataDialogOpen(true)}
          >
            Clear All Data
          </Button>
          <Button
            variant="contained"
            startIcon={saving ? <CircularProgress size={20} color="inherit" /> : <SaveIcon />}
            onClick={handleSaveConfig}
            disabled={!config || saving}
          >
            {saving ? 'Saving...' : 'Save Configuration'}
          </Button>
        </Box>
      </Box>

      {/* Tabs */}
      <Card sx={{ mb: 3 }}>
        <Tabs
          value={activeTab}
          onChange={(_, newValue) => setActiveTab(newValue)}
          variant="fullWidth"
          sx={{
            borderBottom: 1,
            borderColor: 'divider',
            '& .MuiTab-root': {
              minHeight: 64,
            },
          }}
        >
          <Tab
            icon={<ComputerIcon />}
            iconPosition="start"
            label="Client Settings"
            sx={{ textTransform: 'none', fontWeight: 500 }}
          />
          <Tab
            icon={<UsbIcon />}
            iconPosition="start"
            label="USB Settings"
            sx={{ textTransform: 'none', fontWeight: 500 }}
          />
          <Tab
            icon={<ClipboardIcon />}
            iconPosition="start"
            label="Clipboard Settings"
            sx={{ textTransform: 'none', fontWeight: 500 }}
          />
        </Tabs>
      </Card>

      {/* Client Settings Tab */}
      {activeTab === 0 && (
        <>
          {/* Client Selector */}
          <Card sx={{ mb: 3 }}>
        <CardContent>
          <Grid container spacing={2} alignItems="center">
            <Grid item xs={12} md={6}>
              <FormControl fullWidth>
                <InputLabel>Select Client</InputLabel>
                <Select
                  value={selectedClient}
                  label="Select Client"
                  onChange={(e) => setSelectedClient(e.target.value)}
                >
                  {clients.map((client) => (
                    <MenuItem key={client.id} value={client.id}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <ComputerIcon fontSize="small" />
                        {client.hostname}
                        <Chip
                          label={client.status}
                          size="small"
                          color={client.status === 'active' ? 'success' : client.status === 'scanning' ? 'warning' : 'default'}
                          sx={{ ml: 1 }}
                        />
                      </Box>
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={6}>
              {selectedClientData && (
                <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
                  <Chip
                    icon={<ComputerIcon />}
                    label={`IP: ${selectedClientData.ipAddress || 'Unknown'}`}
                    variant="outlined"
                  />
                  <Chip
                    label={`Last seen: ${selectedClientData.lastSeen ? new Date(selectedClientData.lastSeen).toLocaleString() : 'Never'}`}
                    variant="outlined"
                  />
                </Box>
              )}
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      {/* Current Scan Status */}
      <Card sx={{ mb: 3, border: isScanning ? '2px solid' : '1px solid', borderColor: isScanning ? 'warning.main' : 'divider' }}>
        <CardContent>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
            <Typography variant="h6">
              <ScannerIcon sx={{ mr: 1, verticalAlign: 'middle' }} />
              Scan Control
            </Typography>
            <Box sx={{ display: 'flex', gap: 1 }}>
              <Tooltip title="Refresh status">
                <IconButton onClick={fetchServiceStatus} size="small">
                  <RefreshIcon />
                </IconButton>
              </Tooltip>
              {isScanning ? (
                <Button
                  variant="contained"
                  color="error"
                  startIcon={<StopIcon />}
                  onClick={handleStopScan}
                >
                  Stop Scan
                </Button>
              ) : (
                <Button
                  variant="contained"
                  color="success"
                  startIcon={<PlayIcon />}
                  onClick={handleStartScan}
                  disabled={!serviceStatus}
                >
                  Start Scan
                </Button>
              )}
            </Box>
          </Box>
          <Divider sx={{ mb: 2 }} />

          {!serviceStatus ? (
            <Alert severity="warning">
              Windows service is not running or not reachable. Start the service to enable scanning.
            </Alert>
          ) : isScanning && scanProgress ? (
            <Box>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                <Typography variant="body2" color="text.secondary">
                  Scanning in progress...
                </Typography>
                <Typography variant="body2" fontWeight={600}>
                  {progressPercent}%
                </Typography>
              </Box>
              <LinearProgress 
                variant="determinate" 
                value={progressPercent} 
                sx={{ height: 8, borderRadius: 1, mb: 2 }}
              />
              <Grid container spacing={2}>
                <Grid item xs={6} sm={3}>
                  <Typography variant="caption" color="text.secondary">Files Scanned</Typography>
                  <Typography variant="h6">{scanProgress.filesScanned.toLocaleString()}</Typography>
                </Grid>
                <Grid item xs={6} sm={3}>
                  <Typography variant="caption" color="text.secondary">Total Files</Typography>
                  <Typography variant="h6">{scanProgress.totalFiles.toLocaleString()}</Typography>
                </Grid>
                <Grid item xs={6} sm={3}>
                  <Typography variant="caption" color="text.secondary">Detections Found</Typography>
                  <Typography variant="h6" color="error.main">{scanProgress.detectionsFound.toLocaleString()}</Typography>
                </Grid>
                <Grid item xs={6} sm={3}>
                  <Typography variant="caption" color="text.secondary">Est. Time Remaining</Typography>
                  <Typography variant="h6">
                    {scanProgress.estimatedTimeSeconds > 60 
                      ? `${Math.round(scanProgress.estimatedTimeSeconds / 60)}m`
                      : `${scanProgress.estimatedTimeSeconds}s`}
                  </Typography>
                </Grid>
              </Grid>
              <Box sx={{ mt: 2, p: 1, bgcolor: 'background.default', borderRadius: 1 }}>
                <Typography variant="caption" color="text.secondary">Current file:</Typography>
                <Typography variant="body2" sx={{ fontFamily: 'monospace', fontSize: '0.75rem', wordBreak: 'break-all' }}>
                  {scanProgress.currentFile || 'N/A'}
                </Typography>
              </Box>
            </Box>
          ) : (
            <Box>
              <Grid container spacing={2}>
                <Grid item xs={6} sm={3}>
                  <Typography variant="caption" color="text.secondary">Service Status</Typography>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: 'success.main' }} />
                    <Typography variant="body1" fontWeight={500}>Running</Typography>
                  </Box>
                </Grid>
                <Grid item xs={6} sm={3}>
                  <Typography variant="caption" color="text.secondary">Total Detections</Typography>
                  <Typography variant="h6">{serviceStatus.totalDetections.toLocaleString()}</Typography>
                </Grid>
                <Grid item xs={6} sm={3}>
                  <Typography variant="caption" color="text.secondary">Uptime</Typography>
                  <Typography variant="h6">
                    {serviceStatus.uptimeSeconds > 3600 
                      ? `${Math.round(serviceStatus.uptimeSeconds / 3600)}h`
                      : `${Math.round(serviceStatus.uptimeSeconds / 60)}m`}
                  </Typography>
                </Grid>
                <Grid item xs={6} sm={3}>
                  <Typography variant="caption" color="text.secondary">Version</Typography>
                  <Typography variant="h6">{serviceStatus.version}</Typography>
                </Grid>
              </Grid>
            </Box>
          )}
        </CardContent>
      </Card>

      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
          <CircularProgress />
        </Box>
      ) : config ? (
        <Grid container spacing={3}>
          {/* Scan Directories */}
          <Grid item xs={12} md={6}>
            <Card sx={{ height: '100%' }}>
              <CardContent>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                  <Typography variant="h6">
                    <FolderIcon sx={{ mr: 1, verticalAlign: 'middle' }} />
                    Scan Directories
                  </Typography>
                  <Button
                    variant="outlined"
                    size="small"
                    startIcon={<AddIcon />}
                    onClick={() => setDialogOpen(true)}
                  >
                    Add Directory
                  </Button>
                </Box>
                <Divider sx={{ mb: 2 }} />
                
                {config.scan.directories.length === 0 ? (
                  <Typography color="text.secondary" sx={{ py: 2, textAlign: 'center' }}>
                    No directories configured
                  </Typography>
                ) : (
                  <List dense>
                    {config.scan.directories.map((dir, index) => (
                      <ListItem
                        key={index}
                        sx={{
                          bgcolor: 'background.default',
                          borderRadius: 1,
                          mb: 1,
                        }}
                      >
                        <FolderIcon sx={{ mr: 2, color: 'primary.main' }} />
                        <ListItemText
                          primary={dir}
                          primaryTypographyProps={{
                            sx: { fontFamily: 'monospace', fontSize: '0.875rem' },
                          }}
                        />
                        <ListItemSecondaryAction>
                          <Tooltip title="Remove directory">
                            <IconButton
                              edge="end"
                              size="small"
                              onClick={() => handleRemoveDirectory(index)}
                              color="error"
                            >
                              <DeleteIcon />
                            </IconButton>
                          </Tooltip>
                        </ListItemSecondaryAction>
                      </ListItem>
                    ))}
                  </List>
                )}
              </CardContent>
            </Card>
          </Grid>

          {/* File Types */}
          <Grid item xs={12} md={6}>
            <Card sx={{ height: '100%' }}>
              <CardContent>
                <Typography variant="h6" sx={{ mb: 2 }}>
                  File Types to Scan
                </Typography>
                <Divider sx={{ mb: 2 }} />
                
                <Box sx={{ display: 'flex', gap: 1, mb: 2, flexWrap: 'wrap' }}>
                  {config.scan.file_types.map((type, index) => (
                    <Chip
                      key={index}
                      label={type}
                      onDelete={() => handleRemoveFileType(index)}
                      color="primary"
                      variant="outlined"
                    />
                  ))}
                </Box>
                
                <Box sx={{ display: 'flex', gap: 1 }}>
                  <TextField
                    size="small"
                    placeholder="e.g., .xlsx"
                    value={newFileType}
                    onChange={(e) => setNewFileType(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleAddFileType()}
                  />
                  <Button
                    variant="outlined"
                    onClick={handleAddFileType}
                    disabled={!newFileType.trim()}
                  >
                    Add
                  </Button>
                </Box>
              </CardContent>
            </Card>
          </Grid>

          {/* Scan Settings */}
          <Grid item xs={12} md={6}>
            <Card>
              <CardContent>
                <Typography variant="h6" sx={{ mb: 2 }}>
                  Scan Settings
                </Typography>
                <Divider sx={{ mb: 2 }} />
                
                <Grid container spacing={2}>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="Scan Interval (hours)"
                      type="number"
                      value={config.scan.interval_hours}
                      onChange={(e) =>
                        setConfig({
                          ...config,
                          scan: { ...config.scan, interval_hours: parseInt(e.target.value) || 24 },
                        })
                      }
                      inputProps={{ min: 1, max: 168 }}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="Max File Size (MB)"
                      type="number"
                      value={config.scan.max_file_size_mb}
                      onChange={(e) =>
                        setConfig({
                          ...config,
                          scan: { ...config.scan, max_file_size_mb: parseInt(e.target.value) || 50 },
                        })
                      }
                      inputProps={{ min: 1, max: 500 }}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="Worker Count"
                      type="number"
                      value={config.scan.worker_count}
                      onChange={(e) =>
                        setConfig({
                          ...config,
                          scan: { ...config.scan, worker_count: parseInt(e.target.value) || 4 },
                        })
                      }
                      inputProps={{ min: 1, max: 16 }}
                    />
                  </Grid>
                </Grid>
              </CardContent>
            </Card>
          </Grid>

          {/* Server Configuration */}
          <Grid item xs={12} md={6}>
            <Card>
              <CardContent>
                <Typography variant="h6" sx={{ mb: 2 }}>
                  Server Configuration
                </Typography>
                <Divider sx={{ mb: 2 }} />
                
                <Grid container spacing={2}>
                  <Grid item xs={12}>
                    <TextField
                      fullWidth
                      label="Analyzer Server URL"
                      value={config.servers.analyzer_url}
                      onChange={(e) =>
                        setConfig({
                          ...config,
                          servers: { ...config.servers, analyzer_url: e.target.value },
                        })
                      }
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      fullWidth
                      label="Dashboard Server URL"
                      value={config.servers.dashboard_url}
                      onChange={(e) =>
                        setConfig({
                          ...config,
                          servers: { ...config.servers, dashboard_url: e.target.value },
                        })
                      }
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="Local API Port"
                      type="number"
                      value={config.api.port}
                      onChange={(e) =>
                        setConfig({
                          ...config,
                          api: { port: parseInt(e.target.value) || 8080 },
                        })
                      }
                      inputProps={{ min: 1024, max: 65535 }}
                    />
                  </Grid>
                </Grid>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      ) : (
        <Alert severity="info">
          Select a client to view and edit its configuration.
        </Alert>
      )}
        </>
      )}

      {/* USB Settings Tab */}
      {activeTab === 1 && (
        <Card>
          <CardContent>
            <Typography variant="h6" sx={{ mb: 2, display: 'flex', alignItems: 'center', gap: 1 }}>
              <UsbIcon />
              USB Device Settings
            </Typography>
            <Divider sx={{ mb: 3 }} />
            
            <Alert severity="info" sx={{ mb: 3 }}>
              USB device monitoring and scanning settings. Configure how USB devices are tracked and scanned when connected.
            </Alert>

            {selectedClient ? (
              <Grid container spacing={3}>
                <Grid item xs={12}>
                  <Card variant="outlined">
                    <CardContent>
                      <Typography variant="subtitle1" sx={{ mb: 2, fontWeight: 600 }}>
                        USB Monitoring Configuration
                      </Typography>
                      <Grid container spacing={2}>
                        <Grid item xs={12} sm={6}>
                          <FormControl fullWidth>
                            <InputLabel>Auto Scan on Insert</InputLabel>
                            <Select
                              value={config?.usb?.auto_scan_on_insert !== false ? 'enabled' : 'disabled'}
                              label="Auto Scan on Insert"
                              onChange={(e) => {
                                if (config) {
                                  setConfig({
                                    ...config,
                                    usb: {
                                      ...config.usb,
                                      auto_scan_on_insert: e.target.value === 'enabled',
                                    },
                                  });
                                }
                              }}
                            >
                              <MenuItem value="enabled">Enabled</MenuItem>
                              <MenuItem value="disabled">Disabled</MenuItem>
                            </Select>
                          </FormControl>
                        </Grid>
                        <Grid item xs={12} sm={6}>
                          <TextField
                            fullWidth
                            label="Max Scan Size (GB)"
                            type="number"
                            value={config?.usb?.max_scan_size_gb || 32}
                            onChange={(e) => {
                              if (config) {
                                setConfig({
                                  ...config,
                                  usb: {
                                    ...config.usb,
                                    max_scan_size_gb: parseInt(e.target.value) || 32,
                                  },
                                });
                              }
                            }}
                            inputProps={{ min: 1, max: 1000 }}
                            helperText="Skip scanning drives larger than this size"
                          />
                        </Grid>
                        <Grid item xs={12} sm={6}>
                          <TextField
                            fullWidth
                            label="Scan Timeout (minutes)"
                            type="number"
                            value={config?.usb?.scan_timeout_minutes || 30}
                            onChange={(e) => {
                              if (config) {
                                setConfig({
                                  ...config,
                                  usb: {
                                    ...config.usb,
                                    scan_timeout_minutes: parseInt(e.target.value) || 30,
                                  },
                                });
                              }
                            }}
                            inputProps={{ min: 1, max: 120 }}
                            helperText="Maximum scan duration"
                          />
                        </Grid>
                        <Grid item xs={12} sm={6}>
                          <FormControl fullWidth>
                            <InputLabel>Scan Hidden Files</InputLabel>
                            <Select
                              value={config?.usb?.scan_hidden_files ? 'enabled' : 'disabled'}
                              label="Scan Hidden Files"
                              onChange={(e) => {
                                if (config) {
                                  setConfig({
                                    ...config,
                                    usb: {
                                      ...config.usb,
                                      scan_hidden_files: e.target.value === 'enabled',
                                    },
                                  });
                                }
                              }}
                            >
                              <MenuItem value="enabled">Enabled</MenuItem>
                              <MenuItem value="disabled">Disabled</MenuItem>
                            </Select>
                          </FormControl>
                        </Grid>
                      </Grid>
                    </CardContent>
                  </Card>
                </Grid>
              </Grid>
            ) : (
              <Alert severity="info">
                Select a client to view and edit USB settings.
              </Alert>
            )}
          </CardContent>
        </Card>
      )}

      {/* Clipboard Settings Tab */}
      {activeTab === 2 && (
        <Card>
          <CardContent>
            <Typography variant="h6" sx={{ mb: 2, display: 'flex', alignItems: 'center', gap: 1 }}>
              <ClipboardIcon />
              Clipboard Monitoring Settings
            </Typography>
            <Divider sx={{ mb: 3 }} />
            
            <Alert severity="info" sx={{ mb: 3 }}>
              Configure real-time clipboard monitoring for sensitive data detection.
            </Alert>

            {selectedClient ? (
              <Grid container spacing={3}>
                <Grid item xs={12}>
                  <Card variant="outlined">
                    <CardContent>
                      <Typography variant="subtitle1" sx={{ mb: 2, fontWeight: 600 }}>
                        Clipboard Monitoring Configuration
                      </Typography>
                      <Grid container spacing={2}>
                        <Grid item xs={12} sm={6}>
                          <FormControl fullWidth>
                            <InputLabel>Clipboard Monitoring</InputLabel>
                            <Select
                              value={config?.clipboard?.enabled !== false ? 'enabled' : 'disabled'}
                              label="Clipboard Monitoring"
                              onChange={(e) => {
                                if (config) {
                                  setConfig({
                                    ...config,
                                    clipboard: {
                                      ...config.clipboard,
                                      enabled: e.target.value === 'enabled',
                                    },
                                  });
                                }
                              }}
                            >
                              <MenuItem value="enabled">Enabled</MenuItem>
                              <MenuItem value="disabled">Disabled</MenuItem>
                            </Select>
                          </FormControl>
                        </Grid>
                        <Grid item xs={12} sm={6}>
                          <TextField
                            fullWidth
                            label="Check Interval (ms)"
                            type="number"
                            value={config?.clipboard?.check_interval_ms || 500}
                            onChange={(e) => {
                              if (config) {
                                setConfig({
                                  ...config,
                                  clipboard: {
                                    ...config.clipboard,
                                    check_interval_ms: parseInt(e.target.value) || 500,
                                  },
                                });
                              }
                            }}
                            inputProps={{ min: 100, max: 5000, step: 100 }}
                            helperText="How often to check clipboard (milliseconds)"
                          />
                        </Grid>
                        <Grid item xs={12} sm={6}>
                          <TextField
                            fullWidth
                            label="Minimum Text Length"
                            type="number"
                            value={config?.clipboard?.min_text_length || 10}
                            onChange={(e) => {
                              if (config) {
                                setConfig({
                                  ...config,
                                  clipboard: {
                                    ...config.clipboard,
                                    min_text_length: parseInt(e.target.value) || 10,
                                  },
                                });
                              }
                            }}
                            inputProps={{ min: 1, max: 1000 }}
                            helperText="Minimum text length to analyze"
                          />
                        </Grid>
                        <Grid item xs={12} sm={6}>
                          <TextField
                            fullWidth
                            label="Retention Hours"
                            type="number"
                            value={config?.clipboard?.retention_hours || 24}
                            onChange={(e) => {
                              if (config) {
                                setConfig({
                                  ...config,
                                  clipboard: {
                                    ...config.clipboard,
                                    retention_hours: parseInt(e.target.value) || 24,
                                  },
                                });
                              }
                            }}
                            inputProps={{ min: 1, max: 168 }}
                            helperText="How long to keep clipboard history"
                          />
                        </Grid>
                        <Grid item xs={12} sm={6}>
                          <FormControl fullWidth>
                            <InputLabel>Alert on Detection</InputLabel>
                            <Select
                              value={config?.clipboard?.alert_on_detection !== false ? 'enabled' : 'disabled'}
                              label="Alert on Detection"
                              onChange={(e) => {
                                if (config) {
                                  setConfig({
                                    ...config,
                                    clipboard: {
                                      ...config.clipboard,
                                      alert_on_detection: e.target.value === 'enabled',
                                    },
                                  });
                                }
                              }}
                            >
                              <MenuItem value="enabled">Enabled</MenuItem>
                              <MenuItem value="disabled">Disabled</MenuItem>
                            </Select>
                          </FormControl>
                        </Grid>
                        <Grid item xs={12} sm={6}>
                          <FormControl fullWidth>
                            <InputLabel>Ignore Duplicates</InputLabel>
                            <Select
                              value={config?.clipboard?.ignore_duplicates !== false ? 'enabled' : 'disabled'}
                              label="Ignore Duplicates"
                              onChange={(e) => {
                                if (config) {
                                  setConfig({
                                    ...config,
                                    clipboard: {
                                      ...config.clipboard,
                                      ignore_duplicates: e.target.value === 'enabled',
                                    },
                                  });
                                }
                              }}
                            >
                              <MenuItem value="enabled">Enabled</MenuItem>
                              <MenuItem value="disabled">Disabled</MenuItem>
                            </Select>
                          </FormControl>
                        </Grid>
                      </Grid>
                    </CardContent>
                  </Card>
                </Grid>
              </Grid>
            ) : (
              <Alert severity="info">
                Select a client to view and edit clipboard settings.
              </Alert>
            )}
          </CardContent>
        </Card>
      )}

      {/* Add Directory Dialog */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Add Scan Directory</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            fullWidth
            label="Directory Path"
            placeholder="e.g., C:\Users\%USERNAME%\Projects"
            value={newDirectory}
            onChange={(e) => setNewDirectory(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleAddDirectory()}
            sx={{ mt: 2 }}
            helperText="Use %USERNAME% for the current user's folder"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
          <Button onClick={handleAddDirectory} variant="contained" disabled={!newDirectory.trim()}>
            Add
          </Button>
        </DialogActions>
      </Dialog>

      {/* Clear All Data Confirmation Dialog */}
      <Dialog open={clearDataDialogOpen} onClose={() => setClearDataDialogOpen(false)} maxWidth="sm">
        <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <WarningIcon color="error" />
          Clear All Data
        </DialogTitle>
        <DialogContent>
          <Alert severity="warning" sx={{ mb: 2 }}>
            This action cannot be undone!
          </Alert>
          <Typography>
            This will permanently delete:
          </Typography>
          <List dense>
            <ListItem>• All scan sessions and their results</ListItem>
            <ListItem>• All detections from all clients</ListItem>
            <ListItem>• All clipboard detections</ListItem>
            <ListItem>• All USB device records and scan sessions</ListItem>
            <ListItem>• Local scan data from the Windows service</ListItem>
          </List>
          <Alert severity="info" sx={{ mt: 2 }}>
            <Typography variant="body2">
              <strong>Important:</strong> Client registration data will be preserved. All registered clients (hostname, IP address, status, registration date) will remain in the system and will not be deleted.
            </Typography>
          </Alert>
          <Typography color="text.secondary" sx={{ mt: 2 }}>
            Are you sure you want to proceed?
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setClearDataDialogOpen(false)}>Cancel</Button>
          <Button 
            onClick={handleClearAllData} 
            variant="contained" 
            color="error"
            disabled={clearing}
            startIcon={clearing ? <CircularProgress size={20} color="inherit" /> : <DeleteForeverIcon />}
          >
            {clearing ? 'Clearing...' : 'Clear All Data'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Success Snackbar */}
      <Snackbar
        open={!!success}
        autoHideDuration={3000}
        onClose={() => setSuccess(null)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert severity="success" onClose={() => setSuccess(null)}>
          {success}
        </Alert>
      </Snackbar>
    </Box>
  );
}
