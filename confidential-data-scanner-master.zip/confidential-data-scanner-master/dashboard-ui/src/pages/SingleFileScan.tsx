import React, { useState, useCallback } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  TextField,
  Alert,
  CircularProgress,
  Divider,
  Grid,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  LinearProgress,
  Tabs,
  Tab,
  IconButton,
  Tooltip,
} from '@mui/material';
import {
  CloudUpload as UploadIcon,
  Description as FileIcon,
  Security as ScanIcon,
  Warning as WarningIcon,
  CheckCircle as CheckIcon,
  Error as ErrorIcon,
  ContentPaste as PasteIcon,
  Clear as ClearIcon,
  Refresh as RefreshIcon,
} from '@mui/icons-material';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3001';

interface Detection {
  type: string;
  text: string;
  confidence: number;
  severity: 'low' | 'medium' | 'high' | 'critical';
  position: { start: number; end: number };
}

interface ScanResult {
  success: boolean;
  fileName: string;
  fileType: string;
  fileSize: number;
  textLength: number;
  detections: Detection[];
  totalDetections: number;
  hasPII: boolean;
  summary: {
    byType: Array<{ type: string; count: number }>;
    bySeverity: { critical: number; high: number; medium: number; low: number };
  };
  message?: string;
}

const severityColors: Record<string, 'error' | 'warning' | 'info' | 'success'> = {
  critical: 'error',
  high: 'warning',
  medium: 'info',
  low: 'success',
};

const severityLabels: Record<string, string> = {
  critical: 'Critical',
  high: 'High',
  medium: 'Medium',
  low: 'Low',
};

export default function SingleFileScan() {
  const [tabValue, setTabValue] = useState(0);
  const [file, setFile] = useState<File | null>(null);
  const [text, setText] = useState('');
  const [scanning, setScanning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<ScanResult | null>(null);
  const [dragActive, setDragActive] = useState(false);

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setFile(e.dataTransfer.files[0]);
      setResult(null);
      setError(null);
    }
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setResult(null);
      setError(null);
    }
  };

  const handleScanFile = async () => {
    if (!file) return;

    setScanning(true);
    setError(null);
    setResult(null);

    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch(`${API_BASE_URL}/api/scan/file`, {
        method: 'POST',
        body: formData,
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to scan file');
      }

      setResult(data);
    } catch (err: any) {
      setError(err.message || 'An error occurred while scanning');
    } finally {
      setScanning(false);
    }
  };

  const handleScanText = async () => {
    if (!text.trim()) return;

    setScanning(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch(`${API_BASE_URL}/api/scan/text`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, fileName: 'Direct Input' }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to scan text');
      }

      setResult(data);
    } catch (err: any) {
      setError(err.message || 'An error occurred while scanning');
    } finally {
      setScanning(false);
    }
  };

  const handleClear = () => {
    setFile(null);
    setText('');
    setResult(null);
    setError(null);
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" sx={{ fontWeight: 700 }}>
          <ScanIcon sx={{ mr: 1, verticalAlign: 'middle' }} />
          Quick Scan
        </Typography>
        {(file || text || result) && (
          <Button
            variant="outlined"
            startIcon={<ClearIcon />}
            onClick={handleClear}
          >
            Clear
          </Button>
        )}
      </Box>

      <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
        Upload a file or paste text to quickly scan for sensitive data without registering a client.
      </Typography>

      {/* Input Section */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Tabs
            value={tabValue}
            onChange={(_, newValue) => {
              setTabValue(newValue);
              setResult(null);
              setError(null);
            }}
            sx={{ mb: 3 }}
          >
            <Tab label="Upload File" icon={<UploadIcon />} iconPosition="start" />
            <Tab label="Paste Text" icon={<PasteIcon />} iconPosition="start" />
          </Tabs>

          {tabValue === 0 && (
            <Box>
              {/* File Upload Area */}
              <Box
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
                sx={{
                  border: '2px dashed',
                  borderColor: dragActive ? 'primary.main' : 'divider',
                  borderRadius: 2,
                  p: 4,
                  textAlign: 'center',
                  backgroundColor: dragActive ? 'rgba(99, 102, 241, 0.08)' : 'background.default',
                  cursor: 'pointer',
                  transition: 'all 0.2s ease',
                  '&:hover': {
                    borderColor: 'primary.main',
                    backgroundColor: 'rgba(99, 102, 241, 0.04)',
                  },
                }}
                onClick={() => document.getElementById('file-input')?.click()}
              >
                <input
                  id="file-input"
                  type="file"
                  hidden
                  accept=".txt,.pdf,.doc,.docx,.xlsx,.xls,.csv,.json,.xml,.html,.md"
                  onChange={handleFileSelect}
                />
                <UploadIcon sx={{ fontSize: 48, color: 'primary.main', mb: 2 }} />
                <Typography variant="h6" gutterBottom>
                  Drag & Drop or Click to Upload
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Supported: TXT, PDF, DOCX, XLSX, CSV, JSON, XML, HTML, MD
                </Typography>
                <Typography variant="caption" color="text.secondary" display="block" sx={{ mt: 1 }}>
                  Maximum file size: 50MB
                </Typography>
              </Box>

              {/* Selected File */}
              {file && (
                <Box sx={{ mt: 3, p: 2, bgcolor: 'background.default', borderRadius: 2 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                    <FileIcon sx={{ fontSize: 40, color: 'primary.main' }} />
                    <Box sx={{ flex: 1 }}>
                      <Typography variant="subtitle1" fontWeight={600}>
                        {file.name}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        {formatFileSize(file.size)} • {file.type || 'Unknown type'}
                      </Typography>
                    </Box>
                    <Button
                      variant="contained"
                      startIcon={scanning ? <CircularProgress size={20} color="inherit" /> : <ScanIcon />}
                      onClick={handleScanFile}
                      disabled={scanning}
                      size="large"
                    >
                      {scanning ? 'Scanning...' : 'Scan File'}
                    </Button>
                  </Box>
                </Box>
              )}
            </Box>
          )}

          {tabValue === 1 && (
            <Box>
              <TextField
                fullWidth
                multiline
                rows={10}
                placeholder="Paste your text here to scan for sensitive data...

Example:
John Doe's SSN is 123-45-6789
Email: john.doe@example.com
Phone: (555) 123-4567
Credit Card: 4111-1111-1111-1111"
                value={text}
                onChange={(e) => setText(e.target.value)}
                sx={{
                  '& .MuiOutlinedInput-root': {
                    fontFamily: 'monospace',
                    fontSize: '0.9rem',
                  },
                }}
              />
              <Box sx={{ mt: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <Typography variant="body2" color="text.secondary">
                  {text.length.toLocaleString()} characters
                </Typography>
                <Button
                  variant="contained"
                  startIcon={scanning ? <CircularProgress size={20} color="inherit" /> : <ScanIcon />}
                  onClick={handleScanText}
                  disabled={scanning || !text.trim()}
                  size="large"
                >
                  {scanning ? 'Scanning...' : 'Scan Text'}
                </Button>
              </Box>
            </Box>
          )}
        </CardContent>
      </Card>

      {/* Error Alert */}
      {error && (
        <Alert severity="error" sx={{ mb: 3 }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      {/* Scanning Progress */}
      {scanning && (
        <Card sx={{ mb: 3 }}>
          <CardContent>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
              <CircularProgress size={24} />
              <Typography>Analyzing content for sensitive data...</Typography>
            </Box>
            <LinearProgress />
          </CardContent>
        </Card>
      )}

      {/* Results Section */}
      {result && (
        <Box>
          {/* Summary Card */}
          <Card sx={{ mb: 3, border: result.hasPII ? '2px solid' : '1px solid', borderColor: result.hasPII ? 'warning.main' : 'success.main' }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
                {result.hasPII ? (
                  <WarningIcon sx={{ fontSize: 48, color: 'warning.main' }} />
                ) : (
                  <CheckIcon sx={{ fontSize: 48, color: 'success.main' }} />
                )}
                <Box>
                  <Typography variant="h5" fontWeight={700}>
                    {result.hasPII ? 'Sensitive Data Detected!' : 'No Sensitive Data Found'}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {result.fileName} • {formatFileSize(result.fileSize)} • {result.textLength.toLocaleString()} characters
                  </Typography>
                </Box>
              </Box>

              {result.message && (
                <Alert severity="info" sx={{ mb: 3 }}>
                  {result.message}
                </Alert>
              )}

              {result.hasPII && (
                <>
                  <Divider sx={{ my: 2 }} />
                  
                  {/* Summary Stats */}
                  <Grid container spacing={3}>
                    <Grid item xs={12} md={6}>
                      <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                        By Severity
                      </Typography>
                      <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                        {Object.entries(result.summary.bySeverity).map(([severity, count]) => (
                          count > 0 && (
                            <Chip
                              key={severity}
                              label={`${severityLabels[severity]}: ${count}`}
                              color={severityColors[severity]}
                              size="small"
                            />
                          )
                        ))}
                      </Box>
                    </Grid>
                    <Grid item xs={12} md={6}>
                      <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                        By Type
                      </Typography>
                      <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                        {result.summary.byType.slice(0, 5).map(({ type, count }) => (
                          <Chip
                            key={type}
                            label={`${type}: ${count}`}
                            variant="outlined"
                            size="small"
                          />
                        ))}
                        {result.summary.byType.length > 5 && (
                          <Chip
                            label={`+${result.summary.byType.length - 5} more`}
                            variant="outlined"
                            size="small"
                          />
                        )}
                      </Box>
                    </Grid>
                  </Grid>
                </>
              )}
            </CardContent>
          </Card>

          {/* Detections Table */}
          {result.detections.length > 0 && (
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Detections ({result.totalDetections})
                </Typography>
                <TableContainer component={Paper} variant="outlined">
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>Type</TableCell>
                        <TableCell>Detected Value (Redacted)</TableCell>
                        <TableCell>Confidence</TableCell>
                        <TableCell>Severity</TableCell>
                        <TableCell>Position</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {result.detections.map((detection, index) => (
                        <TableRow key={index} hover>
                          <TableCell>
                            <Typography variant="body2" fontWeight={500}>
                              {detection.type}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            <Typography
                              variant="body2"
                              sx={{ fontFamily: 'monospace', fontSize: '0.85rem' }}
                            >
                              {detection.text}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                              <LinearProgress
                                variant="determinate"
                                value={detection.confidence * 100}
                                sx={{ width: 60, height: 6, borderRadius: 1 }}
                              />
                              <Typography variant="body2">
                                {(detection.confidence * 100).toFixed(0)}%
                              </Typography>
                            </Box>
                          </TableCell>
                          <TableCell>
                            <Chip
                              label={severityLabels[detection.severity]}
                              color={severityColors[detection.severity]}
                              size="small"
                            />
                          </TableCell>
                          <TableCell>
                            <Typography variant="body2" color="text.secondary">
                              {detection.position.start} - {detection.position.end}
                            </Typography>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              </CardContent>
            </Card>
          )}
        </Box>
      )}
    </Box>
  );
}

