import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3001';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Types
export interface Client {
  id: string;
  hostname: string;
  username: string | null;
  osVersion: string | null;
  clientVersion: string | null;
  ipAddress: string | null;
  lastSeen: string | null;
  status: 'active' | 'inactive' | 'scanning';
  registeredAt: string;
  scanSessions?: ScanSession[];
}

export interface ScanSession {
  id: string;
  clientId: string;
  startedAt: string;
  completedAt: string | null;
  status: 'running' | 'completed' | 'failed' | 'cancelled';
  filesScanned: number;
  detectionsFound: number;
  scanType: 'full' | 'incremental' | 'manual';
  client?: Client;
}

export interface Detection {
  id: string;
  clientId: string;
  sessionId: string | null;
  filePath: string;
  fileName: string | null;
  fileType: string | null;
  fileSize: number | null;
  detectionType: string;
  matchedTextHash: string | null;
  redactedPreview: string | null;
  confidence: number | null;
  severity: 'low' | 'medium' | 'high' | 'critical';
  position: { start: number; end: number } | null;
  detectedAt: string;
  isResolved: boolean;
  resolvedAt: string | null;
  resolvedBy: string | null;
  scanSource?: 'filesystem' | 'clipboard' | 'usb';
  usbDeviceId?: string;
  client?: Client;
}

export interface ClipboardDetection {
  id: string;
  clientId: string;
  contentHash: string;
  detectionType: string;
  redactedPreview: string | null;
  confidence: number | null;
  severity: 'low' | 'medium' | 'high' | 'critical';
  sourceApp: string | null;
  detectedAt: string;
  isResolved: boolean;
  client?: Client;
}

export interface USBDevice {
  id: string;
  clientId: string;
  deviceSerial: string | null;
  deviceVendor: string | null;
  deviceName: string | null;
  driveLetter: string | null;
  firstSeen: string;
  lastSeen: string;
  isWhitelisted: boolean;
  isBlacklisted: boolean;
  totalScans: number;
  totalDetections: number;
  client?: Client;
}

export interface DashboardStats {
  clients: {
    total: number;
    active: number;
  };
  detections: {
    total: number;
    unresolved: number;
    bySeverity: Record<string, number>;
    byType: Array<{ detectionType: string; count: string }>;
    bySource?: Record<string, number>;
  };
  scans: {
    total: number;
    today: number;
    filesScanned: number;
  };
  usb?: {
    totalDevices: number;
  };
  clipboard?: {
    totalDetections: number;
  };
}

export interface RecentActivity {
  detections: Detection[];
  scans: ScanSession[];
  clients: Client[];
}

export interface TrendData {
  detections: Array<{ date: string; count: string }>;
  scans: Array<{ date: string; count: string; filesScanned: string }>;
}

// API functions
export const dashboardApi = {
  getStats: () => api.get<DashboardStats>('/api/dashboard/stats'),
  getRecent: (limit = 20) => api.get<RecentActivity>(`/api/dashboard/recent?limit=${limit}`),
  getTrends: (days = 7) => api.get<TrendData>(`/api/dashboard/trends?days=${days}`),
  getHighRisk: (limit = 10) => api.get<any>(`/api/dashboard/high-risk?limit=${limit}`),
};

export const clientsApi = {
  getAll: (params?: { status?: string; search?: string; limit?: number; offset?: number }) =>
    api.get<{ clients: Client[]; total: number }>('/api/clients', { params }),
  getById: (id: string) => api.get<Client>(`/api/clients/${id}`),
  getDetections: (id: string, params?: { limit?: number; offset?: number; severity?: string }) =>
    api.get<{ detections: Detection[]; total: number }>(`/api/clients/${id}/detections`, { params }),
};

export const detectionsApi = {
  getAll: (params?: {
    clientId?: string;
    severity?: string;
    detectionType?: string;
    isResolved?: boolean;
    scanSource?: string;
    limit?: number;
    offset?: number;
  }) => api.get<{ detections: Detection[]; total: number }>('/api/detections', { params }),
  resolve: (id: string, resolvedBy?: string) =>
    api.put(`/api/detections/${id}/resolve`, { resolvedBy }),
  bulkResolve: (ids: string[], resolvedBy?: string) =>
    api.put('/api/detections/bulk-resolve', { ids, resolvedBy }),
  getStats: (params?: { clientId?: string }) =>
    api.get('/api/detections/stats', { params }),
};

export const sessionsApi = {
  getAll: (params?: { clientId?: string; status?: string; limit?: number; offset?: number }) =>
    api.get<{ sessions: ScanSession[]; total: number }>('/api/sessions', { params }),
  getById: (id: string) => api.get<ScanSession>(`/api/sessions/${id}`),
};

export const clipboardApi = {
  getDetections: (params?: {
    clientId?: string;
    detectionType?: string;
    severity?: string;
    limit?: number;
    offset?: number;
  }) => api.get<{ detections: ClipboardDetection[]; total: number }>('/api/clipboard/detections', { params }),
  getStats: (params?: { clientId?: string }) =>
    api.get('/api/clipboard/stats', { params }),
  getClientDetections: (clientId: string, params?: { limit?: number; offset?: number }) =>
    api.get<{ detections: ClipboardDetection[]; total: number }>(`/api/clipboard/clients/${clientId}/detections`, { params }),
};

export const usbApi = {
  getDevices: (params?: {
    clientId?: string;
    isWhitelisted?: boolean;
    isBlacklisted?: boolean;
    limit?: number;
    offset?: number;
  }) => api.get<{ devices: USBDevice[]; total: number }>('/api/usb/devices', { params }),
  getDevice: (id: string) => api.get<{ device: USBDevice; recentDetections: Detection[] }>(`/api/usb/devices/${id}`),
  getClientDevices: (clientId: string, params?: { limit?: number; offset?: number }) =>
    api.get<{ devices: USBDevice[]; total: number }>(`/api/usb/clients/${clientId}/devices`, { params }),
  whitelistDevice: (id: string) => api.post(`/api/usb/devices/${id}/whitelist`),
  blacklistDevice: (id: string) => api.post(`/api/usb/devices/${id}/blacklist`),
  removeWhitelist: (id: string) => api.delete(`/api/usb/devices/${id}/whitelist`),
  removeBlacklist: (id: string) => api.delete(`/api/usb/devices/${id}/blacklist`),
  getStats: (params?: { clientId?: string }) =>
    api.get('/api/usb/stats', { params }),
  getDetections: (params?: { clientId?: string; deviceId?: string; limit?: number; offset?: number }) =>
    api.get<{ detections: Detection[]; total: number }>('/api/usb/detections', { params }),
};

export default api;

