import { createTheme, alpha } from "@mui/material/styles";

// Custom theme extensions for glassmorphism and glow effects
declare module "@mui/material/styles" {
  interface Theme {
    custom: {
      glassmorphism: {
        background: string;
        backdropFilter: string;
        border: string;
      };
      glows: {
        primary: string;
        secondary: string;
        success: string;
        error: string;
        warning: string;
      };
      gradients: {
        primary: string;
        secondary: string;
        accent: string;
        card: string;
      };
      transitions: {
        smooth: string;
        bounce: string;
      };
    };
  }
  interface ThemeOptions {
    custom?: {
      glassmorphism?: {
        background?: string;
        backdropFilter?: string;
        border?: string;
      };
      glows?: {
        primary?: string;
        secondary?: string;
        success?: string;
        error?: string;
        warning?: string;
      };
      gradients?: {
        primary?: string;
        secondary?: string;
        accent?: string;
        card?: string;
      };
      transitions?: {
        smooth?: string;
        bounce?: string;
      };
    };
  }
}

const theme = createTheme({
  palette: {
    mode: "dark",
    primary: {
      main: "#6366f1",
      light: "#818cf8",
      dark: "#4f46e5",
    },
    secondary: {
      main: "#f472b6",
      light: "#f9a8d4",
      dark: "#ec4899",
    },
    error: {
      main: "#ef4444",
      light: "#f87171",
      dark: "#dc2626",
    },
    warning: {
      main: "#f59e0b",
      light: "#fbbf24",
      dark: "#d97706",
    },
    success: {
      main: "#10b981",
      light: "#34d399",
      dark: "#059669",
    },
    background: {
      default: "#0a0a12",
      paper: "#12121f",
    },
    text: {
      primary: "#f1f5f9",
      secondary: "#94a3b8",
    },
    divider: "rgba(99, 102, 241, 0.12)",
  },
  custom: {
    glassmorphism: {
      background: "rgba(18, 18, 31, 0.7)",
      backdropFilter: "blur(20px)",
      border: "1px solid rgba(99, 102, 241, 0.15)",
    },
    glows: {
      primary: "0 0 30px rgba(99, 102, 241, 0.35)",
      secondary: "0 0 30px rgba(244, 114, 182, 0.35)",
      success: "0 0 30px rgba(16, 185, 129, 0.35)",
      error: "0 0 30px rgba(239, 68, 68, 0.35)",
      warning: "0 0 30px rgba(245, 158, 11, 0.35)",
    },
    gradients: {
      primary: "linear-gradient(135deg, #6366f1 0%, #818cf8 100%)",
      secondary: "linear-gradient(135deg, #f472b6 0%, #f9a8d4 100%)",
      accent: "linear-gradient(135deg, #6366f1 0%, #f472b6 100%)",
      card: "linear-gradient(135deg, rgba(99, 102, 241, 0.08) 0%, rgba(244, 114, 182, 0.05) 100%)",
    },
    transitions: {
      smooth: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
      bounce: "all 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.55)",
    },
  },
  typography: {
    fontFamily: '"Outfit", "Inter", "Roboto", "Helvetica", "Arial", sans-serif',
    h1: {
      fontWeight: 700,
      letterSpacing: "-0.02em",
    },
    h2: {
      fontWeight: 600,
      letterSpacing: "-0.01em",
    },
    h3: {
      fontWeight: 600,
    },
    h4: {
      fontWeight: 600,
    },
    h5: {
      fontWeight: 500,
    },
    h6: {
      fontWeight: 500,
    },
    body1: {
      fontWeight: 400,
    },
    body2: {
      fontWeight: 400,
    },
    button: {
      fontWeight: 500,
      textTransform: "none",
    },
  },
  shape: {
    borderRadius: 16,
  },
  components: {
    MuiCssBaseline: {
      styleOverrides: {
        body: {
          scrollbarWidth: "thin",
          scrollbarColor: "rgba(99, 102, 241, 0.3) transparent",
          "&::-webkit-scrollbar": {
            width: "8px",
            height: "8px",
          },
          "&::-webkit-scrollbar-track": {
            background: "transparent",
          },
          "&::-webkit-scrollbar-thumb": {
            background: "rgba(99, 102, 241, 0.3)",
            borderRadius: "4px",
            "&:hover": {
              background: "rgba(99, 102, 241, 0.5)",
            },
          },
        },
        "*": {
          scrollbarWidth: "thin",
          scrollbarColor: "rgba(99, 102, 241, 0.3) transparent",
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          background: "rgba(18, 18, 31, 0.7)",
          backgroundImage:
            "linear-gradient(135deg, rgba(99, 102, 241, 0.08) 0%, rgba(244, 114, 182, 0.05) 100%)",
          border: "1px solid rgba(99, 102, 241, 0.12)",
          backdropFilter: "blur(20px)",
          transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
          "&:hover": {
            border: "1px solid rgba(99, 102, 241, 0.25)",
            transform: "translateY(-2px)",
            boxShadow: "0 8px 30px rgba(0, 0, 0, 0.3)",
          },
        },
      },
    },
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 10,
          padding: "10px 24px",
          transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
        },
        contained: {
          background: "linear-gradient(135deg, #6366f1 0%, #818cf8 100%)",
          boxShadow: "0 4px 20px rgba(99, 102, 241, 0.35)",
          "&:hover": {
            background: "linear-gradient(135deg, #4f46e5 0%, #6366f1 100%)",
            boxShadow: "0 6px 30px rgba(99, 102, 241, 0.5)",
            transform: "translateY(-1px)",
          },
        },
        outlined: {
          borderColor: "rgba(99, 102, 241, 0.5)",
          "&:hover": {
            borderColor: "#6366f1",
            backgroundColor: "rgba(99, 102, 241, 0.1)",
          },
        },
      },
    },
    MuiChip: {
      styleOverrides: {
        root: {
          fontWeight: 500,
          transition: "all 0.2s ease",
          "&:hover": {
            transform: "scale(1.02)",
          },
        },
        colorSuccess: {
          background: "rgba(16, 185, 129, 0.15)",
          color: "#34d399",
          border: "1px solid rgba(16, 185, 129, 0.3)",
        },
        colorError: {
          background: "rgba(239, 68, 68, 0.15)",
          color: "#f87171",
          border: "1px solid rgba(239, 68, 68, 0.3)",
        },
        colorWarning: {
          background: "rgba(245, 158, 11, 0.15)",
          color: "#fbbf24",
          border: "1px solid rgba(245, 158, 11, 0.3)",
        },
        colorInfo: {
          background: "rgba(99, 102, 241, 0.15)",
          color: "#818cf8",
          border: "1px solid rgba(99, 102, 241, 0.3)",
        },
      },
    },
    MuiTableCell: {
      styleOverrides: {
        root: {
          borderColor: "rgba(99, 102, 241, 0.08)",
          padding: "16px",
        },
        head: {
          fontWeight: 600,
          backgroundColor: "rgba(99, 102, 241, 0.05)",
          color: "#94a3b8",
          textTransform: "uppercase",
          fontSize: "0.75rem",
          letterSpacing: "0.05em",
        },
      },
    },
    MuiTableRow: {
      styleOverrides: {
        root: {
          transition: "all 0.2s ease",
          "&:hover": {
            backgroundColor: "rgba(99, 102, 241, 0.05)",
          },
        },
      },
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          backgroundImage: "none",
          backgroundColor: "rgba(18, 18, 31, 0.7)",
        },
      },
    },
    MuiLinearProgress: {
      styleOverrides: {
        root: {
          borderRadius: 4,
          backgroundColor: "rgba(99, 102, 241, 0.15)",
        },
        bar: {
          borderRadius: 4,
          background: "linear-gradient(90deg, #6366f1 0%, #818cf8 100%)",
        },
      },
    },
    MuiCircularProgress: {
      styleOverrides: {
        circle: {
          strokeLinecap: "round",
        },
      },
    },
    MuiTab: {
      styleOverrides: {
        root: {
          transition: "all 0.3s ease",
          "&.Mui-selected": {
            color: "#6366f1",
          },
        },
      },
    },
    MuiTabs: {
      styleOverrides: {
        indicator: {
          background: "linear-gradient(90deg, #6366f1 0%, #f472b6 100%)",
          height: 3,
          borderRadius: 2,
        },
      },
    },
    MuiAlert: {
      styleOverrides: {
        root: {
          borderRadius: 12,
          backdropFilter: "blur(10px)",
        },
        standardError: {
          background: "rgba(239, 68, 68, 0.1)",
          border: "1px solid rgba(239, 68, 68, 0.3)",
        },
        standardWarning: {
          background: "rgba(245, 158, 11, 0.1)",
          border: "1px solid rgba(245, 158, 11, 0.3)",
        },
        standardSuccess: {
          background: "rgba(16, 185, 129, 0.1)",
          border: "1px solid rgba(16, 185, 129, 0.3)",
        },
        standardInfo: {
          background: "rgba(99, 102, 241, 0.1)",
          border: "1px solid rgba(99, 102, 241, 0.3)",
        },
      },
    },
    MuiTooltip: {
      styleOverrides: {
        tooltip: {
          backgroundColor: "rgba(18, 18, 31, 0.95)",
          backdropFilter: "blur(10px)",
          border: "1px solid rgba(99, 102, 241, 0.2)",
          borderRadius: 8,
          fontSize: "0.8rem",
          padding: "8px 12px",
        },
        arrow: {
          color: "rgba(18, 18, 31, 0.95)",
        },
      },
    },
    MuiTextField: {
      styleOverrides: {
        root: {
          "& .MuiOutlinedInput-root": {
            transition: "all 0.3s ease",
            "&:hover .MuiOutlinedInput-notchedOutline": {
              borderColor: "rgba(99, 102, 241, 0.5)",
            },
            "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
              borderColor: "#6366f1",
              boxShadow: "0 0 0 3px rgba(99, 102, 241, 0.15)",
            },
          },
        },
      },
    },
    MuiSelect: {
      styleOverrides: {
        root: {
          "&:hover .MuiOutlinedInput-notchedOutline": {
            borderColor: "rgba(99, 102, 241, 0.5)",
          },
          "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
            borderColor: "#6366f1",
            boxShadow: "0 0 0 3px rgba(99, 102, 241, 0.15)",
          },
        },
      },
    },
    MuiIconButton: {
      styleOverrides: {
        root: {
          transition: "all 0.2s ease",
          "&:hover": {
            backgroundColor: "rgba(99, 102, 241, 0.1)",
            transform: "scale(1.05)",
          },
        },
      },
    },
  },
});

export default theme;
