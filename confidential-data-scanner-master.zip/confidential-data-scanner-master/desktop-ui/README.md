# Desktop UI

Electron-based desktop application for monitoring the local Windows Scanner Service.

## Features

- Real-time service status monitoring
- Scan progress visualization
- Detection list with file location access
- Configuration management
- Start/stop manual scans

## Setup

### Prerequisites

- Node.js 18+

### Installation

```bash
cd desktop-ui

# Install dependencies
npm install
```

### Development

```bash
# Start in development mode (React + Electron)
npm start
```

This will:
1. Start the React development server on port 3000
2. Launch Electron once React is ready

### Building for Production

```bash
# Build React and package with Electron
npm run dist

# Build for Windows specifically
npm run dist:win
```

The built application will be in the `dist/` directory.

## Pages

### Status (`/`)
- Service running status
- Scan progress with real-time updates
- Start/stop scan controls
- Statistics (total detections, uptime, last/next scan)

### Detections (`/detections`)
- List of all local detections
- File name, type, severity, preview
- Open file location in explorer
- Pagination support

### Settings (`/settings`)
- Configure scan directories
- Manage file type filters
- Set scan interval and worker count
- Configure server endpoints

## Architecture

```
desktop-ui/
├── electron/
│   ├── main.js          # Electron main process
│   └── preload.js       # Preload script for IPC
├── public/
│   └── index.html       # HTML template
├── src/
│   ├── App.tsx          # Main app component
│   ├── index.tsx        # Entry point
│   ├── theme.ts         # MUI theme
│   ├── components/
│   │   └── Layout.tsx   # App layout with sidebar
│   ├── pages/
│   │   ├── Status.tsx   # Status dashboard
│   │   ├── Detections.tsx # Detections list
│   │   └── Settings.tsx # Configuration UI
│   └── services/
│       └── api.ts       # API client for local service
├── package.json
└── README.md
```

## Communication

The desktop UI communicates with the local Windows Scanner Service via REST API on port 8080:

- `GET /api/status` - Service status and scan progress
- `GET /api/detections` - List of detections
- `GET /api/config` - Current configuration
- `PUT /api/config` - Update configuration
- `POST /api/scan/start` - Start a scan
- `POST /api/scan/stop` - Stop current scan

## Tech Stack

- Electron 28
- React 18 with TypeScript
- Material-UI v5
- Axios for HTTP requests

