const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  openFileLocation: (filePath) => ipcRenderer.invoke('open-file-location', filePath),
  getAppVersion: () => ipcRenderer.invoke('get-app-version'),
});

