import React, { useState, useEffect } from 'react';
import {
  Box,
  Card,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  Chip,
  IconButton,
  Tooltip,
  CircularProgress,
  Alert,
} from '@mui/material';
import {
  FolderOpen as FolderIcon,
  Warning as WarningIcon,
} from '@mui/icons-material';
import { serviceApi, Detection } from '../services/api';

declare global {
  interface Window {
    electronAPI?: {
      openFileLocation: (filePath: string) => Promise<void>;
    };
  }
}

const severityConfig = {
  low: { label: 'Low', color: '#22c55e', bgColor: 'rgba(34, 197, 94, 0.15)' },
  medium: { label: 'Medium', color: '#fbbf24', bgColor: 'rgba(251, 191, 36, 0.15)' },
  high: { label: 'High', color: '#f97316', bgColor: 'rgba(249, 115, 22, 0.15)' },
  critical: { label: 'Critical', color: '#f87171', bgColor: 'rgba(248, 113, 113, 0.15)' },
};

const typeConfig: Record<string, { label: string; color: string }> = {
  AADHAR: { label: 'Aadhar', color: '#818cf8' },
  PAN: { label: 'PAN', color: '#a78bfa' },
  US_SSN: { label: 'SSN', color: '#f472b6' },
  CREDIT_CARD: { label: 'Credit Card', color: '#fbbf24' },
  EMAIL_ADDRESS: { label: 'Email', color: '#2dd4bf' },
  PHONE_NUMBER: { label: 'Phone', color: '#38bdf8' },
  INDIAN_PASSPORT: { label: 'Passport', color: '#a3e635' },
  VOTER_ID: { label: 'Voter ID', color: '#fb7185' },
  DRIVING_LICENSE: { label: 'DL', color: '#c084fc' },
};

export default function Detections() {
  const [detections, setDetections] = useState<Detection[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(25);

  useEffect(() => {
    const fetchDetections = async () => {
      try {
        setLoading(true);
        const response = await serviceApi.getDetections({
          limit: rowsPerPage,
          offset: page * rowsPerPage,
        });
        setDetections(response.data.detections || []);
        setTotal(response.data.total || 0);
        setError(null);
      } catch (err) {
        setError('Cannot connect to scanner service.');
      } finally {
        setLoading(false);
      }
    };

    fetchDetections();
  }, [page, rowsPerPage]);

  const handleOpenFileLocation = async (filePath: string) => {
    if (window.electronAPI) {
      await window.electronAPI.openFileLocation(filePath);
    }
  };

  const getSeverityChip = (severity: string) => {
    const config = severityConfig[severity as keyof typeof severityConfig] || severityConfig.medium;
    return (
      <Chip
        label={config.label}
        size="small"
        sx={{
          color: config.color,
          backgroundColor: config.bgColor,
          fontWeight: 600,
          border: `1px solid ${config.color}30`,
        }}
      />
    );
  };

  const getTypeChip = (type: string) => {
    const config = typeConfig[type] || { label: type, color: '#94a3b8' };
    return (
      <Chip
        label={config.label}
        size="small"
        sx={{
          color: config.color,
          backgroundColor: `${config.color}20`,
          fontWeight: 500,
          border: `1px solid ${config.color}30`,
        }}
      />
    );
  };

  if (error) {
    return (
      <Box>
        <Typography variant="h4" sx={{ mb: 3, fontWeight: 700 }}>
          Detections
        </Typography>
        <Alert severity="error">{error}</Alert>
      </Box>
    );
  }

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" sx={{ fontWeight: 700 }}>
          Detections
        </Typography>
        <Chip
          icon={<WarningIcon />}
          label={`${total} total`}
          color="warning"
          sx={{ fontWeight: 600 }}
        />
      </Box>

      <Card>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>File</TableCell>
                <TableCell>Type</TableCell>
                <TableCell>Severity</TableCell>
                <TableCell>Preview</TableCell>
                <TableCell>Detected</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={6} align="center" sx={{ py: 4 }}>
                    <CircularProgress size={32} />
                  </TableCell>
                </TableRow>
              ) : detections.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} align="center" sx={{ py: 6 }}>
                    <WarningIcon sx={{ fontSize: 48, color: 'text.secondary', mb: 1 }} />
                    <Typography color="text.secondary">
                      No detections found
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Start a scan to detect confidential data in your files
                    </Typography>
                  </TableCell>
                </TableRow>
              ) : (
                detections.map((detection) => (
                  <TableRow key={detection.id} hover>
                    <TableCell>
                      <Typography variant="body2" fontWeight={500}>
                        {detection.fileName}
                      </Typography>
                      <Typography
                        variant="caption"
                        color="text.secondary"
                        sx={{
                          display: 'block',
                          maxWidth: 250,
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                          whiteSpace: 'nowrap',
                        }}
                      >
                        {detection.filePath}
                      </Typography>
                    </TableCell>
                    <TableCell>{getTypeChip(detection.detectionType)}</TableCell>
                    <TableCell>{getSeverityChip(detection.severity)}</TableCell>
                    <TableCell>
                      <Typography
                        variant="body2"
                        sx={{
                          fontFamily: '"JetBrains Mono", monospace',
                          fontSize: '0.75rem',
                          color: 'text.secondary',
                        }}
                      >
                        {detection.redactedPreview || '-'}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" color="text.secondary">
                        {new Date(detection.detectedAt).toLocaleString()}
                      </Typography>
                    </TableCell>
                    <TableCell align="right">
                      <Tooltip title="Open File Location">
                        <IconButton
                          size="small"
                          onClick={() => handleOpenFileLocation(detection.filePath)}
                        >
                          <FolderIcon />
                        </IconButton>
                      </Tooltip>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>
        <TablePagination
          rowsPerPageOptions={[10, 25, 50, 100]}
          component="div"
          count={total}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={(_, newPage) => setPage(newPage)}
          onRowsPerPageChange={(e) => {
            setRowsPerPage(parseInt(e.target.value, 10));
            setPage(0);
          }}
        />
      </Card>
    </Box>
  );
}

