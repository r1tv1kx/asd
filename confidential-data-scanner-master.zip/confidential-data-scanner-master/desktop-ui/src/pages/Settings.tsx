import React, { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  TextField,
  Button,
  Grid,
  Chip,
  IconButton,
  Alert,
  CircularProgress,
  Divider,
} from '@mui/material';
import {
  Add as AddIcon,
  Delete as DeleteIcon,
  Save as SaveIcon,
  Refresh as RefreshIcon,
  ContentPaste as ClipboardIcon,
  Usb as UsbIcon,
} from '@mui/icons-material';
import { serviceApi, Config } from '../services/api';

export default function Settings() {
  const [config, setConfig] = useState<Config | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [newDirectory, setNewDirectory] = useState('');
  const [newFileType, setNewFileType] = useState('');

  const fetchConfig = async () => {
    try {
      setLoading(true);
      const response = await serviceApi.getConfig();
      setConfig(response.data);
      setError(null);
    } catch (err) {
      setError('Cannot connect to scanner service.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchConfig();
  }, []);

  const handleSave = async () => {
    if (!config) return;

    try {
      setSaving(true);
      await serviceApi.updateConfig(config);
      setSuccess('Settings saved successfully');
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      setError('Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  const handleAddDirectory = () => {
    if (!newDirectory.trim() || !config) return;
    setConfig({
      ...config,
      scan: {
        ...config.scan,
        directories: [...config.scan.directories, newDirectory.trim()],
      },
    });
    setNewDirectory('');
  };

  const handleRemoveDirectory = (index: number) => {
    if (!config) return;
    setConfig({
      ...config,
      scan: {
        ...config.scan,
        directories: config.scan.directories.filter((_, i) => i !== index),
      },
    });
  };

  const handleAddFileType = () => {
    if (!newFileType.trim() || !config) return;
    let type = newFileType.trim();
    if (!type.startsWith('.')) {
      type = '.' + type;
    }
    if (!config.scan.file_types.includes(type)) {
      setConfig({
        ...config,
        scan: {
          ...config.scan,
          file_types: [...config.scan.file_types, type],
        },
      });
    }
    setNewFileType('');
  };

  const handleRemoveFileType = (type: string) => {
    if (!config) return;
    setConfig({
      ...config,
      scan: {
        ...config.scan,
        file_types: config.scan.file_types.filter((t) => t !== type),
      },
    });
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: 400 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error && !config) {
    return (
      <Box>
        <Typography variant="h4" sx={{ mb: 3, fontWeight: 700 }}>
          Settings
        </Typography>
        <Alert severity="error">{error}</Alert>
        <Button
          variant="outlined"
          startIcon={<RefreshIcon />}
          onClick={fetchConfig}
          sx={{ mt: 2 }}
        >
          Retry
        </Button>
      </Box>
    );
  }

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" sx={{ fontWeight: 700 }}>
          Settings
        </Typography>
        <Button
          variant="contained"
          startIcon={saving ? <CircularProgress size={18} color="inherit" /> : <SaveIcon />}
          onClick={handleSave}
          disabled={saving}
        >
          Save Changes
        </Button>
      </Box>

      {success && (
        <Alert severity="success" sx={{ mb: 3 }}>
          {success}
        </Alert>
      )}
      {error && config && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      <Grid container spacing={3}>
        {/* Scan Directories */}
        <Grid item xs={12}>
          <Card>
            <CardContent sx={{ p: 3 }}>
              <Typography variant="h6" sx={{ mb: 2 }}>
                Scan Directories
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                Directories that will be scanned for confidential data
              </Typography>

              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 2 }}>
                {config?.scan.directories.map((dir, index) => (
                  <Chip
                    key={index}
                    label={dir}
                    onDelete={() => handleRemoveDirectory(index)}
                    deleteIcon={<DeleteIcon />}
                    sx={{
                      backgroundColor: 'rgba(129, 140, 248, 0.1)',
                      border: '1px solid rgba(129, 140, 248, 0.2)',
                    }}
                  />
                ))}
              </Box>

              <Box sx={{ display: 'flex', gap: 1 }}>
                <TextField
                  size="small"
                  placeholder="Add directory path..."
                  value={newDirectory}
                  onChange={(e) => setNewDirectory(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleAddDirectory()}
                  sx={{ flex: 1 }}
                />
                <Button
                  variant="outlined"
                  startIcon={<AddIcon />}
                  onClick={handleAddDirectory}
                >
                  Add
                </Button>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* File Types */}
        <Grid item xs={12} md={6}>
          <Card sx={{ height: '100%' }}>
            <CardContent sx={{ p: 3 }}>
              <Typography variant="h6" sx={{ mb: 2 }}>
                File Types
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                File extensions to scan
              </Typography>

              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 2 }}>
                {config?.scan.file_types.map((type) => (
                  <Chip
                    key={type}
                    label={type}
                    onDelete={() => handleRemoveFileType(type)}
                    deleteIcon={<DeleteIcon />}
                    size="small"
                    sx={{
                      backgroundColor: 'rgba(52, 211, 153, 0.1)',
                      border: '1px solid rgba(52, 211, 153, 0.2)',
                    }}
                  />
                ))}
              </Box>

              <Box sx={{ display: 'flex', gap: 1 }}>
                <TextField
                  size="small"
                  placeholder=".pdf"
                  value={newFileType}
                  onChange={(e) => setNewFileType(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleAddFileType()}
                  sx={{ width: 100 }}
                />
                <Button variant="outlined" size="small" onClick={handleAddFileType}>
                  Add
                </Button>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Scan Settings */}
        <Grid item xs={12} md={6}>
          <Card sx={{ height: '100%' }}>
            <CardContent sx={{ p: 3 }}>
              <Typography variant="h6" sx={{ mb: 2 }}>
                Scan Settings
              </Typography>

              <Grid container spacing={2}>
                <Grid item xs={6}>
                  <TextField
                    label="Scan Interval (hours)"
                    type="number"
                    size="small"
                    fullWidth
                    value={config?.scan.interval_hours || 24}
                    onChange={(e) =>
                      setConfig(
                        config
                          ? {
                              ...config,
                              scan: {
                                ...config.scan,
                                interval_hours: parseInt(e.target.value) || 24,
                              },
                            }
                          : null
                      )
                    }
                  />
                </Grid>
                <Grid item xs={6}>
                  <TextField
                    label="Max File Size (MB)"
                    type="number"
                    size="small"
                    fullWidth
                    value={config?.scan.max_file_size_mb || 50}
                    onChange={(e) =>
                      setConfig(
                        config
                          ? {
                              ...config,
                              scan: {
                                ...config.scan,
                                max_file_size_mb: parseInt(e.target.value) || 50,
                              },
                            }
                          : null
                      )
                    }
                  />
                </Grid>
                <Grid item xs={6}>
                  <TextField
                    label="Worker Threads"
                    type="number"
                    size="small"
                    fullWidth
                    value={config?.scan.worker_count || 4}
                    onChange={(e) =>
                      setConfig(
                        config
                          ? {
                              ...config,
                              scan: {
                                ...config.scan,
                                worker_count: parseInt(e.target.value) || 4,
                              },
                            }
                          : null
                      )
                    }
                  />
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>

        {/* Clipboard Monitoring Settings */}
        <Grid item xs={12} md={6}>
          <Card sx={{ height: '100%' }}>
            <CardContent sx={{ p: 3 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                <ClipboardIcon color="primary" />
                <Typography variant="h6">
                  Clipboard Monitoring
                </Typography>
              </Box>

              <Grid container spacing={2}>
                <Grid item xs={6}>
                  <TextField
                    label="Check Interval (ms)"
                    type="number"
                    size="small"
                    fullWidth
                    value={config?.clipboard?.check_interval_ms || 500}
                    onChange={(e) =>
                      setConfig(
                        config
                          ? {
                              ...config,
                              clipboard: {
                                ...config.clipboard,
                                check_interval_ms: parseInt(e.target.value) || 500,
                              },
                            }
                          : null
                      )
                    }
                  />
                </Grid>
                <Grid item xs={6}>
                  <TextField
                    label="Min Text Length"
                    type="number"
                    size="small"
                    fullWidth
                    value={config?.clipboard?.min_text_length || 10}
                    onChange={(e) =>
                      setConfig(
                        config
                          ? {
                              ...config,
                              clipboard: {
                                ...config.clipboard,
                                min_text_length: parseInt(e.target.value) || 10,
                              },
                            }
                          : null
                      )
                    }
                  />
                </Grid>
                <Grid item xs={6}>
                  <TextField
                    label="Retention (hours)"
                    type="number"
                    size="small"
                    fullWidth
                    value={config?.clipboard?.retention_hours || 24}
                    onChange={(e) =>
                      setConfig(
                        config
                          ? {
                              ...config,
                              clipboard: {
                                ...config.clipboard,
                                retention_hours: parseInt(e.target.value) || 24,
                              },
                            }
                          : null
                      )
                    }
                  />
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>

        {/* USB Monitoring Settings */}
        <Grid item xs={12} md={6}>
          <Card sx={{ height: '100%' }}>
            <CardContent sx={{ p: 3 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                <UsbIcon color="primary" />
                <Typography variant="h6">
                  USB Monitoring
                </Typography>
              </Box>

              <Grid container spacing={2}>
                <Grid item xs={6}>
                  <TextField
                    label="Max Scan Size (GB)"
                    type="number"
                    size="small"
                    fullWidth
                    value={config?.usb?.max_scan_size_gb || 32}
                    onChange={(e) =>
                      setConfig(
                        config
                          ? {
                              ...config,
                              usb: {
                                ...config.usb,
                                max_scan_size_gb: parseInt(e.target.value) || 32,
                              },
                            }
                          : null
                      )
                    }
                  />
                </Grid>
                <Grid item xs={6}>
                  <TextField
                    label="Scan Timeout (min)"
                    type="number"
                    size="small"
                    fullWidth
                    value={config?.usb?.scan_timeout_minutes || 30}
                    onChange={(e) =>
                      setConfig(
                        config
                          ? {
                              ...config,
                              usb: {
                                ...config.usb,
                                scan_timeout_minutes: parseInt(e.target.value) || 30,
                              },
                            }
                          : null
                      )
                    }
                  />
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>

        {/* Server Settings */}
        <Grid item xs={12}>
          <Card>
            <CardContent sx={{ p: 3 }}>
              <Typography variant="h6" sx={{ mb: 2 }}>
                Server Endpoints
              </Typography>

              <Grid container spacing={2}>
                <Grid item xs={12} md={6}>
                  <TextField
                    label="Analyzer Server URL"
                    size="small"
                    fullWidth
                    value={config?.servers.analyzer_url || ''}
                    onChange={(e) =>
                      setConfig(
                        config
                          ? {
                              ...config,
                              servers: {
                                ...config.servers,
                                analyzer_url: e.target.value,
                              },
                            }
                          : null
                      )
                    }
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    label="Dashboard Server URL"
                    size="small"
                    fullWidth
                    value={config?.servers.dashboard_url || ''}
                    onChange={(e) =>
                      setConfig(
                        config
                          ? {
                              ...config,
                              servers: {
                                ...config.servers,
                                dashboard_url: e.target.value,
                              },
                            }
                          : null
                      )
                    }
                  />
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}

