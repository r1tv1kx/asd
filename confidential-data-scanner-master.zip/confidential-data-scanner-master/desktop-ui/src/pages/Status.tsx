import React, { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  Grid,
  LinearProgress,
  Chip,
  Alert,
  CircularProgress,
} from '@mui/material';
import {
  PlayArrow as PlayIcon,
  Stop as StopIcon,
  CheckCircle as CheckIcon,
  Error as ErrorIcon,
  Schedule as ScheduleIcon,
  Folder as FolderIcon,
  Warning as WarningIcon,
  ContentPaste as ClipboardIcon,
  Usb as UsbIcon,
} from '@mui/icons-material';
import { serviceApi, ServiceStatus, ClipboardStatus, USBStatus } from '../services/api';

export default function Status() {
  const [status, setStatus] = useState<ServiceStatus | null>(null);
  const [clipboardStatus, setClipboardStatus] = useState<ClipboardStatus | null>(null);
  const [usbStatus, setUsbStatus] = useState<USBStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState(false);

  const fetchStatus = async () => {
    try {
      const [statusRes, clipboardRes, usbRes] = await Promise.all([
        serviceApi.getStatus(),
        serviceApi.getClipboardStatus().catch(() => ({ data: null })),
        serviceApi.getUSBStatus().catch(() => ({ data: null })),
      ]);
      setStatus(statusRes.data);
      setClipboardStatus(clipboardRes.data);
      setUsbStatus(usbRes.data);
      setError(null);
    } catch (err) {
      setError('Cannot connect to scanner service. Make sure the service is running.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStatus();
    const interval = setInterval(fetchStatus, 2000);
    return () => clearInterval(interval);
  }, []);

  const handleStartScan = async () => {
    setActionLoading(true);
    try {
      await serviceApi.startScan('manual');
      fetchStatus();
    } catch (err) {
      console.error('Failed to start scan:', err);
    } finally {
      setActionLoading(false);
    }
  };

  const handleStopScan = async () => {
    setActionLoading(true);
    try {
      await serviceApi.stopScan();
      fetchStatus();
    } catch (err) {
      console.error('Failed to stop scan:', err);
    } finally {
      setActionLoading(false);
    }
  };

  const formatDuration = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    
    if (hours > 0) {
      return `${hours}h ${minutes}m`;
    }
    if (minutes > 0) {
      return `${minutes}m ${secs}s`;
    }
    return `${secs}s`;
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: 400 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box>
        <Typography variant="h4" sx={{ mb: 3, fontWeight: 700 }}>
          Service Status
        </Typography>
        <Alert
          severity="error"
          icon={<ErrorIcon />}
          sx={{
            backgroundColor: 'rgba(248, 113, 113, 0.1)',
            border: '1px solid rgba(248, 113, 113, 0.2)',
          }}
        >
          {error}
        </Alert>
        <Button
          variant="outlined"
          onClick={fetchStatus}
          sx={{ mt: 2 }}
        >
          Retry Connection
        </Button>
      </Box>
    );
  }

  const isScanning = status?.scanProgress?.isScanning;
  const progress = status?.scanProgress;

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Typography variant="h4" sx={{ fontWeight: 700 }}>
          Service Status
        </Typography>
        <Chip
          icon={status?.status === 'running' ? <CheckIcon /> : <ErrorIcon />}
          label={status?.status === 'running' ? 'Service Running' : 'Service Stopped'}
          color={status?.status === 'running' ? 'success' : 'error'}
          sx={{ fontWeight: 600 }}
        />
      </Box>

      {/* Scan Progress Card */}
      <Card sx={{ mb: 3 }}>
        <CardContent sx={{ p: 4 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 3 }}>
            <Box>
              <Typography variant="h6" sx={{ mb: 1 }}>
                {isScanning ? 'Scan in Progress' : 'Ready to Scan'}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {isScanning
                  ? `Scanning: ${progress?.currentFile?.split(/[/\\]/).pop() || 'Processing...'}`
                  : 'Click the button to start a new scan'}
              </Typography>
            </Box>
            <Button
              variant="contained"
              color={isScanning ? 'error' : 'primary'}
              startIcon={isScanning ? <StopIcon /> : <PlayIcon />}
              onClick={isScanning ? handleStopScan : handleStartScan}
              disabled={actionLoading}
              sx={{ minWidth: 140 }}
            >
              {actionLoading ? (
                <CircularProgress size={20} color="inherit" />
              ) : isScanning ? (
                'Stop Scan'
              ) : (
                'Start Scan'
              )}
            </Button>
          </Box>

          {isScanning && progress && (
            <Box>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                <Typography variant="body2" color="text.secondary">
                  {progress.filesScanned} / {progress.totalFiles} files
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {Math.round((progress.filesScanned / Math.max(progress.totalFiles, 1)) * 100)}%
                </Typography>
              </Box>
              <LinearProgress
                variant="determinate"
                value={(progress.filesScanned / Math.max(progress.totalFiles, 1)) * 100}
                sx={{ height: 8, mb: 2 }}
              />
              <Box sx={{ display: 'flex', gap: 3 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <WarningIcon color="warning" fontSize="small" />
                  <Typography variant="body2">
                    {progress.detectionsFound} detections found
                  </Typography>
                </Box>
                {progress.estimatedTimeSeconds > 0 && (
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <ScheduleIcon fontSize="small" color="action" />
                    <Typography variant="body2" color="text.secondary">
                      ~{formatDuration(progress.estimatedTimeSeconds)} remaining
                    </Typography>
                  </Box>
                )}
              </Box>
            </Box>
          )}
        </CardContent>
      </Card>

      {/* Stats Grid */}
      <Grid container spacing={3}>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent sx={{ p: 3 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Box
                  sx={{
                    p: 1.5,
                    borderRadius: 2,
                    backgroundColor: 'rgba(248, 113, 113, 0.15)',
                    color: 'error.main',
                  }}
                >
                  <WarningIcon />
                </Box>
                <Box>
                  <Typography variant="body2" color="text.secondary">
                    Total Detections
                  </Typography>
                  <Typography
                    variant="h4"
                    sx={{ fontWeight: 700, fontFamily: '"JetBrains Mono", monospace' }}
                  >
                    {status?.totalDetections || 0}
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent sx={{ p: 3 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Box
                  sx={{
                    p: 1.5,
                    borderRadius: 2,
                    backgroundColor: 'rgba(129, 140, 248, 0.15)',
                    color: 'primary.main',
                  }}
                >
                  <ScheduleIcon />
                </Box>
                <Box>
                  <Typography variant="body2" color="text.secondary">
                    Uptime
                  </Typography>
                  <Typography
                    variant="h4"
                    sx={{ fontWeight: 700, fontFamily: '"JetBrains Mono", monospace' }}
                  >
                    {formatDuration(status?.uptimeSeconds || 0)}
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent sx={{ p: 3 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Box
                  sx={{
                    p: 1.5,
                    borderRadius: 2,
                    backgroundColor: 'rgba(52, 211, 153, 0.15)',
                    color: 'success.main',
                  }}
                >
                  <CheckIcon />
                </Box>
                <Box>
                  <Typography variant="body2" color="text.secondary">
                    Last Scan
                  </Typography>
                  <Typography variant="body1" sx={{ fontWeight: 500 }}>
                    {status?.lastScan
                      ? new Date(status.lastScan).toLocaleString()
                      : 'Never'}
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent sx={{ p: 3 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Box
                  sx={{
                    p: 1.5,
                    borderRadius: 2,
                    backgroundColor: 'rgba(251, 191, 36, 0.15)',
                    color: 'warning.main',
                  }}
                >
                  <FolderIcon />
                </Box>
                <Box>
                  <Typography variant="body2" color="text.secondary">
                    Next Scan
                  </Typography>
                  <Typography variant="body1" sx={{ fontWeight: 500 }}>
                    {status?.nextScan
                      ? new Date(status.nextScan).toLocaleString()
                      : 'Not scheduled'}
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Monitoring Status */}
      <Typography variant="h6" sx={{ mt: 4, mb: 2 }}>
        Monitoring Status
      </Typography>
      <Grid container spacing={3}>
        {/* Clipboard Monitor */}
        <Grid item xs={12} sm={6}>
          <Card>
            <CardContent sx={{ p: 3 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                  <Box
                    sx={{
                      p: 1.5,
                      borderRadius: 2,
                      backgroundColor: clipboardStatus?.isMonitoring 
                        ? 'rgba(52, 211, 153, 0.15)' 
                        : 'rgba(156, 163, 175, 0.15)',
                      color: clipboardStatus?.isMonitoring ? 'success.main' : 'text.secondary',
                    }}
                  >
                    <ClipboardIcon />
                  </Box>
                  <Box>
                    <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
                      Clipboard Monitor
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {clipboardStatus?.isMonitoring ? 'Active' : 'Inactive'}
                    </Typography>
                  </Box>
                </Box>
                <Chip
                  size="small"
                  label={clipboardStatus?.enabled ? 'Enabled' : 'Disabled'}
                  color={clipboardStatus?.enabled ? 'success' : 'default'}
                />
              </Box>
              <Box sx={{ display: 'flex', gap: 3 }}>
                <Box>
                  <Typography variant="body2" color="text.secondary">
                    Detections
                  </Typography>
                  <Typography variant="h6" sx={{ fontWeight: 600 }}>
                    {clipboardStatus?.totalDetections || 0}
                  </Typography>
                </Box>
                <Box>
                  <Typography variant="body2" color="text.secondary">
                    Check Interval
                  </Typography>
                  <Typography variant="h6" sx={{ fontWeight: 600 }}>
                    {clipboardStatus?.checkIntervalMs || 500}ms
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* USB Monitor */}
        <Grid item xs={12} sm={6}>
          <Card>
            <CardContent sx={{ p: 3 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                  <Box
                    sx={{
                      p: 1.5,
                      borderRadius: 2,
                      backgroundColor: usbStatus?.isMonitoring 
                        ? 'rgba(52, 211, 153, 0.15)' 
                        : 'rgba(156, 163, 175, 0.15)',
                      color: usbStatus?.isMonitoring ? 'success.main' : 'text.secondary',
                    }}
                  >
                    <UsbIcon />
                  </Box>
                  <Box>
                    <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
                      USB Monitor
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {usbStatus?.isMonitoring ? 'Active' : 'Inactive'}
                    </Typography>
                  </Box>
                </Box>
                <Chip
                  size="small"
                  label={usbStatus?.enabled ? 'Enabled' : 'Disabled'}
                  color={usbStatus?.enabled ? 'success' : 'default'}
                />
              </Box>
              <Box sx={{ display: 'flex', gap: 3 }}>
                <Box>
                  <Typography variant="body2" color="text.secondary">
                    Connected
                  </Typography>
                  <Typography variant="h6" sx={{ fontWeight: 600 }}>
                    {usbStatus?.connectedDevices || 0}
                  </Typography>
                </Box>
                <Box>
                  <Typography variant="body2" color="text.secondary">
                    Total Seen
                  </Typography>
                  <Typography variant="h6" sx={{ fontWeight: 600 }}>
                    {usbStatus?.totalDevicesSeen || 0}
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}

