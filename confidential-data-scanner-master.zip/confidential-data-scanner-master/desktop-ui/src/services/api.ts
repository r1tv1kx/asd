import axios from 'axios';

const API_BASE_URL = 'http://localhost:8080';

const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
});

// Types
export interface ScanProgress {
  isScanning: boolean;
  currentFile: string;
  filesScanned: number;
  totalFiles: number;
  detectionsFound: number;
  startedAt: string;
  estimatedTimeSeconds: number;
}

export interface ServiceStatus {
  status: 'running' | 'stopped' | 'error';
  version: string;
  uptimeSeconds: number;
  lastScan: string | null;
  nextScan: string | null;
  scanProgress: ScanProgress | null;
  totalDetections: number;
  clientId: string;
}

export interface Detection {
  id: string;
  filePath: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  detectionType: string;
  matchedTextHash: string;
  redactedPreview: string;
  confidence: number;
  severity: 'low' | 'medium' | 'high' | 'critical';
  position: { start: number; end: number } | null;
  detectedAt: string;
  isResolved: boolean;
  scanSource?: 'filesystem' | 'clipboard' | 'usb';
  usbDeviceId?: string;
}

export interface ClipboardDetection {
  id: string;
  contentHash: string;
  detectionType: string;
  redactedPreview: string;
  confidence: number;
  severity: 'low' | 'medium' | 'high' | 'critical';
  detectedAt: string;
  sourceApp: string;
  isResolved: boolean;
}

export interface ClipboardStatus {
  enabled: boolean;
  isMonitoring: boolean;
  totalDetections: number;
  lastDetection: string | null;
  lastChecked: string | null;
  checkIntervalMs: number;
}

export interface USBDevice {
  id: string;
  deviceSerial: string;
  deviceVendor: string;
  deviceName: string;
  driveLetter: string;
  firstSeen: string;
  lastSeen: string;
  isWhitelisted: boolean;
  isBlacklisted: boolean;
}

export interface USBStatus {
  enabled: boolean;
  isMonitoring: boolean;
  connectedDevices: number;
  totalDevicesSeen: number;
  totalScans: number;
  lastScan: string | null;
}

export interface ClipboardConfig {
  enabled: boolean;
  check_interval_ms: number;
  min_text_length: number;
  ignore_duplicates: boolean;
  retention_hours: number;
  alert_on_detection: boolean;
}

export interface USBConfig {
  enabled: boolean;
  auto_scan_on_insert: boolean;
  scan_hidden_files: boolean;
  max_scan_size_gb: number;
  block_on_detection: boolean;
  whitelist_devices: string[];
  blacklist_devices: string[];
  scan_timeout_minutes: number;
}

export interface Config {
  scan: {
    directories: string[];
    file_types: string[];
    interval_hours: number;
    max_file_size_mb: number;
    worker_count: number;
  };
  clipboard: ClipboardConfig;
  usb: USBConfig;
  servers: {
    analyzer_url: string;
    dashboard_url: string;
  };
  api: {
    port: number;
  };
}

// API functions
export const serviceApi = {
  // Status and health
  getStatus: () => api.get<ServiceStatus>('/api/status'),
  healthCheck: () => api.get('/health'),

  // Detections
  getDetections: (params?: { limit?: number; offset?: number }) =>
    api.get<{ detections: Detection[]; total: number }>('/api/detections', { params }),

  // Config
  getConfig: () => api.get<Config>('/api/config'),
  updateConfig: (config: Partial<Config>) =>
    api.put<Config>('/api/config', config),

  // Scanning
  startScan: (type: 'full' | 'incremental' | 'manual' = 'manual') =>
    api.post('/api/scan/start', null, { params: { type } }),
  stopScan: () => api.post('/api/scan/stop'),

  // Clipboard
  getClipboardDetections: (params?: { limit?: number; offset?: number }) =>
    api.get<{ detections: ClipboardDetection[]; total: number }>('/api/clipboard/detections', { params }),
  getClipboardStatus: () => api.get<ClipboardStatus>('/api/clipboard/status'),
  clearClipboardDetections: () => api.post('/api/clipboard/clear'),
  updateClipboardConfig: (config: ClipboardConfig) =>
    api.put('/api/clipboard/config', config),

  // USB
  getUSBDevices: () =>
    api.get<{ devices: USBDevice[]; total: number }>('/api/usb/devices'),
  getUSBDevice: (id: string) => api.get<USBDevice>(`/api/usb/devices/${id}`),
  whitelistUSBDevice: (id: string) =>
    api.post(`/api/usb/devices/${id}/whitelist`),
  blacklistUSBDevice: (id: string) =>
    api.post(`/api/usb/devices/${id}/blacklist`),
  removeUSBDeviceWhitelist: (id: string) =>
    api.delete(`/api/usb/devices/${id}/whitelist`),
  removeUSBDeviceBlacklist: (id: string) =>
    api.delete(`/api/usb/devices/${id}/blacklist`),
  getUSBScanSessions: (params?: { deviceId?: string; limit?: number; offset?: number }) =>
    api.get('/api/usb/sessions', { params }),
  triggerUSBScan: (deviceId: string) =>
    api.post(`/api/usb/scan/${deviceId}`),
  getUSBStatus: () => api.get<USBStatus>('/api/usb/status'),
  updateUSBConfig: (config: USBConfig) =>
    api.put('/api/usb/config', config),
};

export default api;

