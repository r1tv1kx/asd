# Start Services Script for Confidential Data Scanner
# This script starts all manual services (non-Docker)

param(
    [switch]$SkipDockerCheck,
    [switch]$StartDesktopUI,
    [switch]$WaitForServices
)

$ErrorActionPreference = "Continue"
$script:ServiceProcess = $null
$script:DesktopUIProcess = $null

# Colors for output
function Write-ColorOutput {
    param(
        [string]$Message,
        [string]$Color = "White"
    )
    Write-Host $Message -ForegroundColor $Color
}

function Write-Success { param([string]$msg) Write-ColorOutput "✓ $msg" "Green" }
function Write-Error { param([string]$msg) Write-ColorOutput "✗ $msg" "Red" }
function Write-Info { param([string]$msg) Write-ColorOutput "ℹ $msg" "Cyan" }
function Write-Warning { param([string]$msg) Write-ColorOutput "⚠ $msg" "Yellow" }

Write-ColorOutput "`n========================================" "Cyan"
Write-ColorOutput "  Confidential Data Scanner" "Cyan"
Write-ColorOutput "  Service Startup Script" "Cyan"
Write-ColorOutput "========================================`n" "Cyan"

# Check Docker services
if (-not $SkipDockerCheck) {
    Write-Info "Checking Docker services..."
    
    $dockerServices = @(
        @{Name="scanner-postgres"; Port=5432},
        @{Name="scanner-analyzer"; Port=8000},
        @{Name="scanner-dashboard-api"; Port=3001},
        @{Name="scanner-dashboard-ui"; Port=3000}
    )
    
    $allRunning = $true
    foreach ($service in $dockerServices) {
        try {
            $response = Invoke-WebRequest -Uri "http://localhost:$($service.Port)/health" -UseBasicParsing -TimeoutSec 2 -ErrorAction SilentlyContinue
            if ($response.StatusCode -eq 200) {
                Write-Success "$($service.Name) is running on port $($service.Port)"
            }
        } catch {
            Write-Warning "$($service.Name) may not be running on port $($service.Port)"
            Write-Info "  Start with: docker-compose up -d"
            $allRunning = $false
        }
    }
    
    if (-not $allRunning) {
        Write-Warning "Some Docker services are not running. Start them with: docker-compose up -d"
        $response = Read-Host "Continue anyway? (y/n)"
        if ($response -ne "y" -and $response -ne "Y") {
            Write-Info "Exiting..."
            exit 1
        }
    }
} else {
    Write-Info "Skipping Docker service checks..."
}

# Get script directory
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$windowsServiceDir = Join-Path $scriptDir "windows-service"
$desktopUIDir = Join-Path $scriptDir "desktop-ui"
$serviceExe = Join-Path $windowsServiceDir "scanner-service.exe"

# Check if Windows service executable exists
if (-not (Test-Path $serviceExe)) {
    Write-Error "Windows service executable not found: $serviceExe"
    Write-Info "Building service..."
    
    Push-Location $windowsServiceDir
    try {
        $buildOutput = & go build -o scanner-service.exe ./cmd/service 2>&1
        if ($LASTEXITCODE -ne 0) {
            Write-Error "Failed to build Windows service:"
            Write-Host $buildOutput
            exit 1
        }
        Write-Success "Service built successfully"
    } catch {
        Write-Error "Build error: $_"
        exit 1
    } finally {
        Pop-Location
    }
}

# Check if service is already running
Write-Info "Checking if Windows service is already running..."
try {
    $existingProcess = Get-Process | Where-Object { $_.Path -like "*scanner-service.exe" }
    if ($existingProcess) {
        Write-Warning "Windows service is already running (PID: $($existingProcess.Id))"
        $response = Read-Host "Kill existing process and restart? (y/n)"
        if ($response -eq "y" -or $response -eq "Y") {
            Stop-Process -Id $existingProcess.Id -Force -ErrorAction SilentlyContinue
            Start-Sleep -Seconds 2
            Write-Success "Stopped existing service"
        } else {
            Write-Info "Using existing service instance"
            $script:ServiceProcess = $existingProcess
        }
    }
} catch {
    # No existing process
}

# Start Windows service
if (-not $script:ServiceProcess) {
    Write-Info "Starting Windows service..."
    Push-Location $windowsServiceDir
    
    try {
        $script:ServiceProcess = Start-Process -FilePath $serviceExe -ArgumentList "-interactive" -WindowStyle Minimized -PassThru -ErrorAction Stop
        Write-Success "Windows service started (PID: $($script:ServiceProcess.Id))"
    } catch {
        Write-Error "Failed to start Windows service: $_"
        Pop-Location
        exit 1
    }
    
    Pop-Location
    
    # Wait for service to start
    Write-Info "Waiting for service to initialize..."
    $maxAttempts = 30
    $attempt = 0
    $serviceReady = $false
    
    while ($attempt -lt $maxAttempts -and -not $serviceReady) {
        Start-Sleep -Seconds 1
        $attempt++
        try {
            $response = Invoke-WebRequest -Uri "http://localhost:8080/health" -UseBasicParsing -TimeoutSec 1 -ErrorAction SilentlyContinue
            if ($response.StatusCode -eq 200) {
                $serviceReady = $true
                Write-Success "Service is ready!"
            }
        } catch {
            Write-Host "." -NoNewline
        }
    }
    
    if (-not $serviceReady) {
        Write-Warning "Service may not be fully ready yet. Check manually."
    } else {
        Write-Host ""
    }
}

# Verify service endpoints
Write-Info "Verifying service endpoints..."
$endpoints = @(
    @{Path="/health"; Name="Health"},
    @{Path="/api/status"; Name="Status"},
    @{Path="/api/clipboard/status"; Name="Clipboard Status"},
    @{Path="/api/usb/status"; Name="USB Status"}
)

foreach ($endpoint in $endpoints) {
    try {
        $response = Invoke-WebRequest -Uri "http://localhost:8080$($endpoint.Path)" -UseBasicParsing -TimeoutSec 2 -ErrorAction SilentlyContinue
        if ($response.StatusCode -eq 200) {
            Write-Success "$($endpoint.Name) endpoint is responding"
        }
    } catch {
        Write-Warning "$($endpoint.Name) endpoint not responding yet"
    }
}

# Start Desktop UI if requested
if ($StartDesktopUI) {
    Write-Info "Starting Desktop UI..."
    
    if (-not (Test-Path $desktopUIDir)) {
        Write-Warning "Desktop UI directory not found: $desktopUIDir"
    } else {
        Push-Location $desktopUIDir
        
        # Check if node_modules exists
        if (-not (Test-Path "node_modules")) {
            Write-Info "Installing Desktop UI dependencies..."
            & npm install
            if ($LASTEXITCODE -ne 0) {
                Write-Error "Failed to install dependencies"
                Pop-Location
            }
        }
        
        Write-Info "Starting Desktop UI (Electron app)..."
        try {
            $script:DesktopUIProcess = Start-Process -FilePath "npm" -ArgumentList "start" -WindowStyle Normal -PassThru -ErrorAction Stop
            Write-Success "Desktop UI started (PID: $($script:DesktopUIProcess.Id))"
        } catch {
            Write-Error "Failed to start Desktop UI: $_"
        }
        
        Pop-Location
    }
}

# Summary
Write-ColorOutput "`n========================================" "Cyan"
Write-ColorOutput "  Startup Summary" "Cyan"
Write-ColorOutput "========================================`n" "Cyan"

Write-Info "Services Status:"
Write-Host "  Windows Service: " -NoNewline
if ($script:ServiceProcess) {
    Write-Success "Running (PID: $($script:ServiceProcess.Id))"
} else {
    Write-Error "Not running"
}

Write-Host "  Desktop UI: " -NoNewline
if ($script:DesktopUIProcess) {
    Write-Success "Running (PID: $($script:DesktopUIProcess.Id))"
} else {
    Write-Info "Not started (use -StartDesktopUI to start)"
}

Write-ColorOutput "`nService URLs:" "Cyan"
Write-Host "  Windows Service API: http://localhost:8080"
Write-Host "  Dashboard UI:        http://localhost:3000"
Write-Host "  Dashboard API:       http://localhost:3001"
Write-Host "  Analyzer Server:     http://localhost:8000"

Write-ColorOutput "`nTo stop services:" "Yellow"
Write-Host "  Windows Service: Stop-Process -Id $($script:ServiceProcess.Id)"
if ($script:DesktopUIProcess) {
    Write-Host "  Desktop UI:      Stop-Process -Id $($script:DesktopUIProcess.Id)"
}

Write-ColorOutput "`n========================================`n" "Cyan"

# Save process IDs to file for easy stopping
$pidFile = Join-Path $scriptDir ".service-pids.txt"
@{
    WindowsService = if ($script:ServiceProcess) { $script:ServiceProcess.Id } else { $null }
    DesktopUI = if ($script:DesktopUIProcess) { $script:DesktopUIProcess.Id } else { $null }
    Timestamp = Get-Date
} | ConvertTo-Json | Out-File $pidFile -Encoding UTF8

Write-Info "Process IDs saved to: $pidFile"

if ($WaitForServices) {
    Write-Info "`nPress Ctrl+C to stop all services..."
    try {
        Wait-Event
    } catch {
        Write-Info "`nShutting down services..."
        if ($script:ServiceProcess) {
            Stop-Process -Id $script:ServiceProcess.Id -Force -ErrorAction SilentlyContinue
        }
        if ($script:DesktopUIProcess) {
            Stop-Process -Id $script:DesktopUIProcess.Id -Force -ErrorAction SilentlyContinue
        }
    }
}

