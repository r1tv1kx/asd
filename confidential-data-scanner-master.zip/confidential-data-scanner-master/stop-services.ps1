# Stop Services Script for Confidential Data Scanner
# This script stops all manual services

$ErrorActionPreference = "Continue"

function Write-ColorOutput {
    param(
        [string]$Message,
        [string]$Color = "White"
    )
    Write-Host $Message -ForegroundColor $Color
}

function Write-Success { param([string]$msg) Write-ColorOutput "✓ $msg" "Green" }
function Write-Error { param([string]$msg) Write-ColorOutput "✗ $msg" "Red" }
function Write-Info { param([string]$msg) Write-ColorOutput "ℹ $msg" "Cyan" }

Write-ColorOutput "`n========================================" "Cyan"
Write-ColorOutput "  Stopping Services" "Cyan"
Write-ColorOutput "========================================`n" "Cyan"

# Get script directory
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$pidFile = Join-Path $scriptDir ".service-pids.txt"

# Try to read process IDs from file
if (Test-Path $pidFile) {
    Write-Info "Reading process IDs from file..."
    try {
        $pids = Get-Content $pidFile | ConvertFrom-Json
        if ($pids.WindowsService) {
            Write-Info "Stopping Windows Service (PID: $($pids.WindowsService))..."
            Stop-Process -Id $pids.WindowsService -Force -ErrorAction SilentlyContinue
            Write-Success "Windows Service stopped"
        }
        if ($pids.DesktopUI) {
            Write-Info "Stopping Desktop UI (PID: $($pids.DesktopUI))..."
            Stop-Process -Id $pids.DesktopUI -Force -ErrorAction SilentlyContinue
            Write-Success "Desktop UI stopped"
        }
        Remove-Item $pidFile -ErrorAction SilentlyContinue
    } catch {
        Write-Error "Failed to read PID file: $_"
    }
}

# Also try to find and stop processes by name
Write-Info "Searching for running processes..."

$scannerProcesses = Get-Process | Where-Object { 
    $_.ProcessName -like "*scanner*" -or 
    $_.Path -like "*scanner-service.exe*"
}

if ($scannerProcesses) {
    foreach ($proc in $scannerProcesses) {
        Write-Info "Stopping process: $($proc.ProcessName) (PID: $($proc.Id))"
        Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue
        Write-Success "Stopped $($proc.ProcessName)"
    }
} else {
    Write-Info "No scanner processes found"
}

# Check for Electron/Desktop UI processes
$electronProcesses = Get-Process | Where-Object { 
    $_.ProcessName -like "*electron*" -and
    $_.Path -like "*desktop-ui*"
}

if ($electronProcesses) {
    foreach ($proc in $electronProcesses) {
        Write-Info "Stopping Desktop UI: $($proc.ProcessName) (PID: $($proc.Id))"
        Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue
        Write-Success "Stopped Desktop UI"
    }
}

Write-ColorOutput "`n========================================" "Cyan"
Write-Success "All services stopped"
Write-ColorOutput "========================================`n" "Cyan"

