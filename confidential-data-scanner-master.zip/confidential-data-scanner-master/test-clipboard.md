# Clipboard Monitoring Test Guide

The clipboard monitoring feature is **ACTIVE** and running. Here's how to test it:

## How It Works

The clipboard monitor:
- Checks your clipboard every 500ms for new text content
- Analyzes text for PII (Personally Identifiable Information)
- Detects: Aadhar, PAN, SSN, Credit Cards, Passports, Bank Numbers, etc.
- Saves detections to local database and dashboard
- Alerts when sensitive data is detected

## Test Steps

### 1. Copy Sensitive Data to Clipboard

Copy one of these test strings to your clipboard (Ctrl+C):

**Test 1 - US SSN:**
```
My SSN is 123-45-6789
```

**Test 2 - Aadhar Number:**
```
My Aadhar number is 1234 5678 9012
```

**Test 3 - Credit Card:**
```
Card: 4532-1488-0343-6467
```

**Test 4 - PAN Card:**
```
PAN: ABCDE1234F
```

**Test 5 - US Passport:**
```
Passport: 123456789
```

### 2. Wait a Few Seconds

The monitor checks every 500ms, so detections should happen within 1-2 seconds.

### 3. Check for Detections

**Option A: Check via API**

Open PowerShell or Command Prompt and run:

```powershell
# Check clipboard status
curl http://localhost:8080/api/clipboard/status

# View recent clipboard detections
curl http://localhost:8080/api/clipboard/detections
```

**Option B: Check Dashboard UI**

1. Open browser to: http://localhost:3000
2. Navigate to the Dashboard or Detections page
3. Look for clipboard detections (Source: "clipboard")

**Option C: Check Windows Service Logs**

The service logs will show:
```
Clipboard detection: US_SSN (confidence: 0.95)
Clipboard detection: AADHAR (confidence: 0.90)
```

### 4. View Detection Details

Get all clipboard detections with details:

```powershell
curl "http://localhost:8080/api/clipboard/detections?limit=10"
```

This returns:
- Detection type (US_SSN, AADHAR, PAN, etc.)
- Confidence score
- Severity level (critical, high, medium, low)
- Redacted preview (sensitive parts masked)
- Timestamp
- Source application (what app you copied from)

## API Endpoints

### Get Clipboard Status
```bash
GET http://localhost:8080/api/clipboard/status
```

Returns:
```json
{
  "enabled": true,
  "isMonitoring": true,
  "totalDetections": 5,
  "lastChecked": "2025-12-31T18:38:21Z",
  "checkIntervalMs": 500
}
```

### Get Clipboard Detections
```bash
GET http://localhost:8080/api/clipboard/detections?limit=10&offset=0
```

Returns list of clipboard detections with:
- ID
- Detection type
- Redacted preview
- Confidence
- Severity
- Timestamp
- Source app

### Clear Clipboard Detections
```bash
POST http://localhost:8080/api/clipboard/clear
```

Clears all clipboard detection history.

## Configuration

Current clipboard settings (from config.yaml):
- **Enabled**: true
- **Check Interval**: 500ms
- **Min Text Length**: 10 characters
- **Ignore Duplicates**: true (won't re-detect same content)
- **Alert on Detection**: true

## Troubleshooting

**No detections showing up?**
1. Make sure you copied actual text (not images/files)
2. Wait 1-2 seconds after copying
3. Check the service logs for errors
4. Verify the text contains recognizable PII patterns

**False positives?**
The analyzer uses confidence scores. High confidence (>0.8) means it's very likely real PII.

**How to disable clipboard monitoring?**
Stop the Windows service or update config.yaml to set `clipboard.enabled: false`

## Test Results

After testing, you can view:
1. **Dashboard UI**: http://localhost:3000 - Visual dashboard with charts
2. **API Detections**: http://localhost:8080/api/clipboard/detections
3. **Service Logs**: Check the console where the service is running

## Privacy Note

All clipboard detections are:
- Stored locally in SQLite database
- Sent to local dashboard server (not internet)
- Redacted before storage (actual PII is masked)
- Can be cleared anytime via API
