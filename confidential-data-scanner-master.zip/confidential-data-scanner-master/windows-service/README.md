# Windows Scanner Service

A Go-based Windows service that scans files for confidential data (PII) including Aadhar, PAN, SSN, and more.

## Features

- Runs as a Windows service or in interactive mode
- Scans documents for PII (text files, PDF, DOCX)
- Communicates with analyzer server for detection
- Reports results to dashboard server
- Local SQLite database for offline storage
- REST API for local desktop UI

## Building

### Prerequisites

- Go 1.21+
- GCC (for SQLite - use TDM-GCC on Windows)

### Build

```bash
cd windows-service

# Download dependencies
go mod download

# Build for Windows
set CGO_ENABLED=1
go build -o scanner-service.exe ./cmd/service

# Build for current platform (development)
go build -o scanner-service ./cmd/service
```

## Running

### Interactive Mode (Development)

```bash
# Run with default config
./scanner-service -interactive

# Run with custom config
./scanner-service -interactive -config path/to/config.yaml

# Run with custom data directory
./scanner-service -interactive -data path/to/data
```

### Windows Service Mode

```powershell
# Install as Windows service (requires admin)
sc create ConfidentialDataScanner binPath= "C:\path\to\scanner-service.exe"

# Start the service
sc start ConfidentialDataScanner

# Stop the service
sc stop ConfidentialDataScanner

# Remove the service
sc delete ConfidentialDataScanner
```

## Configuration

Configuration is stored in `config.yaml`:

```yaml
scan:
  directories:
    - C:\Users\%USERNAME%\Documents
    - C:\Users\%USERNAME%\Desktop
    - C:\Users\%USERNAME%\Downloads
  file_types:
    - .txt
    - .pdf
    - .doc
    - .docx
  interval_hours: 24
  max_file_size_mb: 50
  worker_count: 4

servers:
  analyzer_url: http://localhost:8000
  dashboard_url: http://localhost:3001

api:
  port: 8080
```

## Local API Endpoints

The service exposes a local REST API on port 8080:

### Status
```
GET /api/status
```
Returns service status, scan progress, and statistics.

### Detections
```
GET /api/detections?limit=100&offset=0
```
Returns list of local detections.

### Configuration
```
GET /api/config
PUT /api/config
```
Get or update service configuration.

### Scan Control
```
POST /api/scan/start?type=manual
POST /api/scan/stop
```
Start or stop a scan.

### Health Check
```
GET /health
```
Returns service health status.

## Data Storage

Local data is stored in `~/.scanner/`:
- `scanner.db` - SQLite database with detections and scan history

## Architecture

```
windows-service/
├── cmd/
│   └── service/
│       └── main.go          # Entry point
├── internal/
│   ├── analyzer/
│   │   └── client.go        # Analyzer server client
│   ├── api/
│   │   └── server.go        # Local REST API
│   ├── config/
│   │   └── config.go        # Configuration management
│   ├── dashboard/
│   │   └── client.go        # Dashboard server client
│   ├── db/
│   │   └── sqlite.go        # Local database
│   ├── extractor/
│   │   └── extractor.go     # Text extraction
│   ├── models/
│   │   └── models.go        # Data models
│   ├── scanner/
│   │   └── scanner.go       # File scanning logic
│   └── service/
│       ├── service.go       # Windows service (Windows)
│       └── service_other.go # Cross-platform service
├── config.yaml              # Default configuration
├── go.mod                   # Go module
└── README.md
```

