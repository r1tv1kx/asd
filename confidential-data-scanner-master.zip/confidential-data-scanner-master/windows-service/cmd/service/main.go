package main

import (
	"context"
	"flag"
	"log"
	"os"
	"os/signal"
	"path/filepath"
	"syscall"

	"github.com/scanner/windows-service/internal/config"
	"github.com/scanner/windows-service/internal/service"
)

func main() {
	// Parse command line flags
	configPath := flag.String("config", "config.yaml", "Path to configuration file")
	dataDir := flag.String("data", "", "Path to data directory")
	interactive := flag.Bool("interactive", false, "Run in interactive mode (not as Windows service)")
	debug := flag.Bool("debug", false, "Run in debug mode")
	flag.Parse()

	// Set default data directory
	if *dataDir == "" {
		homeDir, err := os.UserHomeDir()
		if err != nil {
			log.Fatalf("Failed to get home directory: %v", err)
		}
		*dataDir = filepath.Join(homeDir, ".scanner")
	}

	// Load configuration
	cfg, err := config.Load(*configPath)
	if err != nil {
		log.Printf("Warning: Could not load config from %s: %v", *configPath, err)
		cfg = config.DefaultConfig()
	}

	// Create service
	svc, err := service.New(cfg, *dataDir)
	if err != nil {
		log.Fatalf("Failed to create service: %v", err)
	}

	// Run service
	if *interactive || *debug {
		// Interactive mode
		ctx, cancel := context.WithCancel(context.Background())

		// Handle signals
		sigChan := make(chan os.Signal, 1)
		signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)
		go func() {
			<-sigChan
			log.Println("Received shutdown signal")
			cancel()
		}()

		if err := svc.RunInteractive(ctx); err != nil {
			log.Fatalf("Service error: %v", err)
		}
	} else {
		// Windows service mode
		if err := svc.Run(*debug); err != nil {
			log.Fatalf("Service error: %v", err)
		}
	}
}

