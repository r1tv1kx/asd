package analyzer

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"time"

	"github.com/scanner/windows-service/internal/models"
)

// Client communicates with the analyzer server
type Client struct {
	baseURL    string
	httpClient *http.Client
}

// NewClient creates a new analyzer client
func NewClient(baseURL string) *Client {
	return &Client{
		baseURL: baseURL,
		httpClient: &http.Client{
			Timeout: 60 * time.Second,
		},
	}
}

// Analyze sends text to the analyzer server and returns detections
func (c *Client) Analyze(text, filePath string) (*models.AnalyzeResponse, error) {
	req := models.AnalyzeRequest{
		Text:     text,
		FilePath: filePath,
		Language: "en",
	}

	body, err := json.Marshal(req)
	if err != nil {
		return nil, err
	}

	resp, err := c.httpClient.Post(
		c.baseURL+"/api/analyze",
		"application/json",
		bytes.NewReader(body),
	)
	if err != nil {
		return nil, fmt.Errorf("failed to connect to analyzer: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("analyzer returned status %d", resp.StatusCode)
	}

	var result models.AnalyzeResponse
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, err
	}

	return &result, nil
}

// HealthCheck checks if the analyzer server is available
func (c *Client) HealthCheck() error {
	resp, err := c.httpClient.Get(c.baseURL + "/health")
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("health check failed with status %d", resp.StatusCode)
	}

	return nil
}

// ConvertToDetections converts analyzer detections to our model
func ConvertToDetections(filePath string, analyzerResp *models.AnalyzeResponse) []models.Detection {
	var detections []models.Detection

	fileInfo, _ := os.Stat(filePath)
	var fileSize int64
	if fileInfo != nil {
		fileSize = fileInfo.Size()
	}

	for _, d := range analyzerResp.Detections {
		// Hash the matched text for privacy
		hash := sha256.Sum256([]byte(d.Text))
		hashStr := hex.EncodeToString(hash[:])[:16]

		detection := models.Detection{
			FilePath:        filePath,
			FileName:        filepath.Base(filePath),
			FileType:        filepath.Ext(filePath),
			FileSize:        fileSize,
			DetectionType:   d.EntityType,
			MatchedTextHash: hashStr,
			RedactedPreview: d.RedactedText,
			Confidence:      d.Confidence,
			Severity:        determineSeverity(d.EntityType),
			Position: &models.Position{
				Start: d.Start,
				End:   d.End,
			},
			DetectedAt: time.Now(),
			IsResolved: false,
		}
		detections = append(detections, detection)
	}

	return detections
}

// determineSeverity maps detection types to severity levels
func determineSeverity(detectionType string) string {
	critical := map[string]bool{
		"US_SSN":      true,
		"CREDIT_CARD": true,
	}
	high := map[string]bool{
		"AADHAR":         true,
		"PAN":            true,
		"US_BANK_NUMBER": true,
		"IBAN_CODE":      true,
	}
	medium := map[string]bool{
		"INDIAN_PASSPORT": true,
		"US_PASSPORT":     true,
		"DRIVING_LICENSE": true,
		"VOTER_ID":        true,
	}

	if critical[detectionType] {
		return "critical"
	}
	if high[detectionType] {
		return "high"
	}
	if medium[detectionType] {
		return "medium"
	}
	return "low"
}

