package api

import (
	"context"
	"fmt"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/scanner/windows-service/internal/clipboard"
	"github.com/scanner/windows-service/internal/config"
	"github.com/scanner/windows-service/internal/db"
	"github.com/scanner/windows-service/internal/models"
	"github.com/scanner/windows-service/internal/scanner"
)

// Server provides the local REST API
type Server struct {
	config           *config.Config
	db               *db.Database
	scanner          *scanner.Scanner
	clipboardMonitor *clipboard.Monitor
	usbMonitor       interface {
		GetStatus() *models.USBStatus
		TriggerScan(ctx context.Context, deviceID string) error
		GetConnectedDevices() []*models.USBDevice
	}
	clientID         string
	startTime        time.Time
	httpServer       *http.Server
}

// NewServer creates a new API server
func NewServer(cfg *config.Config, database *db.Database, scn *scanner.Scanner, clientID string) *Server {
	return &Server{
		config:    cfg,
		db:        database,
		scanner:   scn,
		clientID:  clientID,
		startTime: time.Now(),
	}
}

// SetClipboardMonitor sets the clipboard monitor reference
func (s *Server) SetClipboardMonitor(monitor *clipboard.Monitor) {
	s.clipboardMonitor = monitor
}

// SetUSBMonitor sets the USB monitor reference
func (s *Server) SetUSBMonitor(monitor interface {
	GetStatus() *models.USBStatus
	TriggerScan(ctx context.Context, deviceID string) error
	GetConnectedDevices() []*models.USBDevice
}) {
	s.usbMonitor = monitor
}

// Start starts the API server
func (s *Server) Start() error {
	gin.SetMode(gin.ReleaseMode)
	router := gin.New()
	router.Use(gin.Recovery())
	router.Use(corsMiddleware())

	// Core Routes
	router.GET("/api/status", s.getStatus)
	router.GET("/api/detections", s.getDetections)
	router.GET("/api/config", s.getConfig)
	router.PUT("/api/config", s.updateConfig)
	router.POST("/api/scan/start", s.startScan)
	router.POST("/api/scan/stop", s.stopScan)
	router.DELETE("/api/data/clear", s.clearData)
	router.GET("/health", s.healthCheck)

	// Clipboard Routes
	router.GET("/api/clipboard/detections", s.getClipboardDetections)
	router.GET("/api/clipboard/status", s.getClipboardStatus)
	router.POST("/api/clipboard/clear", s.clearClipboardDetections)
	router.PUT("/api/clipboard/config", s.updateClipboardConfig)

	// USB Routes
	router.GET("/api/usb/devices", s.getUSBDevices)
	router.GET("/api/usb/devices/:id", s.getUSBDevice)
	router.POST("/api/usb/devices/:id/whitelist", s.whitelistUSBDevice)
	router.POST("/api/usb/devices/:id/blacklist", s.blacklistUSBDevice)
	router.DELETE("/api/usb/devices/:id/whitelist", s.removeUSBDeviceWhitelist)
	router.DELETE("/api/usb/devices/:id/blacklist", s.removeUSBDeviceBlacklist)
	router.GET("/api/usb/sessions", s.getUSBScanSessions)
	router.POST("/api/usb/scan/:deviceId", s.triggerUSBScan)
	router.GET("/api/usb/status", s.getUSBStatus)
	router.PUT("/api/usb/config", s.updateUSBConfig)

	addr := fmt.Sprintf(":%d", s.config.API.Port)
	s.httpServer = &http.Server{
		Addr:    addr,
		Handler: router,
	}

	return s.httpServer.ListenAndServe()
}

// Stop stops the API server
func (s *Server) Stop(ctx context.Context) error {
	if s.httpServer != nil {
		return s.httpServer.Shutdown(ctx)
	}
	return nil
}

// corsMiddleware adds CORS headers
func corsMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		c.Writer.Header().Set("Access-Control-Allow-Origin", "*")
		c.Writer.Header().Set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
		c.Writer.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")

		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(204)
			return
		}

		c.Next()
	}
}

// getStatus returns the service status
func (s *Server) getStatus(c *gin.Context) {
	detectionCount, _ := s.db.GetDetectionCount()
	lastSession, _ := s.db.GetLastScanSession()

	status := models.ServiceStatus{
		Status:          "running",
		Version:         "1.0.0",
		Uptime:          int64(time.Since(s.startTime).Seconds()),
		TotalDetections: detectionCount,
		ClientID:        s.clientID,
	}

	if lastSession != nil && lastSession.CompletedAt != nil {
		status.LastScan = lastSession.CompletedAt
	}

	// Calculate next scan time
	if lastSession != nil && lastSession.CompletedAt != nil {
		nextScan := lastSession.CompletedAt.Add(time.Duration(s.config.Scan.IntervalHours) * time.Hour)
		status.NextScan = &nextScan
	}

	// Add scan progress if scanning
	if s.scanner.IsScanning() {
		status.ScanProgress = s.scanner.GetProgress()
	}

	c.JSON(http.StatusOK, status)
}

// getDetections returns the list of detections
func (s *Server) getDetections(c *gin.Context) {
	limit := 100
	offset := 0

	if l := c.Query("limit"); l != "" {
		fmt.Sscanf(l, "%d", &limit)
	}
	if o := c.Query("offset"); o != "" {
		fmt.Sscanf(o, "%d", &offset)
	}

	detections, err := s.db.GetDetections(limit, offset, false)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	total, _ := s.db.GetDetectionCount()

	c.JSON(http.StatusOK, gin.H{
		"detections": detections,
		"total":      total,
		"limit":      limit,
		"offset":     offset,
	})
}

// getConfig returns the current configuration
func (s *Server) getConfig(c *gin.Context) {
	c.JSON(http.StatusOK, s.config)
}

// updateConfig updates the configuration
func (s *Server) updateConfig(c *gin.Context) {
	var newConfig config.Config
	if err := c.ShouldBindJSON(&newConfig); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// Update only scan config for now
	s.config.Scan = newConfig.Scan

	// Save to file
	configPath := "config.yaml"
	if err := s.config.Save(configPath); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, s.config)
}

// startScan triggers a manual scan
func (s *Server) startScan(c *gin.Context) {
	if s.scanner.IsScanning() {
		c.JSON(http.StatusConflict, gin.H{"error": "Scan already in progress"})
		return
	}

	scanType := "manual"
	if t := c.Query("type"); t != "" {
		scanType = t
	}

	if err := s.scanner.StartScan(context.Background(), scanType); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Scan started", "type": scanType})
}

// stopScan stops the current scan
func (s *Server) stopScan(c *gin.Context) {
	if !s.scanner.IsScanning() {
		c.JSON(http.StatusConflict, gin.H{"error": "No scan in progress"})
		return
	}

	s.scanner.StopScan()
	c.JSON(http.StatusOK, gin.H{"message": "Scan stop requested"})
}

// clearData clears all local scan data
func (s *Server) clearData(c *gin.Context) {
	if s.scanner.IsScanning() {
		c.JSON(http.StatusConflict, gin.H{"error": "Cannot clear data while scan is in progress"})
		return
	}

	if err := s.db.ClearAllData(); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "All local data cleared successfully"})
}

// healthCheck returns health status
func (s *Server) healthCheck(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{
		"status":  "healthy",
		"version": "1.0.0",
	})
}

// ============================================================================
// Clipboard Endpoints
// ============================================================================

// getClipboardDetections returns clipboard detection history
func (s *Server) getClipboardDetections(c *gin.Context) {
	limit := 100
	offset := 0

	if l := c.Query("limit"); l != "" {
		fmt.Sscanf(l, "%d", &limit)
	}
	if o := c.Query("offset"); o != "" {
		fmt.Sscanf(o, "%d", &offset)
	}

	detections, err := s.db.GetClipboardDetections(limit, offset)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	total, _ := s.db.GetClipboardDetectionCount()

	c.JSON(http.StatusOK, gin.H{
		"detections": detections,
		"total":      total,
		"limit":      limit,
		"offset":     offset,
	})
}

// getClipboardStatus returns the clipboard monitor status
func (s *Server) getClipboardStatus(c *gin.Context) {
	if s.clipboardMonitor == nil {
		c.JSON(http.StatusOK, gin.H{
			"enabled":      s.config.Clipboard.Enabled,
			"isMonitoring": false,
			"message":      "Clipboard monitor not initialized",
		})
		return
	}

	status := s.clipboardMonitor.GetStatus()
	c.JSON(http.StatusOK, status)
}

// clearClipboardDetections clears all clipboard detection history
func (s *Server) clearClipboardDetections(c *gin.Context) {
	if err := s.db.ClearClipboardDetections(); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Clipboard detection history cleared"})
}

// updateClipboardConfig updates clipboard monitoring configuration
func (s *Server) updateClipboardConfig(c *gin.Context) {
	var clipboardConfig config.ClipboardConfig
	if err := c.ShouldBindJSON(&clipboardConfig); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	s.config.Clipboard = clipboardConfig

	// Save to file
	configPath := "config.yaml"
	if err := s.config.Save(configPath); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"message":   "Clipboard configuration updated",
		"clipboard": s.config.Clipboard,
	})
}

// ============================================================================
// USB Endpoints
// ============================================================================

// getUSBDevices returns all known USB devices
func (s *Server) getUSBDevices(c *gin.Context) {
	devices, err := s.db.GetUSBDevices()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"devices": devices,
		"total":   len(devices),
	})
}

// getUSBDevice returns a specific USB device by ID
func (s *Server) getUSBDevice(c *gin.Context) {
	id := c.Param("id")

	device, err := s.db.GetUSBDeviceByID(id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	if device == nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Device not found"})
		return
	}

	c.JSON(http.StatusOK, device)
}

// whitelistUSBDevice adds a device to the whitelist
func (s *Server) whitelistUSBDevice(c *gin.Context) {
	id := c.Param("id")

	if err := s.db.UpdateUSBDeviceWhitelist(id, true); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Device added to whitelist"})
}

// blacklistUSBDevice adds a device to the blacklist
func (s *Server) blacklistUSBDevice(c *gin.Context) {
	id := c.Param("id")

	if err := s.db.UpdateUSBDeviceBlacklist(id, true); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Device added to blacklist"})
}

// removeUSBDeviceWhitelist removes a device from the whitelist
func (s *Server) removeUSBDeviceWhitelist(c *gin.Context) {
	id := c.Param("id")

	if err := s.db.UpdateUSBDeviceWhitelist(id, false); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Device removed from whitelist"})
}

// removeUSBDeviceBlacklist removes a device from the blacklist
func (s *Server) removeUSBDeviceBlacklist(c *gin.Context) {
	id := c.Param("id")

	if err := s.db.UpdateUSBDeviceBlacklist(id, false); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Device removed from blacklist"})
}

// getUSBScanSessions returns USB scan session history
func (s *Server) getUSBScanSessions(c *gin.Context) {
	limit := 50
	offset := 0
	deviceID := c.Query("deviceId")

	if l := c.Query("limit"); l != "" {
		fmt.Sscanf(l, "%d", &limit)
	}
	if o := c.Query("offset"); o != "" {
		fmt.Sscanf(o, "%d", &offset)
	}

	sessions, err := s.db.GetUSBScanSessions(deviceID, limit, offset)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"sessions": sessions,
		"total":    len(sessions),
		"limit":    limit,
		"offset":   offset,
	})
}

// triggerUSBScan triggers a manual scan of a USB device
func (s *Server) triggerUSBScan(c *gin.Context) {
	deviceID := c.Param("deviceId")

	device, err := s.db.GetUSBDeviceByID(deviceID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	if device == nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Device not found"})
		return
	}

	if device.DriveLetter == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Device is not currently connected"})
		return
	}

	if s.usbMonitor == nil {
		c.JSON(http.StatusServiceUnavailable, gin.H{"error": "USB monitor not initialized"})
		return
	}

	if err := s.usbMonitor.TriggerScan(c.Request.Context(), deviceID); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"message":     "USB scan triggered",
		"deviceId":    deviceID,
		"driveLetter": device.DriveLetter,
	})
}

// getUSBStatus returns the USB monitor status
func (s *Server) getUSBStatus(c *gin.Context) {
	if s.usbMonitor == nil {
	devices, _ := s.db.GetUSBDevices()
	status := models.USBStatus{
		Enabled:          s.config.USB.Enabled,
			IsMonitoring:     false,
		TotalDevicesSeen: len(devices),
	}
	// Count connected devices (those with drive letters)
	for _, d := range devices {
		if d.DriveLetter != "" {
			status.ConnectedDevices++
		}
		}
		c.JSON(http.StatusOK, status)
		return
	}

	status := s.usbMonitor.GetStatus()
	c.JSON(http.StatusOK, status)
}

// updateUSBConfig updates USB monitoring configuration
func (s *Server) updateUSBConfig(c *gin.Context) {
	var usbConfig config.USBConfig
	if err := c.ShouldBindJSON(&usbConfig); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	s.config.USB = usbConfig

	// Save to file
	configPath := "config.yaml"
	if err := s.config.Save(configPath); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"message": "USB configuration updated",
		"usb":     s.config.USB,
	})
}

