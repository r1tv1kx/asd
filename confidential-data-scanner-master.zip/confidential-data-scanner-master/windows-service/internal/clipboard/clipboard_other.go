//go:build !windows

package clipboard

import "errors"

// readClipboardText is a stub for non-Windows platforms
func readClipboardText() (string, error) {
	return "", errors.New("clipboard monitoring is only supported on Windows")
}

// getActiveWindowTitle is a stub for non-Windows platforms
func getActiveWindowTitle() string {
	return ""
}

