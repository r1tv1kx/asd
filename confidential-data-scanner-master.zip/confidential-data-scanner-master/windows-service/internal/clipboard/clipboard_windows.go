//go:build windows

package clipboard

import (
	"errors"
	"syscall"
	"unsafe"
)

var (
	user32           = syscall.NewLazyDLL("user32.dll")
	kernel32         = syscall.NewLazyDLL("kernel32.dll")
	openClipboard    = user32.NewProc("OpenClipboard")
	closeClipboard   = user32.NewProc("CloseClipboard")
	getClipboardData = user32.NewProc("GetClipboardData")
	globalLock       = kernel32.NewProc("GlobalLock")
	globalUnlock     = kernel32.NewProc("GlobalUnlock")
	getForegroundWnd = user32.NewProc("GetForegroundWindow")
	getWindowTextW   = user32.NewProc("GetWindowTextW")
)

const (
	cfUnicodeText = 13
)

// readClipboardText reads text content from the Windows clipboard
func readClipboardText() (string, error) {
	// Open clipboard
	ret, _, err := openClipboard.Call(0)
	if ret == 0 {
		return "", errors.New("failed to open clipboard: " + err.Error())
	}
	defer closeClipboard.Call()

	// Get clipboard data handle
	handle, _, err := getClipboardData.Call(cfUnicodeText)
	if handle == 0 {
		return "", errors.New("no text data in clipboard")
	}

	// Lock global memory
	ptr, _, err := globalLock.Call(handle)
	if ptr == 0 {
		return "", errors.New("failed to lock clipboard data: " + err.Error())
	}
	defer globalUnlock.Call(handle)

	// Convert wide string to Go string
	text := wideCharToString(ptr)
	return text, nil
}

// wideCharToString converts a null-terminated wide character string to Go string
func wideCharToString(ptr uintptr) string {
	if ptr == 0 {
		return ""
	}

	// Find string length
	length := 0
	for p := ptr; ; p += 2 {
		if *(*uint16)(unsafe.Pointer(p)) == 0 {
			break
		}
		length++
	}

	if length == 0 {
		return ""
	}

	// Create slice from pointer
	slice := make([]uint16, length)
	for i := 0; i < length; i++ {
		slice[i] = *(*uint16)(unsafe.Pointer(ptr + uintptr(i*2)))
	}

	return syscall.UTF16ToString(slice)
}

// getActiveWindowTitle gets the title of the currently active window
func getActiveWindowTitle() string {
	hwnd, _, _ := getForegroundWnd.Call()
	if hwnd == 0 {
		return ""
	}

	// Get window title
	buf := make([]uint16, 256)
	ret, _, _ := getWindowTextW.Call(hwnd, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
	if ret == 0 {
		return ""
	}

	return syscall.UTF16ToString(buf)
}

