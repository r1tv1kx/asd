package clipboard

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"log"
	"strings"
	"sync"
	"time"

	"github.com/google/uuid"
	"github.com/scanner/windows-service/internal/analyzer"
	"github.com/scanner/windows-service/internal/config"
	"github.com/scanner/windows-service/internal/dashboard"
	"github.com/scanner/windows-service/internal/db"
	"github.com/scanner/windows-service/internal/models"
)

// Monitor handles clipboard monitoring for sensitive data
type Monitor struct {
	config          *config.Config
	db              *db.Database
	analyzerClient  *analyzer.Client
	dashboardClient *dashboard.Client

	mu              sync.RWMutex
	isMonitoring    bool
	lastContent     string
	lastContentHash string
	lastChecked     time.Time
	lastDetection   *time.Time
	totalDetections int
	cancelFunc      context.CancelFunc

	// Alert callback for real-time notifications
	alertCallback func(detection *models.ClipboardDetection)
}

// New creates a new clipboard monitor
func New(
	cfg *config.Config,
	database *db.Database,
	analyzerClient *analyzer.Client,
	dashboardClient *dashboard.Client,
) *Monitor {
	return &Monitor{
		config:          cfg,
		db:              database,
		analyzerClient:  analyzerClient,
		dashboardClient: dashboardClient,
	}
}

// SetAlertCallback sets a callback function for real-time detection alerts
func (m *Monitor) SetAlertCallback(callback func(detection *models.ClipboardDetection)) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.alertCallback = callback
}

// Start begins clipboard monitoring
func (m *Monitor) Start(ctx context.Context) error {
	m.mu.Lock()
	if m.isMonitoring {
		m.mu.Unlock()
		return nil
	}
	m.isMonitoring = true

	ctx, cancel := context.WithCancel(ctx)
	m.cancelFunc = cancel
	m.mu.Unlock()

	log.Println("Starting clipboard monitor...")

	// Load total detections count
	count, err := m.db.GetClipboardDetectionCount()
	if err == nil {
		m.mu.Lock()
		m.totalDetections = count
		m.mu.Unlock()
	}

	go m.monitorLoop(ctx)
	return nil
}

// Stop stops clipboard monitoring
func (m *Monitor) Stop() {
	m.mu.Lock()
	defer m.mu.Unlock()

	if m.cancelFunc != nil {
		m.cancelFunc()
		m.cancelFunc = nil
	}
	m.isMonitoring = false
	log.Println("Clipboard monitor stopped")
}

// IsMonitoring returns whether the monitor is active
func (m *Monitor) IsMonitoring() bool {
	m.mu.RLock()
	defer m.mu.RUnlock()
	return m.isMonitoring
}

// GetStatus returns the current clipboard monitor status
func (m *Monitor) GetStatus() *models.ClipboardStatus {
	m.mu.RLock()
	defer m.mu.RUnlock()

	status := &models.ClipboardStatus{
		Enabled:         m.config.Clipboard.Enabled,
		IsMonitoring:    m.isMonitoring,
		TotalDetections: m.totalDetections,
		CheckIntervalMs: m.config.Clipboard.CheckIntervalMs,
	}

	if !m.lastChecked.IsZero() {
		status.LastChecked = &m.lastChecked
	}
	if m.lastDetection != nil {
		status.LastDetection = m.lastDetection
	}

	return status
}

// monitorLoop is the main monitoring loop
func (m *Monitor) monitorLoop(ctx context.Context) {
	interval := time.Duration(m.config.Clipboard.CheckIntervalMs) * time.Millisecond
	if interval < 100*time.Millisecond {
		interval = 100 * time.Millisecond
	}

	ticker := time.NewTicker(interval)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			m.mu.Lock()
			m.isMonitoring = false
			m.mu.Unlock()
			return
		case <-ticker.C:
			m.checkClipboard()
		}
	}
}

// checkClipboard reads and analyzes clipboard content
func (m *Monitor) checkClipboard() {
	content, err := readClipboardText()
	if err != nil {
		// Clipboard read errors are common (e.g., clipboard locked), don't log them
		return
	}

	m.mu.Lock()
	m.lastChecked = time.Now()
	m.mu.Unlock()

	// Skip if content is too short
	if len(strings.TrimSpace(content)) < m.config.Clipboard.MinTextLength {
		return
	}

	// Calculate content hash for duplicate detection
	hash := hashContent(content)

	m.mu.RLock()
	lastHash := m.lastContentHash
	ignoreDuplicates := m.config.Clipboard.IgnoreDuplicates
	m.mu.RUnlock()

	// Skip if same content as last check
	if hash == lastHash {
		return
	}

	// Update last content
	m.mu.Lock()
	m.lastContent = content
	m.lastContentHash = hash
	m.mu.Unlock()

	// Check if we've already processed this content (if ignoring duplicates)
	if ignoreDuplicates {
		exists, err := m.db.HasClipboardContentHash(hash)
		if err == nil && exists {
			return
		}
	}

	// Analyze content for sensitive data
	m.analyzeContent(content, hash)
}

// analyzeContent sends content to the analyzer and processes results
func (m *Monitor) analyzeContent(content, hash string) {
	resp, err := m.analyzerClient.Analyze(content, "clipboard")
	if err != nil {
		log.Printf("Clipboard analysis error: %v", err)
		return
	}

	if !resp.HasPII {
		return
	}

	// Process each detection
	for _, det := range resp.Detections {
		detection := &models.ClipboardDetection{
			ID:              uuid.New().String(),
			ContentHash:     hash,
			DetectionType:   det.EntityType,
			RedactedPreview: det.RedactedText,
			Confidence:      det.Confidence,
			Severity:        determineSeverity(det.EntityType, det.Confidence),
			DetectedAt:      time.Now(),
			SourceApp:       getActiveWindowTitle(),
			IsResolved:      false,
		}

		// Save to database
		if err := m.db.SaveClipboardDetection(detection); err != nil {
			log.Printf("Failed to save clipboard detection: %v", err)
			continue
		}

		// Update statistics
		m.mu.Lock()
		m.totalDetections++
		now := time.Now()
		m.lastDetection = &now
		alertCallback := m.alertCallback
		m.mu.Unlock()

		// Trigger alert callback if set
		if alertCallback != nil && m.config.Clipboard.AlertOnDetection {
			alertCallback(detection)
		}

		log.Printf("Clipboard detection: %s (confidence: %.2f)", det.EntityType, det.Confidence)

		// Submit to dashboard if connected
		m.submitToDashboard(detection)
	}
}

// submitToDashboard sends clipboard detection to the dashboard server
func (m *Monitor) submitToDashboard(detection *models.ClipboardDetection) {
	if m.dashboardClient == nil || m.dashboardClient.GetClientID() == "" {
		return
	}

	// Convert to standard detection format for dashboard
	det := models.Detection{
		ID:              detection.ID,
		FilePath:        "clipboard",
		FileName:        "clipboard",
		FileType:        "clipboard",
		DetectionType:   detection.DetectionType,
		MatchedTextHash: detection.ContentHash,
		RedactedPreview: detection.RedactedPreview,
		Confidence:      detection.Confidence,
		Severity:        detection.Severity,
		DetectedAt:      detection.DetectedAt,
		ScanSource:      "clipboard",
	}

	if err := m.dashboardClient.SubmitDetections("", []models.Detection{det}); err != nil {
		log.Printf("Failed to submit clipboard detection to dashboard: %v", err)
	}
}

// hashContent creates a SHA-256 hash of the content
func hashContent(content string) string {
	hash := sha256.Sum256([]byte(content))
	return hex.EncodeToString(hash[:])
}

// determineSeverity determines the severity level based on detection type
func determineSeverity(entityType string, confidence float64) string {
	// High severity for financial and government IDs
	highSeverityTypes := map[string]bool{
		"AADHAR":          true,
		"PAN":             true,
		"US_SSN":          true,
		"CREDIT_CARD":     true,
		"US_BANK_NUMBER":  true,
		"IBAN_CODE":       true,
		"US_PASSPORT":     true,
		"UK_NHS":          true,
	}

	if highSeverityTypes[entityType] {
		if confidence >= 0.9 {
			return "critical"
		}
		return "high"
	}

	if confidence >= 0.8 {
		return "medium"
	}
	return "low"
}

