package config

import (
	"os"
	"path/filepath"
	"strings"

	"gopkg.in/yaml.v3"
)

// Config holds all configuration for the scanner service
type Config struct {
	Scan      ScanConfig      `yaml:"scan" json:"scan"`
	Clipboard ClipboardConfig `yaml:"clipboard" json:"clipboard"`
	USB       USBConfig       `yaml:"usb" json:"usb"`
	Servers   ServersConfig   `yaml:"servers" json:"servers"`
	API       APIConfig       `yaml:"api" json:"api"`
}

// ScanConfig holds scanning configuration
type ScanConfig struct {
	Directories   []string `yaml:"directories" json:"directories"`
	FileTypes     []string `yaml:"file_types" json:"file_types"`
	IntervalHours int      `yaml:"interval_hours" json:"interval_hours"`
	MaxFileSize   int64    `yaml:"max_file_size_mb" json:"max_file_size_mb"`
	WorkerCount   int      `yaml:"worker_count" json:"worker_count"`
}

// ClipboardConfig holds clipboard monitoring configuration
type ClipboardConfig struct {
	Enabled          bool `yaml:"enabled" json:"enabled"`
	CheckIntervalMs  int  `yaml:"check_interval_ms" json:"check_interval_ms"`
	MinTextLength    int  `yaml:"min_text_length" json:"min_text_length"`
	IgnoreDuplicates bool `yaml:"ignore_duplicates" json:"ignore_duplicates"`
	RetentionHours   int  `yaml:"retention_hours" json:"retention_hours"`
	AlertOnDetection bool `yaml:"alert_on_detection" json:"alert_on_detection"`
}

// USBConfig holds USB monitoring configuration
type USBConfig struct {
	Enabled            bool     `yaml:"enabled" json:"enabled"`
	AutoScanOnInsert   bool     `yaml:"auto_scan_on_insert" json:"auto_scan_on_insert"`
	ScanHiddenFiles    bool     `yaml:"scan_hidden_files" json:"scan_hidden_files"`
	MaxScanSizeGB      int      `yaml:"max_scan_size_gb" json:"max_scan_size_gb"`
	BlockOnDetection   bool     `yaml:"block_on_detection" json:"block_on_detection"`
	WhitelistDevices   []string `yaml:"whitelist_devices" json:"whitelist_devices"`
	BlacklistDevices   []string `yaml:"blacklist_devices" json:"blacklist_devices"`
	ScanTimeoutMinutes int      `yaml:"scan_timeout_minutes" json:"scan_timeout_minutes"`
}

// ServersConfig holds server endpoints
type ServersConfig struct {
	AnalyzerURL  string `yaml:"analyzer_url" json:"analyzer_url"`
	DashboardURL string `yaml:"dashboard_url" json:"dashboard_url"`
}

// APIConfig holds local API configuration
type APIConfig struct {
	Port int `yaml:"port" json:"port"`
}

// DefaultConfig returns the default configuration
func DefaultConfig() *Config {
	homeDir, _ := os.UserHomeDir()

	return &Config{
		Scan: ScanConfig{
			Directories: []string{
				filepath.Join(homeDir, "Documents"),
				filepath.Join(homeDir, "Desktop"),
				filepath.Join(homeDir, "Downloads"),
			},
			FileTypes:     []string{".txt", ".pdf", ".doc", ".docx"},
			IntervalHours: 24,
			MaxFileSize:   50, // 50 MB
			WorkerCount:   4,
		},
		Clipboard: ClipboardConfig{
			Enabled:          true,
			CheckIntervalMs:  500,
			MinTextLength:    10,
			IgnoreDuplicates: true,
			RetentionHours:   24,
			AlertOnDetection: true,
		},
		USB: USBConfig{
			Enabled:            true,
			AutoScanOnInsert:   true,
			ScanHiddenFiles:    false,
			MaxScanSizeGB:      32,
			BlockOnDetection:   false,
			WhitelistDevices:   []string{},
			BlacklistDevices:   []string{},
			ScanTimeoutMinutes: 30,
		},
		Servers: ServersConfig{
			AnalyzerURL:  "http://localhost:8000",
			DashboardURL: "http://localhost:3001",
		},
		API: APIConfig{
			Port: 8080,
		},
	}
}

// Load loads configuration from a YAML file
func Load(path string) (*Config, error) {
	config := DefaultConfig()
	
	data, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			// Return default config if file doesn't exist
			return config, nil
		}
		return nil, err
	}
	
	if err := yaml.Unmarshal(data, config); err != nil {
		return nil, err
	}
	
	// Expand environment variables in directories
	for i, dir := range config.Scan.Directories {
		config.Scan.Directories[i] = expandEnvVars(dir)
	}
	
	return config, nil
}

// Save saves configuration to a YAML file
func (c *Config) Save(path string) error {
	data, err := yaml.Marshal(c)
	if err != nil {
		return err
	}
	
	dir := filepath.Dir(path)
	if err := os.MkdirAll(dir, 0755); err != nil {
		return err
	}
	
	return os.WriteFile(path, data, 0644)
}

// expandEnvVars expands environment variables in a string
func expandEnvVars(s string) string {
	// Handle Windows-style %VAR% and Unix-style $VAR
	result := os.ExpandEnv(s)
	
	// Also handle %USERNAME% style
	for _, env := range os.Environ() {
		parts := strings.SplitN(env, "=", 2)
		if len(parts) == 2 {
			placeholder := "%" + parts[0] + "%"
			result = strings.ReplaceAll(result, placeholder, parts[1])
		}
	}
	
	return result
}

