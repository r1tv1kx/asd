package dashboard

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net"
	"net/http"
	"os"
	"runtime"
	"time"

	"github.com/scanner/windows-service/internal/models"
)

// Client communicates with the dashboard server
type Client struct {
	baseURL    string
	httpClient *http.Client
	clientID   string
}

// NewClient creates a new dashboard client
func NewClient(baseURL string) *Client {
	return &Client{
		baseURL: baseURL,
		httpClient: &http.Client{
			Timeout: 30 * time.Second,
		},
	}
}

// Register registers this client with the dashboard server
func (c *Client) Register() (*models.ClientRegistrationResponse, error) {
	hostname, _ := os.Hostname()
	username := os.Getenv("USERNAME")
	if username == "" {
		username = os.Getenv("USER")
	}

	reg := models.ClientRegistration{
		Hostname:      hostname,
		Username:      username,
		OSVersion:     runtime.GOOS + " " + runtime.GOARCH,
		ClientVersion: "1.0.0",
		IPAddress:     getLocalIP(),
	}

	body, err := json.Marshal(reg)
	if err != nil {
		return nil, err
	}

	resp, err := c.httpClient.Post(
		c.baseURL+"/api/clients/register",
		"application/json",
		bytes.NewReader(body),
	)
	if err != nil {
		return nil, fmt.Errorf("failed to connect to dashboard: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusCreated && resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("registration failed with status %d", resp.StatusCode)
	}

	var result models.ClientRegistrationResponse
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, err
	}

	c.clientID = result.ID
	return &result, nil
}

// GetClientID returns the registered client ID
func (c *Client) GetClientID() string {
	return c.clientID
}

// SetClientID sets the client ID (loaded from storage)
func (c *Client) SetClientID(id string) {
	c.clientID = id
}

// CreateSession creates a new scan session on the dashboard
func (c *Client) CreateSession(scanType string, directories []string) (string, error) {
	if c.clientID == "" {
		return "", fmt.Errorf("client not registered")
	}

	payload := map[string]interface{}{
		"clientId":        c.clientID,
		"scanType":        scanType,
		"scanDirectories": directories,
	}

	body, err := json.Marshal(payload)
	if err != nil {
		return "", err
	}

	resp, err := c.httpClient.Post(
		c.baseURL+"/api/sessions",
		"application/json",
		bytes.NewReader(body),
	)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusCreated {
		return "", fmt.Errorf("failed to create session: status %d", resp.StatusCode)
	}

	var result struct {
		ID string `json:"id"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return "", err
	}

	return result.ID, nil
}

// UpdateSession updates a scan session status
func (c *Client) UpdateSession(sessionID string, status string, filesScanned, detectionsFound int) error {
	payload := map[string]interface{}{
		"status":          status,
		"filesScanned":    filesScanned,
		"detectionsFound": detectionsFound,
	}

	body, err := json.Marshal(payload)
	if err != nil {
		return err
	}

	req, err := http.NewRequest(
		http.MethodPut,
		c.baseURL+"/api/sessions/"+sessionID,
		bytes.NewReader(body),
	)
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/json")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("failed to update session: status %d", resp.StatusCode)
	}

	return nil
}

// SubmitDetections submits detections to the dashboard
func (c *Client) SubmitDetections(sessionID string, detections []models.Detection) error {
	if c.clientID == "" {
		return fmt.Errorf("client not registered")
	}

	if len(detections) == 0 {
		return nil
	}

	req := models.SubmitDetectionsRequest{
		ClientID:   c.clientID,
		SessionID:  sessionID,
		Detections: detections,
	}

	body, err := json.Marshal(req)
	if err != nil {
		return err
	}

	resp, err := c.httpClient.Post(
		c.baseURL+"/api/detections",
		"application/json",
		bytes.NewReader(body),
	)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusCreated {
		return fmt.Errorf("failed to submit detections: status %d", resp.StatusCode)
	}

	return nil
}

// HealthCheck checks if the dashboard server is available
func (c *Client) HealthCheck() error {
	resp, err := c.httpClient.Get(c.baseURL + "/health")
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("health check failed with status %d", resp.StatusCode)
	}

	return nil
}

// getLocalIP returns the local IP address
func getLocalIP() string {
	addrs, err := net.InterfaceAddrs()
	if err != nil {
		return ""
	}

	for _, addr := range addrs {
		if ipnet, ok := addr.(*net.IPNet); ok && !ipnet.IP.IsLoopback() {
			if ipnet.IP.To4() != nil {
				return ipnet.IP.String()
			}
		}
	}

	return ""
}

