package db

import (
	"database/sql"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/google/uuid"
	_ "modernc.org/sqlite"
	"github.com/scanner/windows-service/internal/models"
)

// Database handles local SQLite storage
type Database struct {
	db *sql.DB
}

// New creates a new database connection
func New(dataDir string) (*Database, error) {
	if err := os.MkdirAll(dataDir, 0755); err != nil {
		return nil, err
	}

	dbPath := filepath.Join(dataDir, "scanner.db")
	db, err := sql.Open("sqlite", dbPath)
	if err != nil {
		return nil, err
	}

	database := &Database{db: db}
	if err := database.initialize(); err != nil {
		return nil, err
	}

	return database, nil
}

// initialize creates the database schema
func (d *Database) initialize() error {
	schema := `
	CREATE TABLE IF NOT EXISTS detections (
		id TEXT PRIMARY KEY,
		file_path TEXT NOT NULL,
		file_name TEXT,
		file_type TEXT,
		file_size INTEGER,
		detection_type TEXT NOT NULL,
		matched_text_hash TEXT,
		redacted_preview TEXT,
		confidence REAL,
		severity TEXT,
		position_start INTEGER,
		position_end INTEGER,
		detected_at DATETIME DEFAULT CURRENT_TIMESTAMP,
		is_resolved INTEGER DEFAULT 0,
		synced INTEGER DEFAULT 0,
		scan_source TEXT DEFAULT 'filesystem',
		usb_device_id TEXT
	);

	CREATE TABLE IF NOT EXISTS scan_sessions (
		id TEXT PRIMARY KEY,
		started_at DATETIME,
		completed_at DATETIME,
		status TEXT,
		files_scanned INTEGER DEFAULT 0,
		detections_found INTEGER DEFAULT 0,
		scan_type TEXT,
		scan_directories TEXT,
		error_message TEXT
	);

	CREATE TABLE IF NOT EXISTS config (
		key TEXT PRIMARY KEY,
		value TEXT
	);

	-- Clipboard detections history
	CREATE TABLE IF NOT EXISTS clipboard_detections (
		id TEXT PRIMARY KEY,
		content_hash TEXT NOT NULL,
		detection_type TEXT NOT NULL,
		redacted_preview TEXT,
		confidence REAL,
		severity TEXT,
		detected_at DATETIME DEFAULT CURRENT_TIMESTAMP,
		source_app TEXT,
		is_resolved INTEGER DEFAULT 0,
		synced INTEGER DEFAULT 0
	);

	-- USB device tracking
	CREATE TABLE IF NOT EXISTS usb_devices (
		id TEXT PRIMARY KEY,
		device_serial TEXT,
		device_vendor TEXT,
		device_name TEXT,
		drive_letter TEXT,
		first_seen DATETIME,
		last_seen DATETIME,
		is_whitelisted INTEGER DEFAULT 0,
		is_blacklisted INTEGER DEFAULT 0
	);

	-- USB scan sessions
	CREATE TABLE IF NOT EXISTS usb_scan_sessions (
		id TEXT PRIMARY KEY,
		device_id TEXT,
		started_at DATETIME,
		completed_at DATETIME,
		status TEXT,
		files_scanned INTEGER DEFAULT 0,
		detections_found INTEGER DEFAULT 0
	);

	CREATE INDEX IF NOT EXISTS idx_detections_file_path ON detections(file_path);
	CREATE INDEX IF NOT EXISTS idx_detections_type ON detections(detection_type);
	CREATE INDEX IF NOT EXISTS idx_detections_synced ON detections(synced);
	CREATE INDEX IF NOT EXISTS idx_detections_scan_source ON detections(scan_source);
	CREATE INDEX IF NOT EXISTS idx_sessions_status ON scan_sessions(status);
	CREATE INDEX IF NOT EXISTS idx_clipboard_detected_at ON clipboard_detections(detected_at);
	CREATE INDEX IF NOT EXISTS idx_clipboard_synced ON clipboard_detections(synced);
	CREATE INDEX IF NOT EXISTS idx_usb_devices_serial ON usb_devices(device_serial);
	CREATE INDEX IF NOT EXISTS idx_usb_sessions_device ON usb_scan_sessions(device_id);
	`

	_, err := d.db.Exec(schema)
	if err != nil {
		return err
	}

	// Run migrations for existing databases
	if err := d.migrate(); err != nil {
		return err
	}

	return nil
}

// migrate handles database schema migrations
func (d *Database) migrate() error {
	// Check if detections table exists
	var tableExists int
	err := d.db.QueryRow(`
		SELECT COUNT(*) FROM sqlite_master 
		WHERE type='table' AND name='detections'
	`).Scan(&tableExists)
	
	if err != nil || tableExists == 0 {
		// Table doesn't exist, schema creation will handle it
		return nil
	}

	// Try to add scan_source column (ignore error if it already exists)
	_, err = d.db.Exec(`
		ALTER TABLE detections 
		ADD COLUMN scan_source TEXT DEFAULT 'filesystem'
	`)
	// SQLite returns error if column exists, but we can ignore it
	if err != nil && !strings.Contains(strings.ToLower(err.Error()), "duplicate") {
		// If error is not about duplicate column, check if column actually exists
		// by trying a SELECT
		_, selectErr := d.db.Exec("SELECT scan_source FROM detections LIMIT 1")
		if selectErr != nil {
			// Column doesn't exist, but ALTER failed - this is a real error
			// Try one more time
			_, _ = d.db.Exec(`
				ALTER TABLE detections 
				ADD COLUMN scan_source TEXT DEFAULT 'filesystem'
			`)
		}
	}

	// Try to add usb_device_id column (ignore error if it already exists)
	_, err = d.db.Exec(`
		ALTER TABLE detections 
		ADD COLUMN usb_device_id TEXT
	`)
	if err != nil && !strings.Contains(strings.ToLower(err.Error()), "duplicate") {
		_, selectErr := d.db.Exec("SELECT usb_device_id FROM detections LIMIT 1")
		if selectErr != nil {
			_, _ = d.db.Exec(`
				ALTER TABLE detections 
				ADD COLUMN usb_device_id TEXT
			`)
		}
	}

	return nil
}

// Close closes the database connection
func (d *Database) Close() error {
	return d.db.Close()
}

// SaveDetection saves a detection to the database
func (d *Database) SaveDetection(det *models.Detection) error {
	if det.ID == "" {
		det.ID = uuid.New().String()
	}

	var posStart, posEnd *int
	if det.Position != nil {
		posStart = &det.Position.Start
		posEnd = &det.Position.End
	}

	// Default scan source to filesystem if not set
	scanSource := det.ScanSource
	if scanSource == "" {
		scanSource = "filesystem"
	}

	var usbDeviceID *string
	if det.USBDeviceID != "" {
		usbDeviceID = &det.USBDeviceID
	}

	_, err := d.db.Exec(`
		INSERT OR REPLACE INTO detections 
		(id, file_path, file_name, file_type, file_size, detection_type, 
		 matched_text_hash, redacted_preview, confidence, severity,
		 position_start, position_end, detected_at, is_resolved, synced,
		 scan_source, usb_device_id)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)
	`, det.ID, det.FilePath, det.FileName, det.FileType, det.FileSize,
		det.DetectionType, det.MatchedTextHash, det.RedactedPreview,
		det.Confidence, det.Severity, posStart, posEnd, det.DetectedAt,
		det.IsResolved, scanSource, usbDeviceID)

	return err
}

// GetDetections retrieves detections with optional filters
func (d *Database) GetDetections(limit, offset int, unsynced bool) ([]models.Detection, error) {
	query := `
		SELECT id, file_path, file_name, file_type, file_size, detection_type,
			   matched_text_hash, redacted_preview, confidence, severity,
			   position_start, position_end, detected_at, is_resolved
		FROM detections
	`
	if unsynced {
		query += " WHERE synced = 0"
	}
	query += " ORDER BY detected_at DESC LIMIT ? OFFSET ?"

	rows, err := d.db.Query(query, limit, offset)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var detections []models.Detection
	for rows.Next() {
		var det models.Detection
		var posStart, posEnd sql.NullInt64
		var detectedAt string

		err := rows.Scan(
			&det.ID, &det.FilePath, &det.FileName, &det.FileType, &det.FileSize,
			&det.DetectionType, &det.MatchedTextHash, &det.RedactedPreview,
			&det.Confidence, &det.Severity, &posStart, &posEnd, &detectedAt,
			&det.IsResolved,
		)
		if err != nil {
			return nil, err
		}

		det.DetectedAt, _ = time.Parse("2006-01-02 15:04:05", detectedAt)
		if posStart.Valid && posEnd.Valid {
			det.Position = &models.Position{
				Start: int(posStart.Int64),
				End:   int(posEnd.Int64),
			}
		}

		detections = append(detections, det)
	}

	return detections, nil
}

// MarkDetectionsSynced marks detections as synced
func (d *Database) MarkDetectionsSynced(ids []string) error {
	if len(ids) == 0 {
		return nil
	}

	tx, err := d.db.Begin()
	if err != nil {
		return err
	}

	stmt, err := tx.Prepare("UPDATE detections SET synced = 1 WHERE id = ?")
	if err != nil {
		tx.Rollback()
		return err
	}
	defer stmt.Close()

	for _, id := range ids {
		if _, err := stmt.Exec(id); err != nil {
			tx.Rollback()
			return err
		}
	}

	return tx.Commit()
}

// GetDetectionCount returns the total number of detections
func (d *Database) GetDetectionCount() (int, error) {
	var count int
	err := d.db.QueryRow("SELECT COUNT(*) FROM detections").Scan(&count)
	return count, err
}

// SaveScanSession saves a scan session
func (d *Database) SaveScanSession(session *models.ScanSession) error {
	if session.ID == "" {
		session.ID = uuid.New().String()
	}

	dirs := ""
	for i, dir := range session.ScanDirectories {
		if i > 0 {
			dirs += ","
		}
		dirs += dir
	}

	_, err := d.db.Exec(`
		INSERT OR REPLACE INTO scan_sessions 
		(id, started_at, completed_at, status, files_scanned, detections_found,
		 scan_type, scan_directories, error_message)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
	`, session.ID, session.StartedAt, session.CompletedAt, session.Status,
		session.FilesScanned, session.DetectionsFound, session.ScanType, dirs,
		session.ErrorMessage)

	return err
}

// GetLastScanSession returns the most recent scan session
func (d *Database) GetLastScanSession() (*models.ScanSession, error) {
	row := d.db.QueryRow(`
		SELECT id, started_at, completed_at, status, files_scanned, detections_found,
			   scan_type, scan_directories, error_message
		FROM scan_sessions
		ORDER BY started_at DESC
		LIMIT 1
	`)

	var session models.ScanSession
	var startedAt, completedAt sql.NullString
	var dirs string

	err := row.Scan(
		&session.ID, &startedAt, &completedAt, &session.Status,
		&session.FilesScanned, &session.DetectionsFound, &session.ScanType,
		&dirs, &session.ErrorMessage,
	)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}

	if startedAt.Valid {
		t, _ := time.Parse("2006-01-02 15:04:05", startedAt.String)
		session.StartedAt = t
	}
	if completedAt.Valid {
		t, _ := time.Parse("2006-01-02 15:04:05", completedAt.String)
		session.CompletedAt = &t
	}

	return &session, nil
}

// SetConfig stores a configuration value
func (d *Database) SetConfig(key, value string) error {
	_, err := d.db.Exec(`
		INSERT OR REPLACE INTO config (key, value) VALUES (?, ?)
	`, key, value)
	return err
}

// GetConfig retrieves a configuration value
func (d *Database) GetConfig(key string) (string, error) {
	var value string
	err := d.db.QueryRow("SELECT value FROM config WHERE key = ?", key).Scan(&value)
	if err == sql.ErrNoRows {
		return "", nil
	}
	return value, err
}

// HasFileBeenScanned checks if a file has been scanned (has detections)
func (d *Database) HasFileBeenScanned(filePath string) (bool, error) {
	var count int
	err := d.db.QueryRow(
		"SELECT COUNT(*) FROM detections WHERE file_path = ?",
		filePath,
	).Scan(&count)
	return count > 0, err
}

// ClearAllData removes all scan data from the database
// Note: Client registration data (stored in config table) is preserved
func (d *Database) ClearAllData() error {
	tx, err := d.db.Begin()
	if err != nil {
		return err
	}

	// Delete all clipboard detections
	if _, err := tx.Exec("DELETE FROM clipboard_detections"); err != nil {
		tx.Rollback()
		return err
	}

	// Delete all USB scan sessions
	if _, err := tx.Exec("DELETE FROM usb_scan_sessions"); err != nil {
		tx.Rollback()
		return err
	}

	// Delete all USB devices
	if _, err := tx.Exec("DELETE FROM usb_devices"); err != nil {
		tx.Rollback()
		return err
	}

	// Delete all detections
	if _, err := tx.Exec("DELETE FROM detections"); err != nil {
		tx.Rollback()
		return err
	}

	// Delete all scan sessions
	if _, err := tx.Exec("DELETE FROM scan_sessions"); err != nil {
		tx.Rollback()
		return err
	}

	// IMPORTANT: Config table (which stores client_id) is NOT cleared to preserve client registration
	// The client_id in the config table links the Windows service to its registered client identity
	// DO NOT delete from config table - this would require clients to re-register

	return tx.Commit()
}

// ============================================================================
// Clipboard Detection Methods
// ============================================================================

// SaveClipboardDetection saves a clipboard detection to the database
func (d *Database) SaveClipboardDetection(det *models.ClipboardDetection) error {
	if det.ID == "" {
		det.ID = uuid.New().String()
	}

	_, err := d.db.Exec(`
		INSERT OR REPLACE INTO clipboard_detections 
		(id, content_hash, detection_type, redacted_preview, confidence, severity,
		 detected_at, source_app, is_resolved, synced)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
	`, det.ID, det.ContentHash, det.DetectionType, det.RedactedPreview,
		det.Confidence, det.Severity, det.DetectedAt, det.SourceApp, det.IsResolved)

	return err
}

// GetClipboardDetections retrieves clipboard detections with pagination
func (d *Database) GetClipboardDetections(limit, offset int) ([]models.ClipboardDetection, error) {
	query := `
		SELECT id, content_hash, detection_type, redacted_preview, confidence, severity,
			   detected_at, source_app, is_resolved
		FROM clipboard_detections
		ORDER BY detected_at DESC LIMIT ? OFFSET ?
	`

	rows, err := d.db.Query(query, limit, offset)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var detections []models.ClipboardDetection
	for rows.Next() {
		var det models.ClipboardDetection
		var detectedAt string
		var sourceApp sql.NullString
		var redactedPreview sql.NullString

		err := rows.Scan(
			&det.ID, &det.ContentHash, &det.DetectionType, &redactedPreview,
			&det.Confidence, &det.Severity, &detectedAt, &sourceApp, &det.IsResolved,
		)
		if err != nil {
			return nil, err
		}

		det.DetectedAt, _ = time.Parse("2006-01-02 15:04:05", detectedAt)
		if sourceApp.Valid {
			det.SourceApp = sourceApp.String
		}
		if redactedPreview.Valid {
			det.RedactedPreview = redactedPreview.String
		}

		detections = append(detections, det)
	}

	return detections, nil
}

// GetClipboardDetectionCount returns the total number of clipboard detections
func (d *Database) GetClipboardDetectionCount() (int, error) {
	var count int
	err := d.db.QueryRow("SELECT COUNT(*) FROM clipboard_detections").Scan(&count)
	return count, err
}

// ClearClipboardDetections removes all clipboard detections
func (d *Database) ClearClipboardDetections() error {
	_, err := d.db.Exec("DELETE FROM clipboard_detections")
	return err
}

// HasClipboardContentHash checks if a clipboard content hash already exists
func (d *Database) HasClipboardContentHash(hash string) (bool, error) {
	var count int
	err := d.db.QueryRow(
		"SELECT COUNT(*) FROM clipboard_detections WHERE content_hash = ?",
		hash,
	).Scan(&count)
	return count > 0, err
}

// ============================================================================
// USB Device Methods
// ============================================================================

// SaveUSBDevice saves or updates a USB device record
func (d *Database) SaveUSBDevice(device *models.USBDevice) error {
	if device.ID == "" {
		device.ID = uuid.New().String()
	}

	_, err := d.db.Exec(`
		INSERT OR REPLACE INTO usb_devices 
		(id, device_serial, device_vendor, device_name, drive_letter,
		 first_seen, last_seen, is_whitelisted, is_blacklisted)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
	`, device.ID, device.DeviceSerial, device.DeviceVendor, device.DeviceName,
		device.DriveLetter, device.FirstSeen, device.LastSeen,
		device.IsWhitelisted, device.IsBlacklisted)

	return err
}

// GetUSBDevices retrieves all USB devices
func (d *Database) GetUSBDevices() ([]models.USBDevice, error) {
	query := `
		SELECT id, device_serial, device_vendor, device_name, drive_letter,
			   first_seen, last_seen, is_whitelisted, is_blacklisted
		FROM usb_devices
		ORDER BY last_seen DESC
	`

	rows, err := d.db.Query(query)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var devices []models.USBDevice
	for rows.Next() {
		var device models.USBDevice
		var firstSeen, lastSeen string
		var serial, vendor, name, driveLetter sql.NullString

		err := rows.Scan(
			&device.ID, &serial, &vendor, &name, &driveLetter,
			&firstSeen, &lastSeen, &device.IsWhitelisted, &device.IsBlacklisted,
		)
		if err != nil {
			return nil, err
		}

		device.FirstSeen, _ = time.Parse("2006-01-02 15:04:05", firstSeen)
		device.LastSeen, _ = time.Parse("2006-01-02 15:04:05", lastSeen)
		if serial.Valid {
			device.DeviceSerial = serial.String
		}
		if vendor.Valid {
			device.DeviceVendor = vendor.String
		}
		if name.Valid {
			device.DeviceName = name.String
		}
		if driveLetter.Valid {
			device.DriveLetter = driveLetter.String
		}

		devices = append(devices, device)
	}

	return devices, nil
}

// GetUSBDeviceByID retrieves a USB device by ID
func (d *Database) GetUSBDeviceByID(id string) (*models.USBDevice, error) {
	row := d.db.QueryRow(`
		SELECT id, device_serial, device_vendor, device_name, drive_letter,
			   first_seen, last_seen, is_whitelisted, is_blacklisted
		FROM usb_devices WHERE id = ?
	`, id)

	var device models.USBDevice
	var firstSeen, lastSeen string
	var serial, vendor, name, driveLetter sql.NullString

	err := row.Scan(
		&device.ID, &serial, &vendor, &name, &driveLetter,
		&firstSeen, &lastSeen, &device.IsWhitelisted, &device.IsBlacklisted,
	)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}

	device.FirstSeen, _ = time.Parse("2006-01-02 15:04:05", firstSeen)
	device.LastSeen, _ = time.Parse("2006-01-02 15:04:05", lastSeen)
	if serial.Valid {
		device.DeviceSerial = serial.String
	}
	if vendor.Valid {
		device.DeviceVendor = vendor.String
	}
	if name.Valid {
		device.DeviceName = name.String
	}
	if driveLetter.Valid {
		device.DriveLetter = driveLetter.String
	}

	return &device, nil
}

// GetUSBDeviceBySerial retrieves a USB device by serial number
func (d *Database) GetUSBDeviceBySerial(serial string) (*models.USBDevice, error) {
	row := d.db.QueryRow(`
		SELECT id, device_serial, device_vendor, device_name, drive_letter,
			   first_seen, last_seen, is_whitelisted, is_blacklisted
		FROM usb_devices WHERE device_serial = ?
	`, serial)

	var device models.USBDevice
	var firstSeen, lastSeen string
	var serialVal, vendor, name, driveLetter sql.NullString

	err := row.Scan(
		&device.ID, &serialVal, &vendor, &name, &driveLetter,
		&firstSeen, &lastSeen, &device.IsWhitelisted, &device.IsBlacklisted,
	)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}

	device.FirstSeen, _ = time.Parse("2006-01-02 15:04:05", firstSeen)
	device.LastSeen, _ = time.Parse("2006-01-02 15:04:05", lastSeen)
	if serialVal.Valid {
		device.DeviceSerial = serialVal.String
	}
	if vendor.Valid {
		device.DeviceVendor = vendor.String
	}
	if name.Valid {
		device.DeviceName = name.String
	}
	if driveLetter.Valid {
		device.DriveLetter = driveLetter.String
	}

	return &device, nil
}

// UpdateUSBDeviceWhitelist updates the whitelist status of a USB device
func (d *Database) UpdateUSBDeviceWhitelist(id string, whitelisted bool) error {
	_, err := d.db.Exec(
		"UPDATE usb_devices SET is_whitelisted = ?, is_blacklisted = 0 WHERE id = ?",
		whitelisted, id,
	)
	return err
}

// UpdateUSBDeviceBlacklist updates the blacklist status of a USB device
func (d *Database) UpdateUSBDeviceBlacklist(id string, blacklisted bool) error {
	_, err := d.db.Exec(
		"UPDATE usb_devices SET is_blacklisted = ?, is_whitelisted = 0 WHERE id = ?",
		blacklisted, id,
	)
	return err
}

// ============================================================================
// USB Scan Session Methods
// ============================================================================

// SaveUSBScanSession saves a USB scan session
func (d *Database) SaveUSBScanSession(session *models.USBScanSession) error {
	if session.ID == "" {
		session.ID = uuid.New().String()
	}

	_, err := d.db.Exec(`
		INSERT OR REPLACE INTO usb_scan_sessions 
		(id, device_id, started_at, completed_at, status, files_scanned, detections_found)
		VALUES (?, ?, ?, ?, ?, ?, ?)
	`, session.ID, session.DeviceID, session.StartedAt, session.CompletedAt,
		session.Status, session.FilesScanned, session.DetectionsFound)

	return err
}

// GetUSBScanSessions retrieves USB scan sessions with optional device filter
func (d *Database) GetUSBScanSessions(deviceID string, limit, offset int) ([]models.USBScanSession, error) {
	var query string
	var args []interface{}

	if deviceID != "" {
		query = `
			SELECT id, device_id, started_at, completed_at, status, files_scanned, detections_found
			FROM usb_scan_sessions
			WHERE device_id = ?
			ORDER BY started_at DESC LIMIT ? OFFSET ?
		`
		args = []interface{}{deviceID, limit, offset}
	} else {
		query = `
			SELECT id, device_id, started_at, completed_at, status, files_scanned, detections_found
			FROM usb_scan_sessions
			ORDER BY started_at DESC LIMIT ? OFFSET ?
		`
		args = []interface{}{limit, offset}
	}

	rows, err := d.db.Query(query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var sessions []models.USBScanSession
	for rows.Next() {
		var session models.USBScanSession
		var startedAt string
		var completedAt sql.NullString

		err := rows.Scan(
			&session.ID, &session.DeviceID, &startedAt, &completedAt,
			&session.Status, &session.FilesScanned, &session.DetectionsFound,
		)
		if err != nil {
			return nil, err
		}

		session.StartedAt, _ = time.Parse("2006-01-02 15:04:05", startedAt)
		if completedAt.Valid {
			t, _ := time.Parse("2006-01-02 15:04:05", completedAt.String)
			session.CompletedAt = &t
		}

		sessions = append(sessions, session)
	}

	return sessions, nil
}

// GetDetectionsBySource retrieves detections filtered by scan source
func (d *Database) GetDetectionsBySource(source string, limit, offset int) ([]models.Detection, error) {
	query := `
		SELECT id, file_path, file_name, file_type, file_size, detection_type,
			   matched_text_hash, redacted_preview, confidence, severity,
			   position_start, position_end, detected_at, is_resolved, scan_source, usb_device_id
		FROM detections
		WHERE scan_source = ?
		ORDER BY detected_at DESC LIMIT ? OFFSET ?
	`

	rows, err := d.db.Query(query, source, limit, offset)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var detections []models.Detection
	for rows.Next() {
		var det models.Detection
		var posStart, posEnd sql.NullInt64
		var detectedAt string
		var usbDeviceID sql.NullString

		err := rows.Scan(
			&det.ID, &det.FilePath, &det.FileName, &det.FileType, &det.FileSize,
			&det.DetectionType, &det.MatchedTextHash, &det.RedactedPreview,
			&det.Confidence, &det.Severity, &posStart, &posEnd, &detectedAt,
			&det.IsResolved, &det.ScanSource, &usbDeviceID,
		)
		if err != nil {
			return nil, err
		}

		det.DetectedAt, _ = time.Parse("2006-01-02 15:04:05", detectedAt)
		if posStart.Valid && posEnd.Valid {
			det.Position = &models.Position{
				Start: int(posStart.Int64),
				End:   int(posEnd.Int64),
			}
		}
		if usbDeviceID.Valid {
			det.USBDeviceID = usbDeviceID.String
		}

		detections = append(detections, det)
	}

	return detections, nil
}

