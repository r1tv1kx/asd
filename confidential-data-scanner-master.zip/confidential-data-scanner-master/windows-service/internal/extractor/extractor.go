package extractor

import (
	"archive/zip"
	"bytes"
	"encoding/xml"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"

	"github.com/ledongthuc/pdf"
)

// TextExtractor extracts text from various file types
type TextExtractor struct{}

// New creates a new TextExtractor
func New() *TextExtractor {
	return &TextExtractor{}
}

// ExtractText extracts text content from a file
func (e *TextExtractor) ExtractText(filePath string) (string, error) {
	ext := strings.ToLower(filepath.Ext(filePath))

	switch ext {
	case ".txt", ".csv", ".log", ".json", ".xml", ".html", ".htm", ".md":
		return e.extractPlainText(filePath)
	case ".pdf":
		return e.extractPDF(filePath)
	case ".docx":
		return e.extractDOCX(filePath)
	case ".doc":
		// .doc files are more complex, return empty for now
		// Would need a proper library like github.com/unidoc/unioffice
		return "", fmt.Errorf("legacy .doc format not supported, please convert to .docx")
	default:
		return "", fmt.Errorf("unsupported file type: %s", ext)
	}
}

// extractPlainText reads plain text files
func (e *TextExtractor) extractPlainText(filePath string) (string, error) {
	data, err := os.ReadFile(filePath)
	if err != nil {
		return "", err
	}
	return string(data), nil
}

// extractPDF extracts text from PDF files
func (e *TextExtractor) extractPDF(filePath string) (text string, err error) {
	// Recover from panics caused by malformed PDFs
	defer func() {
		if r := recover(); r != nil {
			err = fmt.Errorf("PDF parsing panic: %v", r)
			text = ""
		}
	}()

	f, r, err := pdf.Open(filePath)
	if err != nil {
		return "", fmt.Errorf("failed to open PDF: %w", err)
	}
	defer f.Close()

	var buf bytes.Buffer
	totalPages := r.NumPage()

	for pageNum := 1; pageNum <= totalPages; pageNum++ {
		p := r.Page(pageNum)
		if p.V.IsNull() {
			continue
		}

		pageText, err := p.GetPlainText(nil)
		if err != nil {
			continue // Skip pages that fail to extract
		}
		buf.WriteString(pageText)
		buf.WriteString("\n")
	}

	return buf.String(), nil
}

// extractDOCX extracts text from DOCX files
func (e *TextExtractor) extractDOCX(filePath string) (string, error) {
	r, err := zip.OpenReader(filePath)
	if err != nil {
		return "", fmt.Errorf("failed to open DOCX: %w", err)
	}
	defer r.Close()

	var documentXML *zip.File
	for _, f := range r.File {
		if f.Name == "word/document.xml" {
			documentXML = f
			break
		}
	}

	if documentXML == nil {
		return "", fmt.Errorf("document.xml not found in DOCX")
	}

	rc, err := documentXML.Open()
	if err != nil {
		return "", err
	}
	defer rc.Close()

	data, err := io.ReadAll(rc)
	if err != nil {
		return "", err
	}

	return extractTextFromWordXML(data)
}

// extractTextFromWordXML parses Word XML and extracts text
func extractTextFromWordXML(data []byte) (string, error) {
	type Text struct {
		Content string `xml:",chardata"`
	}
	type Run struct {
		Text []Text `xml:"t"`
	}
	type Paragraph struct {
		Runs []Run `xml:"r"`
	}
	type Body struct {
		Paragraphs []Paragraph `xml:"p"`
	}
	type Document struct {
		Body Body `xml:"body"`
	}

	var doc Document
	if err := xml.Unmarshal(data, &doc); err != nil {
		return "", err
	}

	var buf bytes.Buffer
	for _, p := range doc.Body.Paragraphs {
		for _, r := range p.Runs {
			for _, t := range r.Text {
				buf.WriteString(t.Content)
			}
		}
		buf.WriteString("\n")
	}

	return buf.String(), nil
}

// IsSupportedFile checks if a file type is supported for text extraction
func (e *TextExtractor) IsSupportedFile(filePath string) bool {
	ext := strings.ToLower(filepath.Ext(filePath))
	supported := map[string]bool{
		".txt":  true,
		".csv":  true,
		".log":  true,
		".json": true,
		".xml":  true,
		".html": true,
		".htm":  true,
		".md":   true,
		".pdf":  true,
		".docx": true,
	}
	return supported[ext]
}

