package models

import (
	"time"
)

// Detection represents a PII detection in a file
type Detection struct {
	ID              string    `json:"id"`
	FilePath        string    `json:"filePath"`
	FileName        string    `json:"fileName"`
	FileType        string    `json:"fileType"`
	FileSize        int64     `json:"fileSize"`
	DetectionType   string    `json:"detectionType"`
	MatchedTextHash string    `json:"matchedTextHash"`
	RedactedPreview string    `json:"redactedPreview"`
	Confidence      float64   `json:"confidence"`
	Severity        string    `json:"severity"`
	Position        *Position `json:"position,omitempty"`
	DetectedAt      time.Time `json:"detectedAt"`
	IsResolved      bool      `json:"isResolved"`
	ScanSource      string    `json:"scanSource"`             // 'filesystem', 'clipboard', 'usb'
	USBDeviceID     string    `json:"usbDeviceId,omitempty"`
}

// Position represents the location of a detection in a file
type Position struct {
	Start int `json:"start"`
	End   int `json:"end"`
}

// ScanSession represents a scanning session
type ScanSession struct {
	ID              string    `json:"id"`
	StartedAt       time.Time `json:"startedAt"`
	CompletedAt     *time.Time `json:"completedAt,omitempty"`
	Status          string    `json:"status"` // running, completed, failed, cancelled
	FilesScanned    int       `json:"filesScanned"`
	DetectionsFound int       `json:"detectionsFound"`
	ScanType        string    `json:"scanType"` // full, incremental, manual
	ScanDirectories []string  `json:"scanDirectories"`
	ErrorMessage    string    `json:"errorMessage,omitempty"`
}

// ScanProgress represents the current scan progress
type ScanProgress struct {
	IsScanning      bool      `json:"isScanning"`
	CurrentFile     string    `json:"currentFile"`
	FilesScanned    int       `json:"filesScanned"`
	TotalFiles      int       `json:"totalFiles"`
	DetectionsFound int       `json:"detectionsFound"`
	StartedAt       time.Time `json:"startedAt"`
	EstimatedTime   int       `json:"estimatedTimeSeconds"`
}

// ServiceStatus represents the overall service status
type ServiceStatus struct {
	Status         string        `json:"status"` // running, stopped, error
	Version        string        `json:"version"`
	Uptime         int64         `json:"uptimeSeconds"`
	LastScan       *time.Time    `json:"lastScan,omitempty"`
	NextScan       *time.Time    `json:"nextScan,omitempty"`
	ScanProgress   *ScanProgress `json:"scanProgress,omitempty"`
	TotalDetections int          `json:"totalDetections"`
	ClientID       string        `json:"clientId"`
}

// AnalyzeRequest is the request sent to the analyzer server
type AnalyzeRequest struct {
	Text     string `json:"text"`
	FilePath string `json:"file_path,omitempty"`
	Language string `json:"language"`
}

// AnalyzeResponse is the response from the analyzer server
type AnalyzeResponse struct {
	FilePath        string              `json:"file_path"`
	Detections      []AnalyzerDetection `json:"detections"`
	TotalDetections int                 `json:"total_detections"`
	HasPII          bool                `json:"has_pii"`
}

// AnalyzerDetection represents a detection from the analyzer
type AnalyzerDetection struct {
	EntityType    string  `json:"entity_type"`
	Text          string  `json:"text"`
	Start         int     `json:"start"`
	End           int     `json:"end"`
	Confidence    float64 `json:"confidence"`
	RedactedText  string  `json:"redacted_text"`
}

// ClientRegistration is sent to register with the dashboard
type ClientRegistration struct {
	Hostname      string `json:"hostname"`
	Username      string `json:"username"`
	OSVersion     string `json:"osVersion"`
	ClientVersion string `json:"clientVersion"`
	IPAddress     string `json:"ipAddress"`
}

// ClientRegistrationResponse is the response from client registration
type ClientRegistrationResponse struct {
	ID       string `json:"id"`
	Hostname string `json:"hostname"`
}

// SubmitDetectionsRequest is sent to submit detections to the dashboard
type SubmitDetectionsRequest struct {
	ClientID   string      `json:"clientId"`
	SessionID  string      `json:"sessionId,omitempty"`
	Detections []Detection `json:"detections"`
}

// ============================================================================
// Clipboard Models
// ============================================================================

// ClipboardDetection represents a detection from clipboard monitoring
type ClipboardDetection struct {
	ID              string    `json:"id"`
	ContentHash     string    `json:"contentHash"`
	DetectionType   string    `json:"detectionType"`
	RedactedPreview string    `json:"redactedPreview,omitempty"`
	Confidence      float64   `json:"confidence"`
	Severity        string    `json:"severity"`
	DetectedAt      time.Time `json:"detectedAt"`
	SourceApp       string    `json:"sourceApp,omitempty"`
	IsResolved      bool      `json:"isResolved"`
}

// ClipboardStatus represents the clipboard monitor status
type ClipboardStatus struct {
	Enabled           bool       `json:"enabled"`
	IsMonitoring      bool       `json:"isMonitoring"`
	TotalDetections   int        `json:"totalDetections"`
	LastDetection     *time.Time `json:"lastDetection,omitempty"`
	LastChecked       *time.Time `json:"lastChecked,omitempty"`
	CheckIntervalMs   int        `json:"checkIntervalMs"`
}

// ============================================================================
// USB Device Models
// ============================================================================

// USBDevice represents a USB device
type USBDevice struct {
	ID            string    `json:"id"`
	DeviceSerial  string    `json:"deviceSerial"`
	DeviceVendor  string    `json:"deviceVendor"`
	DeviceName    string    `json:"deviceName"`
	DriveLetter   string    `json:"driveLetter"`
	FirstSeen     time.Time `json:"firstSeen"`
	LastSeen      time.Time `json:"lastSeen"`
	IsWhitelisted bool      `json:"isWhitelisted"`
	IsBlacklisted bool      `json:"isBlacklisted"`
}

// USBScanSession represents a USB scan session
type USBScanSession struct {
	ID              string     `json:"id"`
	DeviceID        string     `json:"deviceId"`
	StartedAt       time.Time  `json:"startedAt"`
	CompletedAt     *time.Time `json:"completedAt,omitempty"`
	Status          string     `json:"status"` // running, completed, failed, cancelled
	FilesScanned    int        `json:"filesScanned"`
	DetectionsFound int        `json:"detectionsFound"`
}

// USBStatus represents the USB monitor status
type USBStatus struct {
	Enabled           bool         `json:"enabled"`
	IsMonitoring      bool         `json:"isMonitoring"`
	ConnectedDevices  int          `json:"connectedDevices"`
	TotalDevicesSeen  int          `json:"totalDevicesSeen"`
	TotalScans        int          `json:"totalScans"`
	LastScan          *time.Time   `json:"lastScan,omitempty"`
	CurrentScan       *USBScanInfo `json:"currentScan,omitempty"`
}

// USBScanInfo represents information about a current USB scan
type USBScanInfo struct {
	DeviceID     string    `json:"deviceId"`
	DeviceName   string    `json:"deviceName"`
	DriveLetter  string    `json:"driveLetter"`
	StartedAt    time.Time `json:"startedAt"`
	FilesScanned int       `json:"filesScanned"`
	TotalFiles   int       `json:"totalFiles"`
}

