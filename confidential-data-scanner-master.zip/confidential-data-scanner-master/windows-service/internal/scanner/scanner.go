package scanner

import (
	"context"
	"log"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/google/uuid"
	"github.com/scanner/windows-service/internal/analyzer"
	"github.com/scanner/windows-service/internal/config"
	"github.com/scanner/windows-service/internal/dashboard"
	"github.com/scanner/windows-service/internal/db"
	"github.com/scanner/windows-service/internal/extractor"
	"github.com/scanner/windows-service/internal/models"
)

// Scanner handles file scanning operations
type Scanner struct {
	config          *config.Config
	db              *db.Database
	extractor       *extractor.TextExtractor
	analyzerClient  *analyzer.Client
	dashboardClient *dashboard.Client

	mu              sync.RWMutex
	isScanning      bool
	currentFile     string
	filesScanned    int32
	totalFiles      int32
	detectionsFound int32
	startedAt       time.Time
	cancelFunc      context.CancelFunc

	// USB scan state
	currentUSBDeviceID string
	scanSource         string // "filesystem", "usb"
}

// New creates a new Scanner
func New(
	cfg *config.Config,
	database *db.Database,
	analyzerClient *analyzer.Client,
	dashboardClient *dashboard.Client,
) *Scanner {
	return &Scanner{
		config:          cfg,
		db:              database,
		extractor:       extractor.New(),
		analyzerClient:  analyzerClient,
		dashboardClient: dashboardClient,
	}
}

// IsScanning returns whether a scan is in progress
func (s *Scanner) IsScanning() bool {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.isScanning
}

// GetProgress returns the current scan progress
func (s *Scanner) GetProgress() *models.ScanProgress {
	s.mu.RLock()
	defer s.mu.RUnlock()

	if !s.isScanning {
		return nil
	}

	filesScanned := atomic.LoadInt32(&s.filesScanned)
	totalFiles := atomic.LoadInt32(&s.totalFiles)
	detectionsFound := atomic.LoadInt32(&s.detectionsFound)

	var estimatedTime int
	if filesScanned > 0 && totalFiles > filesScanned {
		elapsed := time.Since(s.startedAt).Seconds()
		rate := float64(filesScanned) / elapsed
		remaining := float64(totalFiles - filesScanned)
		estimatedTime = int(remaining / rate)
	}

	return &models.ScanProgress{
		IsScanning:      true,
		CurrentFile:     s.currentFile,
		FilesScanned:    int(filesScanned),
		TotalFiles:      int(totalFiles),
		DetectionsFound: int(detectionsFound),
		StartedAt:       s.startedAt,
		EstimatedTime:   estimatedTime,
	}
}

// StartScan starts a new scan
func (s *Scanner) StartScan(ctx context.Context, scanType string) error {
	s.mu.Lock()
	if s.isScanning {
		s.mu.Unlock()
		return nil // Already scanning
	}
	s.isScanning = true
	s.startedAt = time.Now()
	atomic.StoreInt32(&s.filesScanned, 0)
	atomic.StoreInt32(&s.totalFiles, 0)
	atomic.StoreInt32(&s.detectionsFound, 0)
	
	ctx, cancel := context.WithCancel(ctx)
	s.cancelFunc = cancel
	s.mu.Unlock()

	go s.runScan(ctx, scanType)
	return nil
}

// StopScan stops the current scan
func (s *Scanner) StopScan() {
	s.mu.Lock()
	defer s.mu.Unlock()

	if s.cancelFunc != nil {
		s.cancelFunc()
		s.cancelFunc = nil
	}
	// Note: isScanning will be set to false in runScan's defer when context is cancelled
}

// runScan performs the actual scanning
func (s *Scanner) runScan(ctx context.Context, scanType string) {
	defer func() {
		s.mu.Lock()
		s.isScanning = false
		s.cancelFunc = nil
		s.mu.Unlock()
	}()

	// Create session on dashboard
	var sessionID string
	if s.dashboardClient != nil && s.dashboardClient.GetClientID() != "" {
		var err error
		sessionID, err = s.dashboardClient.CreateSession(scanType, s.config.Scan.Directories)
		if err != nil {
			log.Printf("Warning: Could not create session on dashboard: %v", err)
		}
	}

	// Create local session
	session := &models.ScanSession{
		ID:              uuid.New().String(),
		StartedAt:       time.Now(),
		Status:          "running",
		ScanType:        scanType,
		ScanDirectories: s.config.Scan.Directories,
	}
	s.db.SaveScanSession(session)

	// Collect files to scan
	files := s.collectFiles()
	atomic.StoreInt32(&s.totalFiles, int32(len(files)))

	log.Printf("Starting %s scan: %d files to process", scanType, len(files))

	// Create worker pool
	workerCount := s.config.Scan.WorkerCount
	if workerCount <= 0 {
		workerCount = 4
	}

	fileChan := make(chan string, workerCount*2)
	var wg sync.WaitGroup

	// Start workers
	for i := 0; i < workerCount; i++ {
		wg.Add(1)
		go s.worker(ctx, fileChan, &wg, sessionID)
	}

	// Send files to workers
	for _, file := range files {
		select {
		case <-ctx.Done():
			close(fileChan)
			wg.Wait()
			s.finishScan(session, sessionID, "cancelled")
			return
		case fileChan <- file:
		}
	}

	close(fileChan)
	wg.Wait()

	s.finishScan(session, sessionID, "completed")
}

// worker processes files from the channel
func (s *Scanner) worker(ctx context.Context, files <-chan string, wg *sync.WaitGroup, sessionID string) {
	defer wg.Done()

	var batchDetections []models.Detection
	batchSize := 10

	for file := range files {
		// Check for cancellation before processing
		select {
		case <-ctx.Done():
			return
		default:
		}

		s.mu.Lock()
		s.currentFile = file
		s.mu.Unlock()

		// Check again after setting current file
		select {
		case <-ctx.Done():
			return
		default:
		}

		detections, err := s.processFile(file)
		if err != nil {
			log.Printf("Error processing %s: %v", file, err)
		}

		if len(detections) > 0 {
			atomic.AddInt32(&s.detectionsFound, int32(len(detections)))
			batchDetections = append(batchDetections, detections...)

			// Save to local DB
			for _, det := range detections {
				s.db.SaveDetection(&det)
			}

			// Send batch to dashboard
			if len(batchDetections) >= batchSize {
				s.sendDetections(sessionID, batchDetections)
				batchDetections = nil
			}
		}

		atomic.AddInt32(&s.filesScanned, 1)
	}

	// Send remaining detections
	if len(batchDetections) > 0 {
		s.sendDetections(sessionID, batchDetections)
	}
}

// processFile scans a single file for PII
func (s *Scanner) processFile(filePath string) ([]models.Detection, error) {
	// Check file size
	info, err := os.Stat(filePath)
	if err != nil {
		return nil, err
	}

	maxSize := s.config.Scan.MaxFileSize * 1024 * 1024 // Convert MB to bytes
	if info.Size() > maxSize {
		log.Printf("Skipping %s: file too large (%d bytes)", filePath, info.Size())
		return nil, nil
	}

	// Extract text
	text, err := s.extractor.ExtractText(filePath)
	if err != nil {
		return nil, err
	}

	if strings.TrimSpace(text) == "" {
		return nil, nil
	}

	// Analyze text
	resp, err := s.analyzerClient.Analyze(text, filePath)
	if err != nil {
		return nil, err
	}

	if !resp.HasPII {
		return nil, nil
	}

	// Convert to detections
	detections := analyzer.ConvertToDetections(filePath, resp)
	return detections, nil
}

// collectFiles gathers all files to scan
func (s *Scanner) collectFiles() []string {
	var files []string
	fileTypes := make(map[string]bool)
	for _, ft := range s.config.Scan.FileTypes {
		fileTypes[strings.ToLower(ft)] = true
	}

	for _, dir := range s.config.Scan.Directories {
		filepath.Walk(dir, func(path string, info os.FileInfo, err error) error {
			if err != nil {
				return nil // Skip errors
			}
			if info.IsDir() {
				// Skip hidden directories
				if strings.HasPrefix(info.Name(), ".") {
					return filepath.SkipDir
				}
				return nil
			}

			ext := strings.ToLower(filepath.Ext(path))
			if fileTypes[ext] && s.extractor.IsSupportedFile(path) {
				files = append(files, path)
			}
			return nil
		})
	}

	return files
}

// sendDetections sends detections to the dashboard
func (s *Scanner) sendDetections(sessionID string, detections []models.Detection) {
	if s.dashboardClient == nil || s.dashboardClient.GetClientID() == "" {
		return
	}

	if err := s.dashboardClient.SubmitDetections(sessionID, detections); err != nil {
		log.Printf("Warning: Could not send detections to dashboard: %v", err)
	}
}

// finishScan completes a scan session
func (s *Scanner) finishScan(session *models.ScanSession, sessionID, status string) {
	now := time.Now()
	session.CompletedAt = &now
	session.Status = status
	session.FilesScanned = int(atomic.LoadInt32(&s.filesScanned))
	session.DetectionsFound = int(atomic.LoadInt32(&s.detectionsFound))

	s.db.SaveScanSession(session)

	// Update dashboard session
	if sessionID != "" && s.dashboardClient != nil {
		s.dashboardClient.UpdateSession(
			sessionID,
			status,
			session.FilesScanned,
			session.DetectionsFound,
		)
	}

	log.Printf("Scan %s: %d files scanned, %d detections found",
		status, session.FilesScanned, session.DetectionsFound)
}

// StartUSBScan starts a scan of a USB drive
func (s *Scanner) StartUSBScan(ctx context.Context, drivePath string, deviceID string) error {
	s.mu.Lock()
	if s.isScanning {
		s.mu.Unlock()
		return nil // Already scanning
	}
	s.isScanning = true
	s.startedAt = time.Now()
	s.currentUSBDeviceID = deviceID
	s.scanSource = "usb"
	atomic.StoreInt32(&s.filesScanned, 0)
	atomic.StoreInt32(&s.totalFiles, 0)
	atomic.StoreInt32(&s.detectionsFound, 0)

	ctx, cancel := context.WithCancel(ctx)
	s.cancelFunc = cancel
	s.mu.Unlock()

	// Run scan synchronously for USB (called from USB monitor goroutine)
	s.runUSBScan(ctx, drivePath, deviceID)
	return nil
}

// runUSBScan performs the USB drive scanning
func (s *Scanner) runUSBScan(ctx context.Context, drivePath string, deviceID string) {
	defer func() {
		s.mu.Lock()
		s.isScanning = false
		s.cancelFunc = nil
		s.currentUSBDeviceID = ""
		s.scanSource = ""
		s.mu.Unlock()
	}()

	// Collect files from USB drive
	files := s.collectUSBFiles(drivePath)
	atomic.StoreInt32(&s.totalFiles, int32(len(files)))

	log.Printf("Starting USB scan of %s: %d files to process", drivePath, len(files))

	if len(files) == 0 {
		return
	}

	// Create worker pool
	workerCount := s.config.Scan.WorkerCount
	if workerCount <= 0 {
		workerCount = 4
	}

	fileChan := make(chan string, workerCount*2)
	var wg sync.WaitGroup

	// Start workers
	for i := 0; i < workerCount; i++ {
		wg.Add(1)
		go s.usbWorker(ctx, fileChan, &wg, deviceID)
	}

	// Send files to workers
	for _, file := range files {
		select {
		case <-ctx.Done():
			close(fileChan)
			wg.Wait()
			return
		case fileChan <- file:
		}
	}

	close(fileChan)
	wg.Wait()

	log.Printf("USB scan completed: %d files scanned, %d detections found",
		atomic.LoadInt32(&s.filesScanned), atomic.LoadInt32(&s.detectionsFound))
}

// usbWorker processes files from USB drive
func (s *Scanner) usbWorker(ctx context.Context, files <-chan string, wg *sync.WaitGroup, deviceID string) {
	defer wg.Done()

	var batchDetections []models.Detection
	batchSize := 10

	for file := range files {
		select {
		case <-ctx.Done():
			return
		default:
		}

		s.mu.Lock()
		s.currentFile = file
		s.mu.Unlock()

		detections, err := s.processUSBFile(file, deviceID)
		if err != nil {
			log.Printf("Error processing USB file %s: %v", file, err)
		}

		if len(detections) > 0 {
			atomic.AddInt32(&s.detectionsFound, int32(len(detections)))
			batchDetections = append(batchDetections, detections...)

			// Save to local DB
			for _, det := range detections {
				s.db.SaveDetection(&det)
			}

			// Send batch to dashboard
			if len(batchDetections) >= batchSize {
				s.sendDetections("", batchDetections)
				batchDetections = nil
			}
		}

		atomic.AddInt32(&s.filesScanned, 1)
	}

	// Send remaining detections
	if len(batchDetections) > 0 {
		s.sendDetections("", batchDetections)
	}
}

// processUSBFile scans a single file from USB for PII
func (s *Scanner) processUSBFile(filePath string, deviceID string) ([]models.Detection, error) {
	// Check file size
	info, err := os.Stat(filePath)
	if err != nil {
		return nil, err
	}

	maxSize := s.config.Scan.MaxFileSize * 1024 * 1024 // Convert MB to bytes
	if info.Size() > maxSize {
		return nil, nil
	}

	// Extract text
	text, err := s.extractor.ExtractText(filePath)
	if err != nil {
		return nil, err
	}

	if strings.TrimSpace(text) == "" {
		return nil, nil
	}

	// Analyze text
	resp, err := s.analyzerClient.Analyze(text, filePath)
	if err != nil {
		return nil, err
	}

	if !resp.HasPII {
		return nil, nil
	}

	// Convert to detections with USB source
	detections := analyzer.ConvertToDetections(filePath, resp)

	// Set USB-specific fields
	for i := range detections {
		detections[i].ScanSource = "usb"
		detections[i].USBDeviceID = deviceID
	}

	return detections, nil
}

// collectUSBFiles gathers all files from USB drive to scan
func (s *Scanner) collectUSBFiles(drivePath string) []string {
	var files []string
	fileTypes := make(map[string]bool)
	for _, ft := range s.config.Scan.FileTypes {
		fileTypes[strings.ToLower(ft)] = true
	}

	filepath.Walk(drivePath, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return nil // Skip errors
		}
		if info.IsDir() {
			// Skip hidden directories unless configured otherwise
			if !s.config.USB.ScanHiddenFiles && strings.HasPrefix(info.Name(), ".") {
				return filepath.SkipDir
			}
			// Skip system directories
			name := strings.ToLower(info.Name())
			if name == "$recycle.bin" || name == "system volume information" {
				return filepath.SkipDir
			}
			return nil
		}

		// Skip hidden files unless configured otherwise
		if !s.config.USB.ScanHiddenFiles && strings.HasPrefix(info.Name(), ".") {
			return nil
		}

		ext := strings.ToLower(filepath.Ext(path))
		if fileTypes[ext] && s.extractor.IsSupportedFile(path) {
			files = append(files, path)
		}
		return nil
	})

	return files
}

