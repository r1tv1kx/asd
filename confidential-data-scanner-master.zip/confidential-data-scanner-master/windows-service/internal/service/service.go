//go:build windows

package service

import (
	"context"
	"log"
	"time"

	"golang.org/x/sys/windows/svc"
	"golang.org/x/sys/windows/svc/debug"

	"github.com/scanner/windows-service/internal/analyzer"
	"github.com/scanner/windows-service/internal/api"
	"github.com/scanner/windows-service/internal/clipboard"
	"github.com/scanner/windows-service/internal/config"
	"github.com/scanner/windows-service/internal/dashboard"
	"github.com/scanner/windows-service/internal/db"
	"github.com/scanner/windows-service/internal/scanner"
	"github.com/scanner/windows-service/internal/usb"
)

const serviceName = "ConfidentialDataScanner"

// WindowsService implements the Windows service interface
type WindowsService struct {
	config           *config.Config
	db               *db.Database
	scanner          *scanner.Scanner
	clipboardMonitor *clipboard.Monitor
	usbMonitor       *usb.Monitor
	apiServer        *api.Server
	analyzerClient   *analyzer.Client
	dashboardClient  *dashboard.Client
	clientID         string
}

// New creates a new Windows service
func New(cfg *config.Config, dataDir string) (*WindowsService, error) {
	// Initialize database
	database, err := db.New(dataDir)
	if err != nil {
		return nil, err
	}

	// Initialize clients
	analyzerClient := analyzer.NewClient(cfg.Servers.AnalyzerURL)
	dashboardClient := dashboard.NewClient(cfg.Servers.DashboardURL)

	// Load or create client ID
	clientID, _ := database.GetConfig("client_id")

	ws := &WindowsService{
		config:          cfg,
		db:              database,
		analyzerClient:  analyzerClient,
		dashboardClient: dashboardClient,
		clientID:        clientID,
	}

	// Initialize scanner
	ws.scanner = scanner.New(cfg, database, analyzerClient, dashboardClient)

	return ws, nil
}

// Execute implements the Windows service Execute method
func (ws *WindowsService) Execute(args []string, r <-chan svc.ChangeRequest, changes chan<- svc.Status) (ssec bool, errno uint32) {
	const cmdsAccepted = svc.AcceptStop | svc.AcceptShutdown

	changes <- svc.Status{State: svc.StartPending}

	// Initialize service
	if err := ws.initialize(); err != nil {
		log.Printf("Failed to initialize service: %v", err)
		return true, 1
	}

	changes <- svc.Status{State: svc.Running, Accepts: cmdsAccepted}

	// Start API server in background
	go func() {
		if err := ws.apiServer.Start(); err != nil {
			log.Printf("API server error: %v", err)
		}
	}()

	// Start clipboard monitor if enabled
	if ws.clipboardMonitor != nil {
		go ws.clipboardMonitor.Start(context.Background())
	}

	// Start USB monitor if enabled
	if ws.usbMonitor != nil {
		go ws.usbMonitor.Start(context.Background())
	}

	// Start initial scan
	go ws.scanner.StartScan(context.Background(), "full")

	// Start scheduled scanning
	ticker := time.NewTicker(time.Duration(ws.config.Scan.IntervalHours) * time.Hour)
	defer ticker.Stop()

loop:
	for {
		select {
		case <-ticker.C:
			if !ws.scanner.IsScanning() {
				go ws.scanner.StartScan(context.Background(), "incremental")
			}
		case c := <-r:
			switch c.Cmd {
			case svc.Interrogate:
				changes <- c.CurrentStatus
			case svc.Stop, svc.Shutdown:
				break loop
			default:
				log.Printf("Unexpected control request: %d", c.Cmd)
			}
		}
	}

	changes <- svc.Status{State: svc.StopPending}

	// Cleanup
	ws.scanner.StopScan()

	// Stop clipboard monitor
	if ws.clipboardMonitor != nil {
		ws.clipboardMonitor.Stop()
	}

	// Stop USB monitor
	if ws.usbMonitor != nil {
		ws.usbMonitor.Stop()
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	ws.apiServer.Stop(ctx)
	ws.db.Close()

	return false, 0
}

// initialize sets up the service components
func (ws *WindowsService) initialize() error {
	// Register with dashboard if not already registered
	if ws.clientID == "" {
		resp, err := ws.dashboardClient.Register()
		if err != nil {
			log.Printf("Warning: Could not register with dashboard: %v", err)
		} else {
			ws.clientID = resp.ID
			ws.db.SetConfig("client_id", ws.clientID)
			ws.dashboardClient.SetClientID(ws.clientID)
			log.Printf("Registered with dashboard as client: %s", ws.clientID)
		}
	} else {
		ws.dashboardClient.SetClientID(ws.clientID)
	}

	// Initialize clipboard monitor if enabled
	if ws.config.Clipboard.Enabled {
		ws.clipboardMonitor = clipboard.New(
			ws.config,
			ws.db,
			ws.analyzerClient,
			ws.dashboardClient,
		)
		log.Println("Clipboard monitor initialized")
	}

	// Initialize USB monitor if enabled
	if ws.config.USB.Enabled {
		ws.usbMonitor = usb.New(
			ws.config,
			ws.db,
			ws.scanner,
			ws.dashboardClient,
		)
		log.Println("USB monitor initialized")
	}

	// Initialize API server
	ws.apiServer = api.NewServer(ws.config, ws.db, ws.scanner, ws.clientID)

	// Set clipboard monitor reference in API server
	if ws.clipboardMonitor != nil {
		ws.apiServer.SetClipboardMonitor(ws.clipboardMonitor)
	}

	// Set USB monitor reference in API server
	if ws.usbMonitor != nil {
		ws.apiServer.SetUSBMonitor(ws.usbMonitor)
	}

	return nil
}

// Run runs the service (for debugging or console mode)
func (ws *WindowsService) Run(isDebug bool) error {
	if isDebug {
		return debug.Run(serviceName, ws)
	}
	return svc.Run(serviceName, ws)
}

// RunInteractive runs the service in interactive/console mode
func (ws *WindowsService) RunInteractive(ctx context.Context) error {
	log.Println("Starting service in interactive mode...")

	if err := ws.initialize(); err != nil {
		return err
	}

	// Start API server in background
	go func() {
		log.Printf("Starting API server on port %d", ws.config.API.Port)
		if err := ws.apiServer.Start(); err != nil {
			log.Printf("API server error: %v", err)
		}
	}()

	// Start clipboard monitor if enabled
	if ws.clipboardMonitor != nil {
		go ws.clipboardMonitor.Start(ctx)
		log.Println("Clipboard monitor started")
	}

	// Start USB monitor if enabled
	if ws.usbMonitor != nil {
		go ws.usbMonitor.Start(ctx)
		log.Println("USB monitor started")
	}

	// Start initial scan
	go ws.scanner.StartScan(ctx, "full")

	// Wait for context cancellation
	<-ctx.Done()

	// Cleanup
	log.Println("Shutting down...")
	ws.scanner.StopScan()

	// Stop clipboard monitor
	if ws.clipboardMonitor != nil {
		ws.clipboardMonitor.Stop()
	}

	// Stop USB monitor
	if ws.usbMonitor != nil {
		ws.usbMonitor.Stop()
	}

	shutdownCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	ws.apiServer.Stop(shutdownCtx)
	ws.db.Close()

	return nil
}

