// +build !windows

package service

import (
	"context"
	"log"
	"time"

	"github.com/scanner/windows-service/internal/analyzer"
	"github.com/scanner/windows-service/internal/api"
	"github.com/scanner/windows-service/internal/config"
	"github.com/scanner/windows-service/internal/dashboard"
	"github.com/scanner/windows-service/internal/db"
	"github.com/scanner/windows-service/internal/scanner"
)

// WindowsService is a cross-platform service wrapper
type WindowsService struct {
	config          *config.Config
	db              *db.Database
	scanner         *scanner.Scanner
	apiServer       *api.Server
	analyzerClient  *analyzer.Client
	dashboardClient *dashboard.Client
	clientID        string
}

// New creates a new service
func New(cfg *config.Config, dataDir string) (*WindowsService, error) {
	// Initialize database
	database, err := db.New(dataDir)
	if err != nil {
		return nil, err
	}

	// Initialize clients
	analyzerClient := analyzer.NewClient(cfg.Servers.AnalyzerURL)
	dashboardClient := dashboard.NewClient(cfg.Servers.DashboardURL)

	// Load or create client ID
	clientID, _ := database.GetConfig("client_id")

	ws := &WindowsService{
		config:          cfg,
		db:              database,
		analyzerClient:  analyzerClient,
		dashboardClient: dashboardClient,
		clientID:        clientID,
	}

	// Initialize scanner
	ws.scanner = scanner.New(cfg, database, analyzerClient, dashboardClient)

	return ws, nil
}

// Run is not supported on non-Windows platforms
func (ws *WindowsService) Run(isDebug bool) error {
	log.Println("Windows service mode not supported on this platform")
	log.Println("Use RunInteractive instead")
	return nil
}

// RunInteractive runs the service in interactive/console mode
func (ws *WindowsService) RunInteractive(ctx context.Context) error {
	log.Println("Starting service in interactive mode...")

	if err := ws.initialize(); err != nil {
		return err
	}

	// Start API server in background
	go func() {
		log.Printf("Starting API server on port %d", ws.config.API.Port)
		if err := ws.apiServer.Start(); err != nil {
			log.Printf("API server error: %v", err)
		}
	}()

	// Start initial scan
	go ws.scanner.StartScan(ctx, "full")

	// Wait for context cancellation
	<-ctx.Done()

	// Cleanup
	log.Println("Shutting down...")
	ws.scanner.StopScan()
	shutdownCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	ws.apiServer.Stop(shutdownCtx)
	ws.db.Close()

	return nil
}

// initialize sets up the service components
func (ws *WindowsService) initialize() error {
	// Register with dashboard if not already registered
	if ws.clientID == "" {
		resp, err := ws.dashboardClient.Register()
		if err != nil {
			log.Printf("Warning: Could not register with dashboard: %v", err)
		} else {
			ws.clientID = resp.ID
			ws.db.SetConfig("client_id", ws.clientID)
			ws.dashboardClient.SetClientID(ws.clientID)
			log.Printf("Registered with dashboard as client: %s", ws.clientID)
		}
	} else {
		ws.dashboardClient.SetClientID(ws.clientID)
	}

	// Initialize API server
	ws.apiServer = api.NewServer(ws.config, ws.db, ws.scanner, ws.clientID)

	return nil
}

