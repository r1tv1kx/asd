package usb

import (
	"context"
	"log"
	"path/filepath"
	"sync"
	"time"

	"github.com/google/uuid"
	"github.com/scanner/windows-service/internal/config"
	"github.com/scanner/windows-service/internal/dashboard"
	"github.com/scanner/windows-service/internal/db"
	"github.com/scanner/windows-service/internal/models"
)

// ScannerInterface defines the interface for the file scanner
type ScannerInterface interface {
	StartUSBScan(ctx context.Context, drivePath string, deviceID string) error
	IsScanning() bool
}

// Monitor handles USB device monitoring and scanning
type Monitor struct {
	config          *config.Config
	db              *db.Database
	scanner         ScannerInterface
	dashboardClient *dashboard.Client

	mu              sync.RWMutex
	isMonitoring    bool
	connectedDrives map[string]*models.USBDevice // drive letter -> device
	cancelFunc      context.CancelFunc
	currentScan     *models.USBScanInfo

	// Callback for device events
	deviceCallback func(event string, device *models.USBDevice)
}

// New creates a new USB monitor
func New(
	cfg *config.Config,
	database *db.Database,
	scanner ScannerInterface,
	dashboardClient *dashboard.Client,
) *Monitor {
	return &Monitor{
		config:          cfg,
		db:              database,
		scanner:         scanner,
		dashboardClient: dashboardClient,
		connectedDrives: make(map[string]*models.USBDevice),
	}
}

// SetDeviceCallback sets a callback for device events
func (m *Monitor) SetDeviceCallback(callback func(event string, device *models.USBDevice)) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.deviceCallback = callback
}

// Start begins USB device monitoring
func (m *Monitor) Start(ctx context.Context) error {
	m.mu.Lock()
	if m.isMonitoring {
		m.mu.Unlock()
		return nil
	}
	m.isMonitoring = true

	ctx, cancel := context.WithCancel(ctx)
	m.cancelFunc = cancel
	m.mu.Unlock()

	log.Println("Starting USB device monitor...")

	// Initial scan for connected devices
	m.scanConnectedDevices()

	// Start monitoring loop
	go m.monitorLoop(ctx)

	return nil
}

// Stop stops USB device monitoring
func (m *Monitor) Stop() {
	m.mu.Lock()
	defer m.mu.Unlock()

	if m.cancelFunc != nil {
		m.cancelFunc()
		m.cancelFunc = nil
	}
	m.isMonitoring = false
	log.Println("USB device monitor stopped")
}

// IsMonitoring returns whether the monitor is active
func (m *Monitor) IsMonitoring() bool {
	m.mu.RLock()
	defer m.mu.RUnlock()
	return m.isMonitoring
}

// GetStatus returns the current USB monitor status
func (m *Monitor) GetStatus() *models.USBStatus {
	m.mu.RLock()
	defer m.mu.RUnlock()

	devices, _ := m.db.GetUSBDevices()
	sessions, _ := m.db.GetUSBScanSessions("", 1, 0)

	status := &models.USBStatus{
		Enabled:          m.config.USB.Enabled,
		IsMonitoring:     m.isMonitoring,
		ConnectedDevices: len(m.connectedDrives),
		TotalDevicesSeen: len(devices),
		CurrentScan:      m.currentScan,
	}

	if len(sessions) > 0 && sessions[0].CompletedAt != nil {
		status.LastScan = sessions[0].CompletedAt
	}

	return status
}

// GetConnectedDevices returns currently connected USB devices
func (m *Monitor) GetConnectedDevices() []*models.USBDevice {
	m.mu.RLock()
	defer m.mu.RUnlock()

	devices := make([]*models.USBDevice, 0, len(m.connectedDrives))
	for _, device := range m.connectedDrives {
		devices = append(devices, device)
	}
	return devices
}

// TriggerScan manually triggers a scan for a specific device
func (m *Monitor) TriggerScan(ctx context.Context, deviceID string) error {
	device, err := m.db.GetUSBDeviceByID(deviceID)
	if err != nil {
		return err
	}

	if device == nil || device.DriveLetter == "" {
		return nil
	}

	return m.scanDevice(ctx, device)
}

// monitorLoop is the main monitoring loop
func (m *Monitor) monitorLoop(ctx context.Context) {
	// Poll for device changes every 2 seconds
	ticker := time.NewTicker(2 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			m.mu.Lock()
			m.isMonitoring = false
			m.mu.Unlock()
			return
		case <-ticker.C:
			m.checkForDeviceChanges()
		}
	}
}

// scanConnectedDevices performs initial scan of connected removable devices
func (m *Monitor) scanConnectedDevices() {
	drives := getRemovableDrives()

	for _, drive := range drives {
		m.handleDeviceConnected(drive)
	}
}

// checkForDeviceChanges checks for USB device insertions/removals
func (m *Monitor) checkForDeviceChanges() {
	currentDrives := getRemovableDrives()

	m.mu.Lock()
	previousDrives := make(map[string]bool)
	for drive := range m.connectedDrives {
		previousDrives[drive] = true
	}
	m.mu.Unlock()

	// Check for new drives
	for _, drive := range currentDrives {
		if !previousDrives[drive] {
			m.handleDeviceConnected(drive)
		}
		delete(previousDrives, drive)
	}

	// Check for removed drives
	for drive := range previousDrives {
		m.handleDeviceDisconnected(drive)
	}
}

// handleDeviceConnected handles a newly connected USB device
func (m *Monitor) handleDeviceConnected(driveLetter string) {
	log.Printf("USB device connected: %s", driveLetter)

	// Get device info
	info := getDeviceInfo(driveLetter)

	// Check if device exists in database
	var device *models.USBDevice
	if info.Serial != "" {
		device, _ = m.db.GetUSBDeviceBySerial(info.Serial)
	}

	now := time.Now()
	if device == nil {
		// New device
		device = &models.USBDevice{
			ID:            uuid.New().String(),
			DeviceSerial:  info.Serial,
			DeviceVendor:  info.Vendor,
			DeviceName:    info.Name,
			DriveLetter:   driveLetter,
			FirstSeen:     now,
			LastSeen:      now,
			IsWhitelisted: false,
			IsBlacklisted: false,
		}
	} else {
		// Existing device
		device.DriveLetter = driveLetter
		device.LastSeen = now
		if device.DeviceName == "" {
			device.DeviceName = info.Name
		}
		if device.DeviceVendor == "" {
			device.DeviceVendor = info.Vendor
		}
	}

	// Check whitelist/blacklist from config
	if m.isDeviceWhitelisted(device) {
		device.IsWhitelisted = true
	}
	if m.isDeviceBlacklisted(device) {
		device.IsBlacklisted = true
	}

	// Save to database
	if err := m.db.SaveUSBDevice(device); err != nil {
		log.Printf("Failed to save USB device: %v", err)
	}

	// Add to connected drives
	m.mu.Lock()
	m.connectedDrives[driveLetter] = device
	callback := m.deviceCallback
	m.mu.Unlock()

	// Trigger callback
	if callback != nil {
		callback("connected", device)
	}

	// Auto-scan if enabled and device is not blacklisted
	if m.config.USB.AutoScanOnInsert && !device.IsBlacklisted {
		// Skip scan for whitelisted devices unless they've never been scanned
		if !device.IsWhitelisted {
			go m.scanDevice(context.Background(), device)
		}
	}
}

// handleDeviceDisconnected handles a disconnected USB device
func (m *Monitor) handleDeviceDisconnected(driveLetter string) {
	log.Printf("USB device disconnected: %s", driveLetter)

	m.mu.Lock()
	device, exists := m.connectedDrives[driveLetter]
	if exists {
		delete(m.connectedDrives, driveLetter)
		// Clear drive letter in database
		device.DriveLetter = ""
		m.db.SaveUSBDevice(device)
	}
	callback := m.deviceCallback
	m.mu.Unlock()

	// Trigger callback
	if callback != nil && device != nil {
		callback("disconnected", device)
	}
}

// scanDevice scans a USB device for sensitive data
func (m *Monitor) scanDevice(ctx context.Context, device *models.USBDevice) error {
	if device.DriveLetter == "" {
		return nil
	}

	// Check drive size
	driveSize := getDriveSize(device.DriveLetter)
	maxSize := int64(m.config.USB.MaxScanSizeGB) * 1024 * 1024 * 1024
	if driveSize > maxSize {
		log.Printf("Skipping USB scan: drive %s is too large (%d GB)", device.DriveLetter, driveSize/1024/1024/1024)
		return nil
	}

	// Create scan session
	session := &models.USBScanSession{
		ID:        uuid.New().String(),
		DeviceID:  device.ID,
		StartedAt: time.Now(),
		Status:    "running",
	}

	if err := m.db.SaveUSBScanSession(session); err != nil {
		log.Printf("Failed to create USB scan session: %v", err)
	}

	// Update current scan info
	m.mu.Lock()
	m.currentScan = &models.USBScanInfo{
		DeviceID:    device.ID,
		DeviceName:  device.DeviceName,
		DriveLetter: device.DriveLetter,
		StartedAt:   session.StartedAt,
	}
	m.mu.Unlock()

	log.Printf("Starting USB scan for device %s (%s)", device.DeviceName, device.DriveLetter)

	// Create timeout context
	timeout := time.Duration(m.config.USB.ScanTimeoutMinutes) * time.Minute
	scanCtx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()

	// Perform scan using the file scanner
	drivePath := filepath.Clean(device.DriveLetter + "\\")
	err := m.scanner.StartUSBScan(scanCtx, drivePath, device.ID)

	// Update session status
	now := time.Now()
	session.CompletedAt = &now
	if err != nil {
		session.Status = "failed"
		log.Printf("USB scan failed: %v", err)
	} else {
		session.Status = "completed"
		log.Printf("USB scan completed for device %s", device.DeviceName)
	}

	m.db.SaveUSBScanSession(session)

	// Clear current scan info
	m.mu.Lock()
	m.currentScan = nil
	m.mu.Unlock()

	return err
}

// isDeviceWhitelisted checks if a device is in the whitelist
func (m *Monitor) isDeviceWhitelisted(device *models.USBDevice) bool {
	for _, serial := range m.config.USB.WhitelistDevices {
		if serial == device.DeviceSerial {
			return true
		}
	}
	return false
}

// isDeviceBlacklisted checks if a device is in the blacklist
func (m *Monitor) isDeviceBlacklisted(device *models.USBDevice) bool {
	for _, serial := range m.config.USB.BlacklistDevices {
		if serial == device.DeviceSerial {
			return true
		}
	}
	return false
}

