//go:build !windows

package usb

// DeviceInfo holds information about a USB device
type DeviceInfo struct {
	Serial string
	Vendor string
	Name   string
}

// getRemovableDrives returns a list of removable drive letters
// Stub for non-Windows platforms
func getRemovableDrives() []string {
	return []string{}
}

// getDeviceInfo gets information about a USB device
// Stub for non-Windows platforms
func getDeviceInfo(driveLetter string) DeviceInfo {
	return DeviceInfo{}
}

// getDriveSize returns the total size of a drive in bytes
// Stub for non-Windows platforms
func getDriveSize(driveLetter string) int64 {
	return 0
}

