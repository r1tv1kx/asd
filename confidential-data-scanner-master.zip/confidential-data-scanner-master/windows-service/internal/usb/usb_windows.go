//go:build windows

package usb

import (
	"fmt"
	"log"
	"strings"
	"syscall"
	"unsafe"
)

var (
	kernel32              = syscall.NewLazyDLL("kernel32.dll")
	getLogicalDrives      = kernel32.NewProc("GetLogicalDrives")
	getDriveTypeW         = kernel32.NewProc("GetDriveTypeW")
	getVolumeInformationW = kernel32.NewProc("GetVolumeInformationW")
	getDiskFreeSpaceExW   = kernel32.NewProc("GetDiskFreeSpaceExW")
)

const (
	driveRemovable = 2
	driveFixed     = 3
	driveCDROM     = 5
)

// DeviceInfo holds information about a USB device
type DeviceInfo struct {
	Serial string
	Vendor string
	Name   string
}

// getRemovableDrives returns a list of removable drive letters
func getRemovableDrives() []string {
	var drives []string

	// Get bitmask of available drives
	ret, _, _ := getLogicalDrives.Call()
	if ret == 0 {
		return drives
	}

	bitmask := uint32(ret)

	for i := 0; i < 26; i++ {
		if bitmask&(1<<uint(i)) != 0 {
			driveLetter := fmt.Sprintf("%c:", 'A'+i)
			driveType := getDriveType(driveLetter)

			// Only include removable drives
			if driveType == driveRemovable {
				drives = append(drives, driveLetter)
			}
		}
	}

	return drives
}

// getDriveType returns the type of a drive
func getDriveType(driveLetter string) uint32 {
	path, _ := syscall.UTF16PtrFromString(driveLetter + "\\")
	ret, _, _ := getDriveTypeW.Call(uintptr(unsafe.Pointer(path)))
	return uint32(ret)
}

// getDeviceInfo gets information about a USB device
func getDeviceInfo(driveLetter string) DeviceInfo {
	info := DeviceInfo{}

	rootPath, _ := syscall.UTF16PtrFromString(driveLetter + "\\")

	volumeName := make([]uint16, 256)
	serialNumber := uint32(0)
	maxComponentLength := uint32(0)
	fileSystemFlags := uint32(0)
	fileSystemName := make([]uint16, 256)

	ret, _, err := getVolumeInformationW.Call(
		uintptr(unsafe.Pointer(rootPath)),
		uintptr(unsafe.Pointer(&volumeName[0])),
		uintptr(len(volumeName)),
		uintptr(unsafe.Pointer(&serialNumber)),
		uintptr(unsafe.Pointer(&maxComponentLength)),
		uintptr(unsafe.Pointer(&fileSystemFlags)),
		uintptr(unsafe.Pointer(&fileSystemName[0])),
		uintptr(len(fileSystemName)),
	)

	if ret != 0 {
		info.Name = syscall.UTF16ToString(volumeName)
		info.Serial = fmt.Sprintf("%X", serialNumber)
	} else {
		log.Printf("Failed to get volume info for %s: %v", driveLetter, err)
	}

	// Try to get more detailed device info via WMI
	wmiInfo := getWMIDeviceInfo(driveLetter)
	if wmiInfo.Vendor != "" {
		info.Vendor = wmiInfo.Vendor
	}
	if wmiInfo.Serial != "" && info.Serial == "" {
		info.Serial = wmiInfo.Serial
	}
	if wmiInfo.Name != "" && info.Name == "" {
		info.Name = wmiInfo.Name
	}

	// Default name if still empty
	if info.Name == "" {
		info.Name = "Removable Drive"
	}

	return info
}

// getWMIDeviceInfo gets device info using WMI (simplified version)
func getWMIDeviceInfo(driveLetter string) DeviceInfo {
	// This is a simplified implementation
	// A full implementation would use the WMI library
	return DeviceInfo{}
}

// getDriveSize returns the total size of a drive in bytes
func getDriveSize(driveLetter string) int64 {
	rootPath, _ := syscall.UTF16PtrFromString(driveLetter + "\\")

	var freeBytesAvailable uint64
	var totalBytes uint64
	var totalFreeBytes uint64

	ret, _, _ := getDiskFreeSpaceExW.Call(
		uintptr(unsafe.Pointer(rootPath)),
		uintptr(unsafe.Pointer(&freeBytesAvailable)),
		uintptr(unsafe.Pointer(&totalBytes)),
		uintptr(unsafe.Pointer(&totalFreeBytes)),
	)

	if ret != 0 {
		return int64(totalBytes)
	}

	return 0
}

// isUSBDevice checks if a drive is a USB device (vs internal removable)
func isUSBDevice(driveLetter string) bool {
	// All removable drives are considered USB for simplicity
	// A more sophisticated check would query the device interface
	driveType := getDriveType(driveLetter)
	return driveType == driveRemovable
}

// formatDriveLetter ensures drive letter is in proper format (e.g., "E:")
func formatDriveLetter(input string) string {
	input = strings.TrimSpace(input)
	input = strings.ToUpper(input)

	if len(input) == 1 {
		return input + ":"
	}
	if len(input) == 2 && input[1] == ':' {
		return input
	}
	if len(input) >= 3 && input[1] == ':' {
		return input[:2]
	}

	return input
}

